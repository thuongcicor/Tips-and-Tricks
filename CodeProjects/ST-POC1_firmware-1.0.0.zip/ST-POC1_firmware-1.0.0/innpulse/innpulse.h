/*
 * innpulse.h
 *
 *  Created on: Nov 16, 2023
 *      Author: PaulBoymond
 */

#ifndef INNPULSE_H_
#define INNPULSE_H_

#include "stm32h7xx_hal.h"
#include "../innpulse/comIHM.h"

#define SEQUENCE_PRESS_CHANNEL      TIM_CHANNEL_1
#define SEQUENCE_RELEASE_CHANNEL    TIM_CHANNEL_2

#define SHOCK_POS_CHANNEL      TIM_CHANNEL_1
#define SHOCK_PAUSE_CHANNEL    TIM_CHANNEL_2
#define SHOCK_NEG_CHANNEL      TIM_CHANNEL_3


#define IHM_BREATHING_LED TIM_CHANNEL_2
#define IHM_BUZZER        TIM_CHANNEL_1

#define ADC_RESOLUTION 4096 //(12 bits)
#define ADC_V_REF_MV   3300
#define ADC_QUANTUM_TO_MV (float)((float)ADC_RESOLUTION / (float)ADC_V_REF_MV)

#define MAX_BUZZER_BIPS          5

#define TIMEBASE_MS (uint16_t) 10

typedef enum
{
	BUZZ_BIP_ENDED = 0,
	BUZZ_NONE,
	BUZZ_ON,
	BUZZ_OFF,
	BUZZ_WAIT,

}Innpulse_BuzzerStatus;

typedef enum
{
	BIP_NONE = 0,
	BIP_LONG = BUZZ_LONG_MS,
	BIP_SHORT = BUZZ_SHORT_MS,
	BIP_VERY_SHORT = BUZZ_VERY_SHORT_MS

}Innpulse_BuzzerBip;

typedef enum
{
	GPIO_H_BRIDGE_1 = 0,
	GPIO_H_BRIDGE_2,
	GPIO_H_BRIDGE_3,
	GPIO_H_BRIDGE_4,
	GPIO_LV,
	GPIO_HV,
	GPIO_DISCHARGE,
	GPIO_ECG,

	GPIO_NB

}Innpulse_GpioControlCmd;

typedef enum
{
	SEQUENCE_UNKNOWN = 0,
	SEQUENCE_VALID,
	SEQUENCE_FAIL

}Innpulse_StartSequence;

typedef enum
{
	STATUS_UNKNOWN = 0,
	STATUS_EMPTY,
	STATUS_PAUSED,
	STATUS_PRE_CHARGING,
	STATUS_CHARGING,
	STATUS_CHARGED,
	STATUS_SHOCKING_POSITIVE,
	STATUS_SHOCKING_NEGATIVE,

	STATUS_SAFE_DISCHARGING,
	STATUS_ERROR

}Innpulse_ChargeStatus;

typedef enum
{
	PHASE_POSITIF = 0,
	PHASE_STANDBY,
	PHASE_NEGATIF,

	PHASE_NB

}Innpulse_DischargePhase;

typedef enum
{
	LED_GREEN = 0,

}Innpulse_Led;

typedef struct
{
	// CHARGE
	GPIO_TypeDef * GPIO_Port_IGBT_1;
	uint16_t GPIO_Pin_IGBT_1;

	GPIO_TypeDef * GPIO_Port_IGBT_2;
	uint16_t GPIO_Pin_IGBT_2;

	GPIO_TypeDef * GPIO_Port_IGBT_3;
	uint16_t GPIO_Pin_IGBT_3;

	GPIO_TypeDef * GPIO_Port_IGBT_4;
	uint16_t GPIO_Pin_IGBT_4;

	GPIO_TypeDef * GPIO_Port_Discharge_CMD;
	uint16_t GPIO_Pin_Discharge_CMD;

	GPIO_TypeDef * GPIO_Port_Ecg_CMD;
	uint16_t GPIO_Pin_Ecg_CMD;

	GPIO_TypeDef * GPIO_Port_LV_Enabled;
	uint16_t GPIO_Pin_LV_Enabled;

	GPIO_TypeDef * GPIO_Port_HV_Enabled;
	uint16_t GPIO_Pin_HV_Enabled;

	// HMI
	GPIO_TypeDef * GPIO_Port_Button_1;
	uint16_t GPIO_Pin_Button_1;

	GPIO_TypeDef * GPIO_Port_Button_2;
	uint16_t GPIO_Pin_Button_2;

	GPIO_TypeDef * GPIO_Port_Button_Facade_1;
	uint16_t GPIO_Pin_Button_Facade_1;

	GPIO_TypeDef * GPIO_Port_Button_Facade_2;
	uint16_t GPIO_Pin_Button_Facade_2;

	GPIO_TypeDef * GPIO_Port_Button_Config_1;
	uint16_t GPIO_Pin_Button_Config_1;

	GPIO_TypeDef * GPIO_Port_Test_Config_4;
	uint16_t GPIO_Pin_Test_Config_4;

	GPIO_TypeDef * GPIO_Port_Led_1;
	uint16_t GPIO_Pin_Led_1;

	GPIO_TypeDef * GPIO_Port_Led_Shock;
	uint16_t GPIO_Pin_Led_Shock;

	GPIO_TypeDef * GPIO_Port_Switch;
	uint16_t GPIO_Pin_Switch;

	// Keep Alive
	GPIO_TypeDef * GPIO_Port_Keep_Alive;
	uint16_t GPIO_Pin_Keep_Alive;

}Innpulse_HardwareInterface;

typedef struct
{
	// CHARGE
	ADC_HandleTypeDef * charge_adc;

	// SHOCK
	TIM_HandleTypeDef * shock_timer;

	// HMI
	TIM_HandleTypeDef * ihm_timer;

	// TIME
	TIM_HandleTypeDef * periodic_timer;

	// SEQUENCE
	TIM_HandleTypeDef * timer_sequence;

	// COM
	UART_HandleTypeDef * ihm_huart;

}Innpulse_Periphericals;

typedef struct
{
	Innpulse_ChargeStatus status;
	Innpulse_ChargeStatus status_asked;

	uint32_t target_v;
	uint32_t current_v;
	bool updated;

	bool phase_pos_ended;
	bool phase_pause_ended;
	bool phase_neg_ended;

	uint32_t discharge_phases_us[PHASE_NB];

	uint32_t adc_value;

	GPIO_PinState control_cmd[GPIO_NB];

}Innpulse_ChargeHandle;

typedef enum
{
	INIT_STATE = 0,
	WAIT_STATE,
	CHARGING_STATE,
	WAIT_CHARGED_STATE,
	SHOCKING_STATE,
	DISCHARGING_STATE,

	STATE_NB,

	ERROR_STATE // not a real state

}Innpulse_State;

typedef struct
{
	Innpulse_StartSequence sequence;
	bool facade;

	Innpulse_BuzzerBip buzzer_bips[MAX_BUZZER_BIPS];
	Innpulse_BuzzerStatus buzzer_status;
	uint16_t buzzer_bip;
	bool buzzer_new_sequence;

}Innpulse_HMIHandle;

typedef struct
{
	int32_t acquisition_ms;
	int32_t buzzer_ms;
	int32_t wait_ms;
	int32_t keep_alive_ms;

	bool refresh;

}Innpulse_TimeHandle;

typedef struct
{
	Innpulse_State state;
	Innpulse_HMIHandle hmi;
	Innpulse_ChargeHandle charge;
	Innpulse_TimeHandle time;

	bool is_on;

}Innpulse_HandleTypeDef;

void Innpulse_Init();

void Innpulse_SetHadwareInterface (Innpulse_HardwareInterface * hard);
void Innpulse_SetPeripherals (Innpulse_Periphericals * periph);


//! Run the main state machine
/**
 *
 */
 void Innpulse_RunStep(void);

#endif /* INNPULSE_H_ */
