/*
 * innpulse.c
 *
 *  Created on: Nov 16, 2023
 *      Author: PaulBoymond
 */
#include "innpulse.h"

#include <string.h>

Innpulse_HandleTypeDef AppHandle;
Innpulse_HardwareInterface HardwareHandle;
Innpulse_Periphericals PeripheralsHandle;

/************** STATE MACHINE EXECUTION ************/
static void execInitState();
static void execWaitState();
static void execChargingState();
static void execDischargingState();

static void fullReset();
/************** ----------------------- ************/
static void processIHM();
static void processTicker();
static void processAcquisition();
static void processCharge();
static void processSwitch();
static void processKeepAlive();

/************** CHARGE ************/
static void setState(Innpulse_State s);
static void setChargeStatus(Innpulse_ChargeStatus s);
static void updateCurrentCharge();
static void isolateElectrods();
static void resetControl();
/************** ------ ************/

/************** HMI ************/
static void setLed(Innpulse_Led led, bool s);
static bool getLed(Innpulse_Led led);
static void setBuzzer(Innpulse_BuzzerBip * bips, uint16_t bip_nb);
/************** --- ************/

void Innpulse_Init()
{
	memset(&AppHandle, 0, sizeof(Innpulse_HandleTypeDef));

	HAL_ADC_Start_DMA(PeripheralsHandle.charge_adc,(uint32_t*)&AppHandle.charge.adc_value, 1);

	AppHandle.charge.target_v = DEFAULT_TARGET_V;

	AppHandle.charge.discharge_phases_us[PHASE_POSITIF] = DEFAULT_DISCHARGE_POSITIF_US;
	AppHandle.charge.discharge_phases_us[PHASE_STANDBY] = DEFAULT_DISCHARGE_STANDBY_US;
	AppHandle.charge.discharge_phases_us[PHASE_NEGATIF] = DEFAULT_DISCHARGE_NEGATIF_US;

	AppHandle.is_on = false;
	AppHandle.charge.updated = false;

	ComIHM_Init(PeripheralsHandle.ihm_huart);

	setState(INIT_STATE);
}

void Innpulse_SetHadwareInterface (Innpulse_HardwareInterface * hard)
{
	// CHARGE
	HardwareHandle.GPIO_Port_IGBT_1 = hard->GPIO_Port_IGBT_1;
	HardwareHandle.GPIO_Pin_IGBT_1 = hard->GPIO_Pin_IGBT_1;

	HardwareHandle.GPIO_Port_IGBT_2 = hard->GPIO_Port_IGBT_2;
	HardwareHandle.GPIO_Pin_IGBT_2 = hard->GPIO_Pin_IGBT_2;

	HardwareHandle.GPIO_Port_IGBT_3 = hard->GPIO_Port_IGBT_3;
	HardwareHandle.GPIO_Pin_IGBT_3 = hard->GPIO_Pin_IGBT_3;

	HardwareHandle.GPIO_Port_IGBT_4 = hard->GPIO_Port_IGBT_4;
	HardwareHandle.GPIO_Pin_IGBT_4 = hard->GPIO_Pin_IGBT_4;

	HardwareHandle.GPIO_Port_Discharge_CMD = hard->GPIO_Port_Discharge_CMD;
	HardwareHandle.GPIO_Pin_Discharge_CMD = hard->GPIO_Pin_Discharge_CMD;

	HardwareHandle.GPIO_Port_Ecg_CMD = hard->GPIO_Port_Ecg_CMD;
	HardwareHandle.GPIO_Pin_Ecg_CMD = hard->GPIO_Pin_Ecg_CMD;

	HardwareHandle.GPIO_Port_LV_Enabled = hard->GPIO_Port_LV_Enabled;
	HardwareHandle.GPIO_Pin_LV_Enabled = hard->GPIO_Pin_LV_Enabled;

	HardwareHandle.GPIO_Port_HV_Enabled = hard->GPIO_Port_HV_Enabled;
	HardwareHandle.GPIO_Pin_HV_Enabled = hard->GPIO_Pin_HV_Enabled;

	// HMI
	HardwareHandle.GPIO_Port_Button_1 = hard->GPIO_Port_Button_1;
	HardwareHandle.GPIO_Pin_Button_1 = hard->GPIO_Pin_Button_1;

	HardwareHandle.GPIO_Port_Button_2 = hard->GPIO_Port_Button_2;
	HardwareHandle.GPIO_Pin_Button_2 = hard->GPIO_Pin_Button_2;

	HardwareHandle.GPIO_Port_Button_Facade_1 = hard->GPIO_Port_Button_Facade_1;
	HardwareHandle.GPIO_Pin_Button_Facade_1 = hard->GPIO_Pin_Button_Facade_1;

	HardwareHandle.GPIO_Port_Button_Facade_2 = hard->GPIO_Port_Button_Facade_2;
	HardwareHandle.GPIO_Pin_Button_Facade_2 = hard->GPIO_Pin_Button_Facade_2;

	HardwareHandle.GPIO_Port_Button_Config_1 = hard->GPIO_Port_Button_Config_1;
	HardwareHandle.GPIO_Pin_Button_Config_1 = hard->GPIO_Pin_Button_Config_1;

	HardwareHandle.GPIO_Port_Test_Config_4 = hard->GPIO_Port_Test_Config_4;
	HardwareHandle.GPIO_Pin_Test_Config_4 = hard->GPIO_Pin_Test_Config_4;

	HardwareHandle.GPIO_Port_Led_1 = hard->GPIO_Port_Led_1;
	HardwareHandle.GPIO_Pin_Led_1 = hard->GPIO_Pin_Led_1;

	HardwareHandle.GPIO_Port_Led_Shock = hard->GPIO_Port_Led_Shock;
	HardwareHandle.GPIO_Pin_Led_Shock = hard->GPIO_Pin_Led_Shock;

	HardwareHandle.GPIO_Port_Switch = hard->GPIO_Port_Switch;
	HardwareHandle.GPIO_Pin_Switch = hard->GPIO_Pin_Switch;

	HardwareHandle.GPIO_Port_Keep_Alive = hard->GPIO_Port_Keep_Alive;
	HardwareHandle.GPIO_Pin_Keep_Alive = hard->GPIO_Pin_Keep_Alive;
}

void Innpulse_SetPeripherals (Innpulse_Periphericals * periph)
{
	// CHARGE
	PeripheralsHandle.charge_adc = periph->charge_adc;

	// SHOCK
	PeripheralsHandle.shock_timer = periph->shock_timer;

	// HMI
	PeripheralsHandle.ihm_timer = periph->ihm_timer;

	// TIME
	PeripheralsHandle.periodic_timer = periph->periodic_timer;

	// SEQUENCE
	PeripheralsHandle.timer_sequence = periph->timer_sequence;

	// COM
	PeripheralsHandle.ihm_huart = periph->ihm_huart;
}

void Innpulse_RunStep()
{
	ComIHM_ProcessBuffer();

	processKeepAlive();
	processAcquisition();
	processTicker();

	processSwitch();

	if (AppHandle.is_on)
	{
		processIHM();
	}

	processCharge();

	if (!AppHandle.charge.updated)
	{
		return;
	}

	switch (AppHandle.state)
	{
	case INIT_STATE:
		execInitState();

		HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_RESET);

		if (AppHandle.charge.current_v > EMPTY_CHARGE_THRESHOLD_V)
		{
			Innpulse_BuzzerBip bips_warning[5] = {BIP_SHORT, BIP_SHORT, BIP_SHORT, BIP_SHORT, BIP_SHORT};
			setBuzzer(bips_warning, 5);
		}
		else
		{
			Innpulse_BuzzerBip bips[1] = {BIP_LONG};
			setBuzzer(bips, 1);
		}

		setChargeStatus(STATUS_EMPTY);

		if (AppHandle.is_on)
		{
			setState(WAIT_STATE);
		}
		break;

	case WAIT_STATE:
		execWaitState();

		HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_RESET);

		if (AppHandle.hmi.sequence == SEQUENCE_VALID)
		{
			if (AppHandle.charge.status == STATUS_EMPTY)
			{
				Innpulse_BuzzerBip bips[2] = {BIP_SHORT, BIP_SHORT};
				setBuzzer(bips, 2);

				setState(CHARGING_STATE);

				AppHandle.hmi.sequence = SEQUENCE_UNKNOWN;
			}
		}
		break;

	case CHARGING_STATE:
		execChargingState();

		HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_SET);

		AppHandle.charge.status_asked = STATUS_CHARGING;

		if (AppHandle.charge.status == STATUS_CHARGED)
		{
			Innpulse_BuzzerBip bips[5] = {BIP_VERY_SHORT, BIP_VERY_SHORT, BIP_VERY_SHORT, BIP_VERY_SHORT, BIP_VERY_SHORT};

			setBuzzer(bips, 5);

			AppHandle.hmi.sequence = SEQUENCE_UNKNOWN;

			AppHandle.time.wait_ms = WAIT_BEFORE_SHOCK_MS;

			setState(WAIT_CHARGED_STATE);
		}
		break;


	case WAIT_CHARGED_STATE:
	{
		if (HAL_GPIO_ReadPin(HardwareHandle.GPIO_Port_Test_Config_4, HardwareHandle.GPIO_Pin_Test_Config_4) == TEST_MODE_CONFIG)
		{
			if (AppHandle.hmi.sequence != SEQUENCE_VALID)
			{
				AppHandle.time.wait_ms = WAIT_BEFORE_SHOCK_MS;
			}
			else
			{
				Innpulse_BuzzerBip bips[1] = {BIP_VERY_SHORT};

				setBuzzer(bips, 1);
			}
		}

		if (AppHandle.time.wait_ms == 0)
		{
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_SET);

			AppHandle.hmi.sequence = SEQUENCE_UNKNOWN;

			setState(SHOCKING_STATE);

		}
	}
		break;

	case SHOCKING_STATE:

		HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_SET);

		AppHandle.charge.status_asked = STATUS_SHOCKING_POSITIVE;

		if (AppHandle.charge.status == STATUS_SAFE_DISCHARGING)
		{
			setState(DISCHARGING_STATE);
		}
		break;

	case DISCHARGING_STATE:
		execDischargingState();

		HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Led_Shock, HardwareHandle.GPIO_Pin_Led_Shock, GPIO_PIN_SET);

		if (AppHandle.charge.status == STATUS_EMPTY)
		{
			setState(WAIT_STATE);
		}
		break;

	default:
		break;
	}
}

void execInitState()
{

}

void execWaitState()

{
	if (ComIHM_CommandAvailable())
	{
		ComIHM_CommandRcv_t type = ComIHM_CommandType();

		switch(type)
		{
		case SET_CHARGE_CMD :

			AppHandle.charge.target_v = ComIHM_ReadCommand()->charge_target_v;

			ComIHM_CompleteCommand(COMPLETED);
			break;

		case SET_DISCHARGE_CMD :

			AppHandle.charge.discharge_phases_us[PHASE_POSITIF] = ComIHM_ReadCommand()->discharge_t1_ms;
			AppHandle.charge.discharge_phases_us[PHASE_STANDBY] = ComIHM_ReadCommand()->discharge_t2_ms;
			AppHandle.charge.discharge_phases_us[PHASE_NEGATIF] = ComIHM_ReadCommand()->discharge_t3_ms;

			ComIHM_CompleteCommand(COMPLETED);
			break;

		case GET_CHARGE_CMD :

			printf("Charge target : %lu\n", AppHandle.charge.target_v);

			ComIHM_CompleteCommand(COMPLETED);
			break;

		case GET_DISCHARGE_CMD :

			printf("Discharge phases : %lu | %lu | %lu\n", AppHandle.charge.discharge_phases_us[PHASE_POSITIF],
														   AppHandle.charge.discharge_phases_us[PHASE_STANDBY],
														   AppHandle.charge.discharge_phases_us[PHASE_NEGATIF]);

			ComIHM_CompleteCommand(COMPLETED);
			break;

		default :
			ComIHM_CompleteCommand(NOT_COMPLETED);
			break;
		}
	}
}

void execChargingState()
{

}

void execDischargingState()
{

}

void fullReset()
{
	HAL_TIM_PWM_Stop(PeripheralsHandle.ihm_timer, IHM_BREATHING_LED);
	HAL_TIM_PWM_Stop(PeripheralsHandle.ihm_timer, IHM_BUZZER);

	HAL_TIM_OC_Stop_IT(PeripheralsHandle.timer_sequence, SEQUENCE_PRESS_CHANNEL);
	HAL_TIM_OC_Stop_IT(PeripheralsHandle.timer_sequence, SEQUENCE_RELEASE_CHANNEL);

	setState(INIT_STATE);
	setChargeStatus(STATUS_EMPTY);

	AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_ENABLED;
	AppHandle.charge.control_cmd[GPIO_LV] = LV_DESENABLED;
	AppHandle.charge.control_cmd[GPIO_HV] = HV_DESENABLED;
	AppHandle.charge.control_cmd[GPIO_ECG] = ECG_DESENABLED;

	AppHandle.charge.control_cmd[GPIO_H_BRIDGE_1] = IGBT_OPEN;
	AppHandle.charge.control_cmd[GPIO_H_BRIDGE_2] = IGBT_OPEN;
	AppHandle.charge.control_cmd[GPIO_H_BRIDGE_3] = IGBT_OPEN;
	AppHandle.charge.control_cmd[GPIO_H_BRIDGE_4] = IGBT_OPEN;

	AppHandle.charge.status_asked = STATUS_EMPTY;

	AppHandle.hmi.sequence = SEQUENCE_UNKNOWN;
}

void processIHM()
{
	// Breathing LED
	HAL_TIM_PWM_Start(PeripheralsHandle.ihm_timer, IHM_BREATHING_LED);
	uint16_t sinValue = (sin(HAL_GetTick() * 0.001) + 1) * PeripheralsHandle.ihm_timer->Instance->ARR;
	__HAL_TIM_SET_COMPARE(PeripheralsHandle.ihm_timer, IHM_BREATHING_LED, sinValue);

	if (AppHandle.time.buzzer_ms > 0)
	{
		if (AppHandle.hmi.buzzer_status == BUZZ_ON)
		{
		__HAL_TIM_SET_COMPARE(PeripheralsHandle.ihm_timer, IHM_BUZZER, DUTY_CYCLE_BUZZER);
		HAL_TIM_PWM_Start(PeripheralsHandle.ihm_timer, IHM_BUZZER);
		}
	}
	else
	{
		if (AppHandle.hmi.buzzer_status == BUZZ_ON)
		{
			HAL_TIM_PWM_Stop(PeripheralsHandle.ihm_timer, IHM_BUZZER);

			AppHandle.hmi.buzzer_status = BUZZ_OFF;
		}
		else if (AppHandle.hmi.buzzer_status == BUZZ_WAIT)
		{
			AppHandle.hmi.buzzer_status = BUZZ_BIP_ENDED;
		}
	}

	if (AppHandle.hmi.buzzer_new_sequence)
	{
		switch (AppHandle.hmi.buzzer_status)
		{
		case BUZZ_NONE:
			AppHandle.time.buzzer_ms = (int32_t)AppHandle.hmi.buzzer_bips[AppHandle.hmi.buzzer_bip];
			AppHandle.hmi.buzzer_status = BUZZ_ON;
			break;

		case BUZZ_ON:
			// wait the end of the buzzzzzz
			break;

		case BUZZ_OFF:
			if (AppHandle.hmi.buzzer_bips[AppHandle.hmi.buzzer_bip] == BIP_VERY_SHORT)
			{
				AppHandle.time.buzzer_ms = BUZZ_WAIT_VERY_SHORT_MS;
			}
			else
			{
				AppHandle.time.buzzer_ms = BUZZ_WAIT_MS;
			}
			AppHandle.hmi.buzzer_status = BUZZ_WAIT;
			break;

		case BUZZ_WAIT:
			// wait the end of the waiiiiiit
			break;

		case BUZZ_BIP_ENDED:
			AppHandle.hmi.buzzer_bips[AppHandle.hmi.buzzer_bip] = BIP_NONE;

			if (AppHandle.hmi.buzzer_bip != MAX_BUZZER_BIPS - 1)
			{
				AppHandle.hmi.buzzer_bip ++;
				AppHandle.hmi.buzzer_status = BUZZ_NONE;
			}
			else
			{
				AppHandle.hmi.buzzer_new_sequence = false;
			}

			break;
		}
	}
}

void processTicker()
{
	if (AppHandle.time.refresh)
	{
		if (AppHandle.time.buzzer_ms >= 0)
		{
			AppHandle.time.buzzer_ms -= TIMEBASE_MS;
		}
		if (AppHandle.time.buzzer_ms < 0)
		{
			AppHandle.time.buzzer_ms = 0;
		}

		if (AppHandle.time.wait_ms != 0)
		{
			AppHandle.time.wait_ms -= TIMEBASE_MS;
		}
		if (AppHandle.time.wait_ms < 0)
		{
			AppHandle.time.wait_ms = 0;
		}

		if (AppHandle.time.acquisition_ms != 0)
		{
			AppHandle.time.acquisition_ms -= TIMEBASE_MS;
		}
		if (AppHandle.time.acquisition_ms < 0)
		{
			AppHandle.time.acquisition_ms = 0;
		}

		if (AppHandle.time.keep_alive_ms != 0)
		{
			AppHandle.time.keep_alive_ms -= TIMEBASE_MS;
		}
		if (AppHandle.time.keep_alive_ms < 0)
		{
			AppHandle.time.keep_alive_ms = 0;
		}

		AppHandle.time.refresh = false;
	}
}

void processAcquisition()
{
	if (AppHandle.time.acquisition_ms == 0)
	{
		AppHandle.time.acquisition_ms += ACQUISITION_PERIOD_MS;

		updateCurrentCharge();
	}
}

void processCharge()
{
	if (AppHandle.is_on)
	{
		switch (AppHandle.charge.status)
		{
		case STATUS_EMPTY :
			resetControl();
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_ENABLED;

			if (AppHandle.charge.status_asked == STATUS_CHARGING)
			{
				setChargeStatus(STATUS_PRE_CHARGING);

				AppHandle.time.wait_ms = PRE_CHARGING_DELAY_MS;
			}

			break;

		case STATUS_PAUSED :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			if (AppHandle.charge.phase_pause_ended)
			{
				setChargeStatus(STATUS_SHOCKING_NEGATIVE);
			}

			break;

		case STATUS_PRE_CHARGING :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			AppHandle.charge.control_cmd[GPIO_LV] = LV_ENABLED;

			if (AppHandle.time.wait_ms == 0)
			{
				setChargeStatus(STATUS_CHARGING);
			}
			break;

		case STATUS_CHARGING :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			AppHandle.charge.control_cmd[GPIO_HV] = HV_ENABLED;

#if BYPASS_TENSION_TEST == 0
			if (AppHandle.charge.current_v >= AppHandle.charge.target_v)
			{

				setChargeStatus(STATUS_CHARGED);
			}
#else
			setChargeStatus(STATUS_CHARGED);
#endif
			break;

		case STATUS_CHARGED :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			AppHandle.charge.control_cmd[GPIO_HV] = HV_DESENABLED;

			if (AppHandle.charge.status_asked == STATUS_SHOCKING_POSITIVE)
			{
				// Not very accurate but safe, can be added to shock_timer for next phase
				if (HAL_GPIO_ReadPin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD) == ECG_ENABLED)
				{
					HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD, ECG_DESENABLED);
					AppHandle.time.wait_ms = PRE_SHOCKING_DELAY_MS;
				}

				if (AppHandle.time.wait_ms != 0)
				{
					break;
				}

				HAL_TIM_OC_Stop_IT(PeripheralsHandle.shock_timer, TIM_CHANNEL_ALL);
				HAL_TIM_Base_Stop_IT(PeripheralsHandle.shock_timer);

				AppHandle.charge.phase_pos_ended = false;
				AppHandle.charge.phase_pause_ended = false;
				AppHandle.charge.phase_neg_ended = false;

				__HAL_TIM_SET_COUNTER(PeripheralsHandle.shock_timer, 0);

				__HAL_TIM_SET_COMPARE(PeripheralsHandle.shock_timer, SHOCK_POS_CHANNEL, AppHandle.charge.discharge_phases_us[PHASE_POSITIF]);

				__HAL_TIM_SET_COMPARE(PeripheralsHandle.shock_timer, SHOCK_PAUSE_CHANNEL, AppHandle.charge.discharge_phases_us[PHASE_POSITIF] +
																						  AppHandle.charge.discharge_phases_us[PHASE_STANDBY]);

				__HAL_TIM_SET_COMPARE(PeripheralsHandle.shock_timer, SHOCK_NEG_CHANNEL, AppHandle.charge.discharge_phases_us[PHASE_NEGATIF] +
																                        AppHandle.charge.discharge_phases_us[PHASE_POSITIF] +
																						AppHandle.charge.discharge_phases_us[PHASE_STANDBY]);

				HAL_TIM_OC_Start_IT(PeripheralsHandle.shock_timer, SHOCK_POS_CHANNEL);
				HAL_TIM_OC_Start_IT(PeripheralsHandle.shock_timer, SHOCK_PAUSE_CHANNEL);
				HAL_TIM_OC_Start_IT(PeripheralsHandle.shock_timer, SHOCK_NEG_CHANNEL);

				HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_1, HardwareHandle.GPIO_Pin_IGBT_1, IGBT_CLOSED);
				HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_2, HardwareHandle.GPIO_Pin_IGBT_2, IGBT_OPEN);
				HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_3, HardwareHandle.GPIO_Pin_IGBT_3, IGBT_OPEN);
				HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_4, HardwareHandle.GPIO_Pin_IGBT_4, IGBT_CLOSED);

				HAL_TIM_Base_Start_IT(PeripheralsHandle.shock_timer);

				setChargeStatus(STATUS_SHOCKING_POSITIVE);
			}

			break;

		case STATUS_SHOCKING_POSITIVE :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			if (AppHandle.charge.phase_pos_ended)
			{
				setChargeStatus(STATUS_PAUSED);
			}

			break;

		case STATUS_SHOCKING_NEGATIVE :
			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_DESENABLED;

			if (AppHandle.charge.phase_neg_ended)
			{
				setChargeStatus(STATUS_SAFE_DISCHARGING);
			}
			break;

		case STATUS_SAFE_DISCHARGING :
			resetControl();

			HAL_TIM_OC_Stop_IT(PeripheralsHandle.shock_timer, SHOCK_POS_CHANNEL);
			HAL_TIM_OC_Stop_IT(PeripheralsHandle.shock_timer, SHOCK_PAUSE_CHANNEL);
			HAL_TIM_OC_Stop_IT(PeripheralsHandle.shock_timer, SHOCK_NEG_CHANNEL);

			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_ENABLED;

#if BYPASS_TENSION_TEST == 0
			if (AppHandle.charge.current_v <= EMPTY_CHARGE_THRESHOLD_V)
			{
				AppHandle.charge.status_asked = STATUS_EMPTY;
				setChargeStatus(STATUS_EMPTY);
			}
#else
			AppHandle.charge.status_asked = STATUS_EMPTY;
			setChargeStatus(STATUS_EMPTY);
#endif

			break;

		case STATUS_ERROR :
			resetControl();

			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_ENABLED;

			break;

		default:
			resetControl();

			AppHandle.charge.control_cmd[GPIO_DISCHARGE] = DISCHARGE_ENABLED;
			break;
		}
	}

	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_LV_Enabled, HardwareHandle.GPIO_Pin_LV_Enabled, AppHandle.charge.control_cmd[GPIO_LV]);

	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_HV_Enabled, HardwareHandle.GPIO_Pin_HV_Enabled, AppHandle.charge.control_cmd[GPIO_HV]);

	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Discharge_CMD, HardwareHandle.GPIO_Pin_Discharge_CMD, AppHandle.charge.control_cmd[GPIO_DISCHARGE]);

}

void processSwitch()
{
	if (HAL_GPIO_ReadPin(HardwareHandle.GPIO_Port_Switch, HardwareHandle.GPIO_Pin_Switch) == SWITCH_IS_ON)
	{
		AppHandle.is_on = true;
	}
	else
	{
		AppHandle.is_on = false;

		fullReset();
	}
}

void processKeepAlive()
{
	if (AppHandle.time.keep_alive_ms == 0)
	{
		AppHandle.time.keep_alive_ms += KEEP_ALIVE_PERIOD_MS;

		HAL_GPIO_TogglePin(HardwareHandle.GPIO_Port_Keep_Alive, HardwareHandle.GPIO_Pin_Keep_Alive);
	}
}

void setState(Innpulse_State s)
{
	if (AppHandle.state != s)
	{
		printf("State:%d;\n", s);

		AppHandle.state = s;
	}
}

void setChargeStatus(Innpulse_ChargeStatus s)
{
	if (AppHandle.charge.status != s)
	{
		AppHandle.charge.status = s;

		printf("Charge:%d;\n", AppHandle.charge.status);
	}
}

void updateCurrentCharge()
{
	AppHandle.charge.current_v = (ADC_CONVERSION * AppHandle.charge.adc_value / ADC_QUANTUM_TO_MV);

	AppHandle.charge.updated = true;

#if ENABLE_HF_DEBUG
	printf("Meas:%lu;\n", AppHandle.charge.current_v);
#endif
}

void isolateElectrods()
{
	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_1, HardwareHandle.GPIO_Pin_IGBT_1, IGBT_OPEN);
	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_2, HardwareHandle.GPIO_Pin_IGBT_2, IGBT_OPEN);
	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_3, HardwareHandle.GPIO_Pin_IGBT_3, IGBT_OPEN);
	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_4, HardwareHandle.GPIO_Pin_IGBT_4, IGBT_OPEN);

	HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD, ECG_ENABLED);
}

void resetControl()
{
	isolateElectrods();

	AppHandle.charge.control_cmd[GPIO_LV] = LV_DESENABLED;
	AppHandle.charge.control_cmd[GPIO_HV] = HV_DESENABLED;
}

void setLed(Innpulse_Led led, bool s)
{
	GPIO_TypeDef * port;
	uint16_t pin;

	switch(led)
	{
	case LED_GREEN :
		port = HardwareHandle.GPIO_Port_Led_1;
		pin = HardwareHandle.GPIO_Pin_Led_1;
		break;

	default:
		return;
	}

	GPIO_PinState state = GPIO_PIN_RESET;
	if (s)
	{
		state = GPIO_PIN_SET;
	}

	HAL_GPIO_WritePin(port, pin, state);
}

bool getLed(Innpulse_Led led)
{
	GPIO_TypeDef * port;
	uint16_t pin;

	switch(led)
	{
	case LED_GREEN :
		port = HardwareHandle.GPIO_Port_Led_1;
		pin = HardwareHandle.GPIO_Pin_Led_1;
		break;

	default:
		return false;
	}

	if (HAL_GPIO_ReadPin(port, pin) == GPIO_PIN_SET)
	{
		return true;
	}
	return false;
}

void setBuzzer(Innpulse_BuzzerBip * bips, uint16_t bip_nb)
{
	if (AppHandle.hmi.buzzer_status != BUZZ_BIP_ENDED)
	{
		return;
	}

	uint16_t n = MAX_BUZZER_BIPS;

	if (bip_nb < MAX_BUZZER_BIPS)
	{
		n = bip_nb;
	}

	for (int i=0; i<n; i++)
	{
		AppHandle.hmi.buzzer_bips[i] = bips[i];
	}

	AppHandle.hmi.buzzer_bip = 0;
	AppHandle.hmi.buzzer_new_sequence = true;
	AppHandle.hmi.buzzer_status = BUZZ_NONE;
}

/////////////////// IRQ HANDLER

void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim == PeripheralsHandle.timer_sequence)
	{
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
		{
			setLed(LED_GREEN, true);
		}
		else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2)
		{
			setLed(LED_GREEN, false);
		}
	}
	if(htim == PeripheralsHandle.shock_timer)
	{
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) // POS
		{
			AppHandle.charge.phase_pos_ended = true; // In the interrupt because it must to be very fast !

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD, ECG_DESENABLED);

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_1, HardwareHandle.GPIO_Pin_IGBT_1, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_2, HardwareHandle.GPIO_Pin_IGBT_2, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_3, HardwareHandle.GPIO_Pin_IGBT_3, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_4, HardwareHandle.GPIO_Pin_IGBT_4, IGBT_OPEN);

		}
		else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) // PAUSE
		{
			AppHandle.charge.phase_pause_ended = true;

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD, ECG_DESENABLED);

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_1, HardwareHandle.GPIO_Pin_IGBT_1, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_2, HardwareHandle.GPIO_Pin_IGBT_2, IGBT_CLOSED);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_3, HardwareHandle.GPIO_Pin_IGBT_3, IGBT_CLOSED);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_4, HardwareHandle.GPIO_Pin_IGBT_4, IGBT_OPEN);
		}
		else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3) // NEG
		{
			AppHandle.charge.phase_neg_ended = true;

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_Ecg_CMD, HardwareHandle.GPIO_Pin_Ecg_CMD, ECG_DESENABLED);

			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_1, HardwareHandle.GPIO_Pin_IGBT_1, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_2, HardwareHandle.GPIO_Pin_IGBT_2, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_3, HardwareHandle.GPIO_Pin_IGBT_3, IGBT_OPEN);
			HAL_GPIO_WritePin(HardwareHandle.GPIO_Port_IGBT_4, HardwareHandle.GPIO_Pin_IGBT_4, IGBT_OPEN);

		}
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	GPIO_TypeDef * port1;
	GPIO_TypeDef * port2;
	uint16_t pin1, pin2;

	if (HAL_GPIO_ReadPin(HardwareHandle.GPIO_Port_Button_Config_1, HardwareHandle.GPIO_Pin_Button_Config_1) == GPIO_PIN_SET)
	{
		port1 = HardwareHandle.GPIO_Port_Button_1;
		port2 = HardwareHandle.GPIO_Port_Button_2;
		pin1 = HardwareHandle.GPIO_Pin_Button_1;
		pin2 = HardwareHandle.GPIO_Pin_Button_2;
	}
	else
	{
		port1 = HardwareHandle.GPIO_Port_Button_Facade_1;
		port2 = HardwareHandle.GPIO_Port_Button_Facade_2;
		pin1 = HardwareHandle.GPIO_Pin_Button_Facade_1;
		pin2 = HardwareHandle.GPIO_Pin_Button_Facade_2;
	}

	if (GPIO_Pin == pin1 || GPIO_Pin == pin2)
	{
		if (HAL_GPIO_ReadPin(port1, pin1) == GPIO_PIN_SET &&
			HAL_GPIO_ReadPin(port2, pin2) == GPIO_PIN_SET)
		{
			// PRESSED
			__HAL_TIM_SET_COMPARE(PeripheralsHandle.timer_sequence, SEQUENCE_PRESS_CHANNEL, START_SEQUENCE_PRESS_MS);
			__HAL_TIM_SET_COMPARE(PeripheralsHandle.timer_sequence, SEQUENCE_RELEASE_CHANNEL, START_SEQUENCE_PRESS_MS + START_SEQUENCE_RELEASE_MS);

			HAL_TIM_OC_Start_IT(PeripheralsHandle.timer_sequence, SEQUENCE_PRESS_CHANNEL);
			HAL_TIM_OC_Start_IT(PeripheralsHandle.timer_sequence, SEQUENCE_RELEASE_CHANNEL);

			HAL_TIM_Base_Start_IT(PeripheralsHandle.timer_sequence);
		}
		else if (HAL_GPIO_ReadPin(port1, pin1) == GPIO_PIN_RESET &&
				 HAL_GPIO_ReadPin(port2, pin2) == GPIO_PIN_RESET)
		{
			// RELEASED
			if (getLed(LED_GREEN))
			{
				AppHandle.hmi.sequence = SEQUENCE_VALID;
			}
			else
			{
				AppHandle.hmi.sequence = SEQUENCE_FAIL;
			}

			setLed(LED_GREEN, false);

			HAL_TIM_Base_Stop_IT(PeripheralsHandle.timer_sequence);

			HAL_TIM_OC_Stop_IT(PeripheralsHandle.timer_sequence, SEQUENCE_PRESS_CHANNEL);
			HAL_TIM_OC_Stop_IT(PeripheralsHandle.timer_sequence, SEQUENCE_RELEASE_CHANNEL);

			__HAL_TIM_SET_COUNTER(PeripheralsHandle.timer_sequence, 0);
		}
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	// 100Hz
	if (htim == PeripheralsHandle.periodic_timer)
	{
		AppHandle.time.refresh = true;
	}
}
