/*
 * comIHM.h
 *
 *  Created on: Nov 16, 2023
 *      Author: PaulBoymond
 */

#ifndef COMIHM_H_
#define COMIHM_H_

#include <stdio.h>
#include <stdlib.h>

#include "stm32h7xx_hal.h"

#include "../innpulse/app_conf.h"

#define RECEPTION_BUFFER_SIZE (uint32_t) 500
#define MAX_FRAME_SIZE 500

#define SEPARATOR_CHAR (uint8_t) (';')

#define START_VALUE 	(uint16_t) 0xD5FC
#define END_VALUE   	(uint16_t) 0xF769

#define START_VALUE_BIT_0 	(uint16_t) ((START_VALUE & 0xFF00) >> 8)
#define START_VALUE_BIT_1 	(uint16_t) (START_VALUE & 0x00FF)

#define END_VALUE_BIT_0 	(uint16_t) ((END_VALUE & 0xFF00) >> 8)
#define END_VALUE_BIT_1 	(uint16_t) (END_VALUE & 0x00FF)

// Reception
#define CMD_SET_CHARGE_PARAMETERS      (uint8_t) 0x10
#define CMD_SET_DISCHARGE_PARAMETERS   (uint8_t) 0x20
#define CMD_GET_CHARGE_PARAMETERS      (uint8_t) 0x30
#define CMD_GET_DISCHARGE_PARAMETERS   (uint8_t) 0x40
#define CMD_ACK   					   (uint8_t) 0xAB
#define CMD_NACK   					   (uint8_t) 0xFE

#define CMD_POS_IN_FRAME	(uint16_t) 2

#define TRANSMIT_TIME_OUT   (uint32_t) 10000

#define HEADER_FRAME_SIZE   (uint16_t) 3
#define TAIL_FRAME_SIZE     (uint16_t) 3

#define MINIMUM_FRAME_SIZE   (uint16_t) HEADER_FRAME_SIZE + TAIL_FRAME_SIZE

// payload size
#define SET_CHARGE_PARAMETERS_NB     (uint16_t) 1
#define SET_DISCHARGE_PARAMETERS_NB  (uint16_t) 3
#define ACK_FRAME_SIZE   	       (uint16_t) (0)
#define NACK_FRAME_SIZE   	       (uint16_t) (0)


typedef enum
{
	UNKNOWN_CMD,
	SET_CHARGE_CMD,
	SET_DISCHARGE_CMD,
	GET_CHARGE_CMD,
	GET_DISCHARGE_CMD

} ComIHM_CommandRcv_t;

typedef enum
{
	FRAME_UNKNOWN_ERROR = 0x00,
	FRAME_OK,
	FRAME_ERROR_CRC,

	FRAME_ERROR_SIZE,
	FRAME_ERROR_PAYLOAD,
	FRAME_ERROR_PAYLOAD_SIZE,

	FRAME_ERROR_DEVICE_NOT_READY,
	FRAME_ERROR_CMD_UNAUTHORIZED,
	FRAME_ERROR_CMD_UNKOWN,

	// Custom
	//

} ComIHM_FrameStatus_t;

typedef enum
{
	NOTHING_AVAILABLE = 0,
	UNREAD_AVAILABLE  = 1

} ComIHM_CommandAvailability_t;

typedef enum
{
	UNKNWON       = 0,
	NOT_COMPLETED = 1,
	COMPLETED     = 2

} ComIHM_CommandCompletion_t;

typedef struct
{
	ComIHM_CommandRcv_t type;

	ComIHM_CommandCompletion_t completed;

	uint32_t charge_target_v;

	// Discharge phases
	uint32_t discharge_t1_ms; // Positive phase
	uint32_t discharge_t2_ms; // Standby phase
	uint32_t discharge_t3_ms; // Negative phase

}ComIHM_CommandHandle;

typedef struct
{
	bool new_data_available;
	uint32_t writing_index;
	uint8_t pBuffer[RECEPTION_BUFFER_SIZE];

}ComIHM_BufferHandle;

typedef struct
{
	ComIHM_BufferHandle buffer;

	ComIHM_CommandHandle actual_cmd;

	UART_HandleTypeDef * huartHandle;

}ComIHM_HandleTypeDef;

void ComIHM_Init (UART_HandleTypeDef * huart);

void ComIHM_ProcessBuffer();

/**
 * Send an ACK
 */
void ComIHM_SendAck();

/**
 * Send a NACK
 * return Success
 */
void ComIHM_SendNack();

/**
 * Verify and process a new received frame
 * param Full received frame
 * param Length of the frame
 * return Success
 */
ComIHM_FrameStatus_t ComIHM_ReceiveFrame(const uint8_t* frame, const uint16_t len);

/**
 * Get the current command handle
 * return current command handle
 */
const ComIHM_CommandHandle * ComIHM_ReadCommand();

/**
 * Get the current command type
 * return current command type
 */
ComIHM_CommandRcv_t ComIHM_CommandType();

/**
 * Test if there is a valid command available
 * return Availability of the current command
 */
ComIHM_CommandAvailability_t ComIHM_CommandAvailable();

/**
 * Set the completion state of the current command
 * param c Completion state
 */
void ComIHM_CompleteCommand(ComIHM_CommandCompletion_t c);



#endif /* COMIHM_H_ */
