/*
 * comIHM.c
 *
 *  Created on: Nov 16, 2023
 *      Author: PaulBoymond
 */
#include <string.h>

#include "comIHM.h"

static ComIHM_HandleTypeDef ComIhm_Handle;

static uint8_t pData_from_ihm[RECEPTION_BUFFER_SIZE] = {0};

static void _receiveData(uint16_t len);

static ComIHM_FrameStatus_t _processSetCharge(const uint8_t* frame, uint16_t len);
static ComIHM_FrameStatus_t _processSetDischarge(const uint8_t* frame, uint16_t len);
static ComIHM_FrameStatus_t _processGetCharge();
static ComIHM_FrameStatus_t _processGetDischarge();

static HAL_StatusTypeDef _insertNewCommand(const ComIHM_CommandHandle * cmd);

static ComIHM_CommandRcv_t _getFrameType(const uint8_t* frame, uint16_t len);
static uint8_t _generateCRC(const uint8_t * data, uint16_t len);
static ComIHM_FrameStatus_t _verifyFrame(const uint8_t * frame, uint16_t len);

static bool _extractInt(const uint8_t * frame, uint16_t len, uint32_t * values, uint16_t value_nb);

void ComIHM_Init(UART_HandleTypeDef * huart)
{
	memset(&ComIhm_Handle, 0, sizeof(ComIHM_HandleTypeDef));

	ComIhm_Handle.huartHandle = huart;

	HAL_UARTEx_ReceiveToIdle_IT(ComIhm_Handle.huartHandle, pData_from_ihm, sizeof(pData_from_ihm));
}

void ComIHM_ProcessBuffer()
{
	if (!ComIhm_Handle.buffer.new_data_available)
	{
		return;
	}
	ComIhm_Handle.buffer.new_data_available = false;

	const uint32_t start_buffer_index = ComIhm_Handle.buffer.writing_index;

	bool begin_frame_present = 0;
	bool end_frame_present = 0;

	uint32_t index_begin = 0;
	uint32_t index_end = 0;

	uint32_t index = 0;

	// Detect a full frame
	while ( (index != (start_buffer_index - 1) ) && !(begin_frame_present && end_frame_present) )
	{
		if (index >= RECEPTION_BUFFER_SIZE)
		{
			index = 0;
		}

		// Look for a full frame (begin + end)
		if ( !(begin_frame_present && end_frame_present))
		{
			// Find the beginning of a frame
			if ( (ComIhm_Handle.buffer.pBuffer[index] == START_VALUE_BIT_0)
					&& (ComIhm_Handle.buffer.pBuffer[index+1] == START_VALUE_BIT_1) )
			{
				begin_frame_present = 1;
				index_begin = index;
			}

			// Find the end of a frame
			if ( ( (ComIhm_Handle.buffer.pBuffer[index] == END_VALUE_BIT_0)
					&& (ComIhm_Handle.buffer.pBuffer[index+1] == END_VALUE_BIT_1) ) && begin_frame_present)
			{
				end_frame_present = 1;
				index_end = index+1;
			}
		}

		index++;
	}

	// IF full frame detected
	if (begin_frame_present && end_frame_present)
	{
		// Build the frame
		uint8_t pFrame[MAX_FRAME_SIZE] = {0};

		uint16_t frame_size = 0;

		for (int i = index_begin; i<=index_end; i++)
		{
			pFrame[i-index_begin] = ComIhm_Handle.buffer.pBuffer[i];

			frame_size++;
		}

		//reset buffer's index
		ComIhm_Handle.buffer.writing_index = 0;

		ComIHM_FrameStatus_t ret = ComIHM_ReceiveFrame(pFrame, frame_size);
		// Send full frame to the frame manager
		if (ret != FRAME_OK)
		{
			printf("ERROR com : %d\n", ret);
		}
	}
}

ComIHM_FrameStatus_t ComIHM_ReceiveFrame(const uint8_t* frame, uint16_t len)
{
	ComIHM_FrameStatus_t ret = _verifyFrame(frame, len);
	if (ret != FRAME_OK)
	{
		ComIHM_SendNack(ret);
		return ret;
	}

	ComIHM_CommandRcv_t type = _getFrameType(frame, len);

	printf("CMD received : %d\n", type);

	switch(type)
	{
	case SET_CHARGE_CMD :
		ret = _processSetCharge(frame, len);
		break;

	case SET_DISCHARGE_CMD :
		ret = _processSetDischarge(frame, len);
		break;

	case GET_CHARGE_CMD :
		ret = _processGetCharge();
		break;

	case GET_DISCHARGE_CMD :
		ret = _processGetDischarge();
		break;

	default:
		ComIHM_SendNack(FRAME_ERROR_CMD_UNKOWN);
		break;
	}

	if (ret != FRAME_OK)
	{
		ComIHM_SendNack();
	}

	return ret;
}

const ComIHM_CommandHandle * ComIHM_ReadCommand()
{
	return &ComIhm_Handle.actual_cmd;
}

const ComIHM_CommandRcv_t ComIHM_CommandType()
{
	return ComIhm_Handle.actual_cmd.type;
}

ComIHM_CommandAvailability_t ComIHM_CommandAvailable()
{
	if (ComIhm_Handle.actual_cmd.completed != NOT_COMPLETED)
	{
		return NOTHING_AVAILABLE;
	}

	return UNREAD_AVAILABLE;
}

void ComIHM_CompleteCommand(ComIHM_CommandCompletion_t c)
{
	ComIhm_Handle.actual_cmd.completed = COMPLETED;

	if (c == COMPLETED)
	{
		ComIHM_SendAck();
	}
	else
	{
		ComIHM_SendNack(FRAME_ERROR_CMD_UNAUTHORIZED);
	}
}

static void _receiveData(uint16_t len)
{
	for (int i=0; i<len; i++)
	{
		// Reset buffer index to beginning
		if ( (ComIhm_Handle.buffer.writing_index) >= RECEPTION_BUFFER_SIZE)
		{
			ComIhm_Handle.buffer.writing_index = 0;
		}

		// Write in buffer and increment the writing index
		ComIhm_Handle.buffer.pBuffer[ComIhm_Handle.buffer.writing_index] = pData_from_ihm[i];
		ComIhm_Handle.buffer.writing_index++;
	}

	ComIhm_Handle.buffer.new_data_available = true;
}

static ComIHM_FrameStatus_t _processSetCharge(const  uint8_t* frame, const  uint16_t len)
{
	ComIHM_CommandHandle cmd;

	cmd.type = SET_CHARGE_CMD;

	uint32_t values[SET_CHARGE_PARAMETERS_NB] = {0};

	if (!_extractInt(frame, len, values, SET_CHARGE_PARAMETERS_NB))
	{
		return FRAME_ERROR_PAYLOAD;
	}

	printf("value : %lu\n", values[0]);

	cmd.charge_target_v = values[0];

	_insertNewCommand(&cmd);

	return FRAME_OK;
}

static ComIHM_FrameStatus_t _processSetDischarge(const uint8_t* frame, uint16_t len)
{
	ComIHM_CommandHandle cmd;

	cmd.type = SET_DISCHARGE_CMD;

	uint32_t values[SET_DISCHARGE_PARAMETERS_NB] = {0};

	if (!_extractInt(frame, len, values, SET_DISCHARGE_PARAMETERS_NB))
	{
		return FRAME_ERROR_PAYLOAD;
	}

	printf("value : %lu | %lu | %lu\n", values[0], values[1], values[2]);

	cmd.discharge_t1_ms = values[0];
	cmd.discharge_t2_ms = values[1];
	cmd.discharge_t3_ms = values[2];

	_insertNewCommand(&cmd);

	return FRAME_OK;
}

static ComIHM_FrameStatus_t _processGetCharge()
{
	ComIHM_CommandHandle cmd;

	cmd.type = GET_CHARGE_CMD;

	_insertNewCommand(&cmd);

	return FRAME_OK;
}

static ComIHM_FrameStatus_t _processGetDischarge()
{
	ComIHM_CommandHandle cmd;

	cmd.type = GET_DISCHARGE_CMD;

	_insertNewCommand(&cmd);

	return FRAME_OK;
}

static HAL_StatusTypeDef _insertNewCommand(const ComIHM_CommandHandle * cmd)
{
	if (ComIhm_Handle.actual_cmd.completed == NOT_COMPLETED)
	{
		ComIHM_SendNack(FRAME_ERROR_DEVICE_NOT_READY);

		return HAL_ERROR; // Try to write on not completed command
	}

	ComIhm_Handle.actual_cmd = *cmd;
	ComIhm_Handle.actual_cmd.completed = NOT_COMPLETED;

	return HAL_OK;
}

static ComIHM_CommandRcv_t _getFrameType(const uint8_t* frame, uint16_t len)
{
	ComIHM_CommandRcv_t cmd = UNKNOWN_CMD;

	if (len < (CMD_POS_IN_FRAME + 1) )
	{
		return UNKNOWN_CMD;
	}

	if ( (frame[0] == START_VALUE_BIT_0)
			&&(frame[1] == START_VALUE_BIT_1)
	)
	{
		switch (frame[CMD_POS_IN_FRAME])
		{
		case CMD_SET_CHARGE_PARAMETERS :
			cmd = SET_CHARGE_CMD;
			break;

		case CMD_SET_DISCHARGE_PARAMETERS :
			cmd = SET_DISCHARGE_CMD;
			break;

		case CMD_GET_CHARGE_PARAMETERS :
			cmd = GET_CHARGE_CMD;
			break;

		case CMD_GET_DISCHARGE_PARAMETERS :
			cmd = GET_DISCHARGE_CMD;
			break;

		default :

			cmd = UNKNOWN_CMD;
			break;
		}
	}

	return cmd;
}

/* CRC-16/CCITT-FALSE */
static uint8_t _generateCRC(const uint8_t * data, uint16_t len)
{
	uint8_t crc = data[0];

	for (unsigned int i = 1; i < len; ++i)
	{
		crc ^= data[i];
	}

	return crc;
}

static ComIHM_FrameStatus_t _verifyFrame(const uint8_t * frame, uint16_t len)
{
	// Verify Frame Minimum size
	if (len < MINIMUM_FRAME_SIZE)
	{
		return FRAME_ERROR_SIZE;
	}

	// Verify CRC
	uint8_t verify_crc = _generateCRC(frame, len - TAIL_FRAME_SIZE);
	uint8_t rcv_crc = frame[len - TAIL_FRAME_SIZE];

	if (verify_crc != rcv_crc)
	{
		printf("CRC : Error %hu(vrfy) | %hu(rcvd)\n", verify_crc, rcv_crc);
		return FRAME_ERROR_CRC;
	}

	return FRAME_OK;
}

static bool _extractInt(const uint8_t * frame, uint16_t len, uint32_t * values, uint16_t value_nb)
{
	if (len < TAIL_FRAME_SIZE)
	{
		return false;
	}

	uint16_t values_founded = 0;

	bool start_founded = false;
	bool end_founded = false;

	uint16_t separator_start_index = 0;
	uint16_t separator_end_index = 0;

	for (uint16_t i=0; i<len - TAIL_FRAME_SIZE; ++i)
	{
		if (frame[i] == SEPARATOR_CHAR)
		{
			if (!start_founded)
			{
				start_founded = true;
				separator_start_index = i + 1;
			}
			else
			{
				end_founded = true;
				separator_end_index = i;
			}
		}

		if (start_founded && end_founded)
		{
			if ((separator_end_index - separator_start_index) <= 0)
			{
				return false;
			}

			char payload_str[(separator_end_index - separator_start_index)];

			memcpy(payload_str, &frame[separator_start_index], sizeof(payload_str));

			if (values_founded >= value_nb)
			{
				return false;
			}

			values[values_founded] = atoi(payload_str);

			++values_founded;
			end_founded = false;

			separator_start_index = separator_end_index + 1;
		}
	}

	return (values_founded == value_nb);
}

void ComIHM_SendAck()
{
	printf("ACK\n");
}

void ComIHM_SendNack()
{
	printf("NACK\n");
}

/////////////////// IRQ HANDLER

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if (huart != ComIhm_Handle.huartHandle)
	{
		return;
	}

	_receiveData(Size);

	HAL_UARTEx_ReceiveToIdle_IT(ComIhm_Handle.huartHandle, pData_from_ihm, sizeof(pData_from_ihm));
}
