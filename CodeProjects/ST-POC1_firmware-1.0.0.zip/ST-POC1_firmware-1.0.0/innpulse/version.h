#ifndef VERSION_H_
#define VERSION_H_

/**
 * Software version
 *
 * This field shall be substituted by continuous integration system
 */
static const char impulse_revision[] = "oooDEVooo";

#endif /* VERSION_H_ */
