/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BTN_1_Pin GPIO_PIN_3
#define BTN_1_GPIO_Port GPIOE
#define BTN_1_EXTI_IRQn EXTI3_IRQn
#define OUT_HV_ENABLE_Pin GPIO_PIN_6
#define OUT_HV_ENABLE_GPIO_Port GPIOE
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define B1_EXTI_IRQn EXTI15_10_IRQn
#define BTN_2_Pin GPIO_PIN_1
#define BTN_2_GPIO_Port GPIOF
#define BTN_2_EXTI_IRQn EXTI1_IRQn
#define IN_SWITCH_Pin GPIO_PIN_7
#define IN_SWITCH_GPIO_Port GPIOF
#define OUT_LV_ENABLE_Pin GPIO_PIN_2
#define OUT_LV_ENABLE_GPIO_Port GPIOC
#define ADC_Pin GPIO_PIN_3
#define ADC_GPIO_Port GPIOC
#define LD1_Pin GPIO_PIN_0
#define LD1_GPIO_Port GPIOB
#define OUT_IGBT_3_Pin GPIO_PIN_12
#define OUT_IGBT_3_GPIO_Port GPIOF
#define IN_CONFIG_2_Pin GPIO_PIN_0
#define IN_CONFIG_2_GPIO_Port GPIOG
#define IN_CONFIG_2_EXTI_IRQn EXTI0_IRQn
#define OUT_ENABLE_ECG_Pin GPIO_PIN_1
#define OUT_ENABLE_ECG_GPIO_Port GPIOG
#define OUT_ENABLE_DISCHARGE_Pin GPIO_PIN_15
#define OUT_ENABLE_DISCHARGE_GPIO_Port GPIOE
#define STLINK_RX_Pin GPIO_PIN_8
#define STLINK_RX_GPIO_Port GPIOD
#define STLINK_TX_Pin GPIO_PIN_9
#define STLINK_TX_GPIO_Port GPIOD
#define USB_OTG_FS_PWR_EN_Pin GPIO_PIN_10
#define USB_OTG_FS_PWR_EN_GPIO_Port GPIOD
#define OUT_KEEP_ALIVE_Pin GPIO_PIN_13
#define OUT_KEEP_ALIVE_GPIO_Port GPIOD
#define OUT_IGBT_4_Pin GPIO_PIN_4
#define OUT_IGBT_4_GPIO_Port GPIOG
#define USB_OTG_FS_OVCR_Pin GPIO_PIN_7
#define USB_OTG_FS_OVCR_GPIO_Port GPIOG
#define USB_OTG_FS_OVCR_EXTI_IRQn EXTI9_5_IRQn
#define OUT_IGBT_2_Pin GPIO_PIN_8
#define OUT_IGBT_2_GPIO_Port GPIOG
#define OUT_BUZZER_Pin GPIO_PIN_6
#define OUT_BUZZER_GPIO_Port GPIOC
#define OUT_BREATHING_LED_Pin GPIO_PIN_7
#define OUT_BREATHING_LED_GPIO_Port GPIOC
#define IN_CONFIG_1_Pin GPIO_PIN_0
#define IN_CONFIG_1_GPIO_Port GPIOD
#define LED_ERROR_Pin GPIO_PIN_1
#define LED_ERROR_GPIO_Port GPIOD
#define LED_SHOCK_Pin GPIO_PIN_6
#define LED_SHOCK_GPIO_Port GPIOD
#define IN_CONFIG_3_Pin GPIO_PIN_9
#define IN_CONFIG_3_GPIO_Port GPIOG
#define IN_CONFIG_3_EXTI_IRQn EXTI9_5_IRQn
#define IN_FAULT_FLAG_Pin GPIO_PIN_10
#define IN_FAULT_FLAG_GPIO_Port GPIOG
#define IN_CONFIG_4_Pin GPIO_PIN_12
#define IN_CONFIG_4_GPIO_Port GPIOG
#define OUT_IGBT_1_Pin GPIO_PIN_14
#define OUT_IGBT_1_GPIO_Port GPIOG
#define IN_DONE_FLAG_Pin GPIO_PIN_15
#define IN_DONE_FLAG_GPIO_Port GPIOG
#define LD2_Pin GPIO_PIN_1
#define LD2_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
