# firmware_ST
[![Quality Gate Status](https://sonar.valotec.lan/api/project_badges/measure?project=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5&metric=alert_status&token=sqb_46d35ef29f874e9a69b9adbeedeb54b1435e100d)](https://sonar.valotec.lan/dashboard?id=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5)
[![Bugs](https://sonar.valotec.lan/api/project_badges/measure?project=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5&metric=bugs&token=sqb_46d35ef29f874e9a69b9adbeedeb54b1435e100d)](https://sonar.valotec.lan/dashboard?id=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5)
[![Code Smells](https://sonar.valotec.lan/api/project_badges/measure?project=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5&metric=code_smells&token=sqb_46d35ef29f874e9a69b9adbeedeb54b1435e100d)](https://sonar.valotec.lan/dashboard?id=inn-dad_firmware_st_AYzOu64D4KmT3kaZL_-5)

## Tools version
>STM32CubeIDE : 1.12.1
>BSP STM32H7 : 1.11.1
