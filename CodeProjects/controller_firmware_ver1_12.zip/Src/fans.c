/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    fans.c
**
** Description: This module controls the low-level timer modules on the STM32F0
**              for fan PWM output and fan tach input.  Also controls the logic
**              for computing and controlling the fan RPM and PWM value.
**              If fan outputs are used for LEDs (as in the Sonendo app), then
**              the LED module function will just turn the LED on/off with the
**              low-level HAL Start/Stop functions.  (See leds.c).
**
** Version/Author/Date/Description:
** 1   DMA   03/06/2018  Began coding.
** 2   DMA   12/20/2018  Created this module to separate the fan code from the
**                       TEC PWM code.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "main.h"
#include "pwm.h"
#include "adc.h"
#include "gpio.h"
#include "eeprom.h"
#include "config.h"
#include <math.h>
#include <stdlib.h>

TIM_HandleTypeDef htim1;  // fan pwm drive output
TIM_HandleTypeDef htim3;  // fan tach input capture

/*******************************************************************************
** FAN tach values structs.
*******************************************************************************/
static fan_ic_values_t  fan_tach[2];    // just 2 fans for now...
static U8               fan_speed[2];  // fan status, off, low, med, high

/*******************************************************************************
** Function:     fan_ctrl
** Description:  This function starts or stops the fan on the selected channel
**               using the duty cycle parameter.  For reference:
**               channel 1 - fan1 - J15 connector (near mounting hole on board)
**                           outside fan for ISC, hot side fan for Sonendo
**               channel 2 - fan3 - J16 (not used on ISC, LED for Sonendo)
**               channel 3 - fan4 - J17 connector (farthest from mounting hole)
**               channel 4 - fan2 - J18 (inside, cool side fan, ISC)
** Inputs:       pwm output fan channel (U32), and fan speed (U8).
** Outputs:
*******************************************************************************/
void  fan_ctrl( U32 channel, U8 new_speed )
{
  U8  fan_update_needed = YES;  // default is fan needs to be updated...

  if ( new_speed == FAN_SPEED_OFF )
  {
    set_fan_duty_cycle( channel, FAN_SPEED_OFF );

    if ( channel == FAN1_CH )
    {
      fan_speed[0] = FAN_SPEED_OFF;
    }
    if ( channel == FAN2_CH )
    {
      fan_speed[1] = FAN_SPEED_OFF;
    }
  }
  else
  {
    if ( channel == FAN1_CH )
    {
      if ( fan_speed[0] == new_speed )
      {
        fan_update_needed = NO;  // speed already set, nothing more to do
      }
      else
      {
        if ( new_speed < 25 )
        {
          new_speed = 47;  // minimum fan speed (about 3000 RPM)
        }
        else if ( new_speed > 74 )
        {
          new_speed = 99;  // max out speed for all TEC pwm values > 74%
        }
        fan_speed[0] = new_speed;
      }
    }
    if ( channel == FAN2_CH )
    {
      if ( fan_speed[1] == new_speed )
      {
        fan_update_needed = NO;  // speed already set, nothing more to do
      }
      else
      {
        fan_speed[1] = new_speed;
      }
    }

    if ( fan_update_needed == YES )
    {
      /* Set the duty cycle, then start the fan. */
      set_fan_duty_cycle( channel, new_speed );
      HAL_Delay( 1 );  // not sure if this is needed...

      fan_start_stop( FAN_START, channel );  // start fan
    }
  }

}  // end fan_ctrl()

/*******************************************************************************
** Function:     fan_sonendo_ctrl
** Description:  The Sonendo fan is controlled by the following rules:
**
**               Controller TEC duty  | Fan duty
**               ______________________________________________________________
**               0% thru 25%          | 50%     (2400 RPM - baseline fan speed)
**               26% thru 49%         | 66.67%  (3200 RPM)
**               50% thru 74%         | 83.33%  (4000 RPM)
**               75% thru 100%        | 100%    (4800 RPM)

TODO:  updates..............

**
** Inputs:       U8 - pwm TEC duty cycle value (0 to 100).
** Outputs:
*******************************************************************************/
void  fan_sonendo_ctrl( U8 TEC_duty )
{
  U8  new_speed;

  /* The fan speed rules can be simplified as follows:
  ** if TEC duty <= 25%, then fan duty = 34% (corresponds to ~ 2400 RPM)
  ** if TEC duty >= 75%, then fan duty = 100% (corresponds to ~ 4800 RPM)
  ** else, between the two limits, use this linear approximation:
  ** fan duty = 1.32 * TEC duty. */
  if ( TEC_duty < 25 )
  {
    new_speed = 34;  // minimum fan speed (about 2400 RPM)
  }
  else if ( TEC_duty > 75 )
  {
    new_speed = 72;  // max fan speed (about 4800 RPM) !!! TODO: new fan speed updates....
  }
  else
  {
    new_speed = 50;  //(U8)( TEC_duty * 1.32f );
  }

  /* If fan speed is different, send new fan speed (duty cycle) and save it. */
  if ( fan_speed[0] != new_speed )
  {
    fan_speed[0] = new_speed;
    set_fan_duty_cycle( FAN1_CH, new_speed );
    fan_start_stop( FAN_START, FAN1_CH );
  }

}  // end fan_sonendo_ctrl()

/*******************************************************************************
** Function:     fan_isc_ctrl
** Description:  The ISC fans are controlled by the following rules:
**               Sensor temperature in HEAT or COOL region, (>SPH+2 OR <SPL-2):
**                 Inside, cool-side fan 100%, outside, hot-side fan 100%
**               Sensor temperature in DEADBAND region, (<SPH-2 AND >SPL+2):
**                 Inside 50%, outside 0%
**               Else, (within +-2 degrees of SPH or SPL):
**                 Inside 75%, outside 75%, unless not heat or cool, then 0.
**
** Inputs:       F32 - sph, spl and sensor (in degrees C).
** Outputs:
*******************************************************************************/
void  fan_isc_ctrl( F32 sph, F32 spl, F32 sensor )
{
  U8  new_inside;   // fan 2
  U8  new_outside;  // fan 1
  U32  dummy1;
  U8   dummy2;
  heat_cool_t  hc;

  pid_vals( &dummy1, &dummy2, &hc, GET_HC_MODE );  // get current heat/cool mode

  if (( sensor > ( sph + 2.0f )) || ( sensor < ( spl - 2.0f )))
  {
    new_inside = 100;   // for both cool-side fan and hot-side fan
    new_outside = 100;
  }
  else if (( sensor < ( sph - 2.0f )) && ( sensor > ( spl + 2.0f )))
  {
    new_inside = 50;    // in the deadband region
    new_outside = 0;
  }
  else
  {
    /* In transition zone, near sph or spl, set fan speeds.  If not heating or
    ** cooling anymore (or yet), then set outside fan off. */
    new_inside = 75;
    new_outside = 75;
    if ( hc == NO_HEAT_NO_COOL )
    {
      new_outside = 0;
    }
  }

  /* If fan speed is different, send new fan speed (duty cycle) and save it. */
  if ( fan_speed[0] != new_outside )
  {
    set_fan_duty_cycle( FAN1_CH, new_outside );
    fan_start_stop( FAN_START, FAN1_CH );
    fan_speed[0] = new_outside;
  }
  if ( fan_speed[1] != new_inside )
  {
    set_fan_duty_cycle( FAN2_CH, new_inside );
    fan_start_stop( FAN_START, FAN2_CH );
    fan_speed[1] = new_inside;
  }

}  // end fan_isc_ctrl()

/*******************************************************************************
** Function:     set_fan_duty_cycle
** Description:  Sets the PWM drive output to a duty cycle value 0 to 100%.
** Inputs:       pwm output channel (U32),  pwm drive value, 0-100, (U8).
** Outputs:
*******************************************************************************/
void  set_fan_duty_cycle( U32 channel, U8 pwm_drive )
{
  U16  fan_duty;
  TIM_OC_InitTypeDef sConfigOC;

  /* Limit check on timer channel. Only channels 1 thru 4 defined for fans. */
  if ( channel <= TIM_CHANNEL_4 )
  {
    /* Before changing duty, make sure the selected pwm channel is stopped. */
    fan_start_stop( FAN_STOP, channel );  // stop fan

    /* Limit check is done in the "scale_value" function. */
    fan_duty = scale_value( pwm_drive );

    sConfigOC.OCMode       = TIM_OCMODE_PWM1;
    sConfigOC.Pulse        = fan_duty;
    sConfigOC.OCPolarity   = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
    sConfigOC.OCFastMode   = TIM_OCFAST_DISABLE;
    sConfigOC.OCIdleState  = TIM_OCIDLESTATE_RESET;
    sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;

    /* Set the output control config struct items. */
    if (HAL_TIM_PWM_ConfigChannel( &htim1, &sConfigOC, channel ) != HAL_OK)
    {
      _Error_Handler(__FILE__, __LINE__);
    }
  }

}  // end set_fan_duty_cycle()

/*******************************************************************************
** Function:     fan_start_stop
** Description:  Low level control (start and stop) for the fan PWM output.
** Inputs:       U8 - START_FAN, STOP_FAN,
** Outputs:      .
*******************************************************************************/
void  fan_start_stop( U8 fan_on_off, U32 channel )
{

  if ( fan_on_off == FAN_START )
  {
    /* Start the fan on the selected channel. */
    if ( HAL_TIM_PWM_Start( &htim1, channel ) != HAL_OK )
    {
      Error_Handler();
    }
  }
  else
  {
    /* Stop the fan on the selected channel. */
    if ( HAL_TIM_PWM_Stop( &htim1, channel ) != HAL_OK )
    {
      Error_Handler();
    }
    /* Update fan speed values to reflect that the fan was ordered to stop. */
    if ( channel == FAN1_CH )
    {
      fan_speed[0] = FAN_SPEED_OFF;
    }
    if ( channel == FAN2_CH )
    {
      fan_speed[1] = FAN_SPEED_OFF;
    }
  }

}  // end fan_start_stop()

/*******************************************************************************
** Function:     get_fan_tach
** Description:  Gets the fan tachometer value in RPM.  Since the fan tach
**               interrupt routine holds the last RPM value, even after the fan
**               has stopped, we can check the one-shot fan interrupt timer to
**               see if we need to clear the old, stale RPM values.
** Inputs:       U8 - fan number (1-4).
** Outputs:      U16 - RPM value.
*******************************************************************************/
U16  get_fan_tach( U8 fan )
{
  U16 rpm;

  if ( fan == 1 )
  {
    if ( task_timer_done_check( FAN1_TACH_IC_INTR ))
    {
      fan_tach[0].rpm_tach = 0;  // no tach interrupts lately, so report RPM=0
    }
    /* Error check - noise coupled on the fan tach line from the TEC PWM drive
    ** can cause tach readings around 35,000 RPM.  Limit the values to a max of
    ** 4800, since that is the rated speed at 24VDC.  Note - the coupled noise
    ** does not affect the fan operation, just the tach calculations.  Also,
    ** this check uses the Sonendo fan info. */
    if ( fan_tach[0].rpm_tach > MAX_RPM_XYW_BH )
    {
      fan_tach[0].rpm_tach = MAX_RPM_XYW_BH;
    }
    rpm = fan_tach[0].rpm_tach;
  }
  else if ( fan == 2 )
  {
    if ( task_timer_done_check( FAN2_TACH_IC_INTR ))
    {
      fan_tach[1].rpm_tach = 0;  // no tach interrupts lately, so report RPM=0
    }
    /* Error check - same as above. */
    if ( fan_tach[1].rpm_tach > MAX_RPM_XYW_BH )
    {
      fan_tach[1].rpm_tach = MAX_RPM_XYW_BH;
    }
    rpm = fan_tach[1].rpm_tach;
  }
  else
  {
    rpm = 0;  // only 2 fans for now...
  }
  return  rpm;

}  // end get_fan_tach()

/*******************************************************************************
** Function:     fan_init
** Description:  Set up the GPIO pins used for fan control.  See the pwm.h
**               module for the correlation of fan numbers and timer control
**               channels.
**               IMPORTANT NOTE:  Due to a hardware buffer circuit snafu (Tony!)
**               the PWM buffer enable pins must be left low (low to enable,
**               high to disable).  High disables the buffer, but the PWM drive
**               output will still allow the fans to turn full on!
** Inputs:       pwm output fan channel (U32), and ON/OFF.
** Outputs:
*******************************************************************************/
void  fan_init( void )
{

  MX_TIM1_Init();  // FAN pwm
  MX_TIM3_Init();  // FAN tach

  /* Leave the enable low all the time, (see description above), and use the
  ** PWM duty control to turn fans on/off.  There is a pull-down on the fan
  ** enable line, so the output may glitch at power-up/reset, but this is
  ** usually too quick to cause any problems with fan operation. */
  HAL_GPIO_WritePin( FAN1_BUF_nOE_GPIO_Port, FAN1_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN2_BUF_nOE_GPIO_Port, FAN2_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN3_BUF_nOE_GPIO_Port, FAN3_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN4_BUF_nOE_GPIO_Port, FAN4_BUF_nOE_Pin, GPIO_PIN_RESET );

  /* Init the variables used for fan tachometer monitor & rpm compute.
  ** We are only using 2 fans for ISC, (one for Sonendo), so just set up 2.
  ** For tach values, FAN1 (outside, index=0), and FAN2 (inside, index=1). */
  for ( U8 i = 0; i < 2; i++ )
  {
    fan_tach[i].in_capture1  = 0;
    fan_tach[i].in_capture2  = 0;
    fan_tach[i].diff_capture = 0;
    fan_tach[i].rpm_tach     = 0;
    fan_tach[i].capture_idx  = 0;

    fan_speed[i] = FAN_SPEED_OFF;
  }

}  // end fan_init()

/*******************************************************************************
** Function:     check_fan_error
** Description:  Checks if fan RPM value is below threshold.
**               Only check fan 1 for now.  Eventually, we will have config
**               setting to tell us how many fans are active.
**               As of 02/2019, we have to reset the controller to clear the
**               error. This is OK, since the typical error is a loose or
**               missing fan connect, or a fan blade blockage,
** Inputs:       ,
** Outputs:      .
*******************************************************************************/
void  check_fan_error( void )
{
  static U16 wait_time = 0;
  static U16 rpm_sample[4] = {0};     // hold 4 inputs for averaging
  static U8  fan_error_trigger = NO;  // flag indicates an error found
  static U8  index = 0;               // array index for averaging
  U32 sample_total;

  /* The fan should be on all the time, both for the single Sonendo fan, and
  ** the inside fan for ISC.  Need to wait after the initial start fan command
  ** to allow for spin-up time.  The RPM may vary with PWM changes, so get a
  ** few readings to average. */
  if ( ++wait_time > 12000 )
  {
    rpm_sample[index] = get_fan_tach( 1 );
    if ( ++index > 3 )
    {
      index = 0;
      sample_total = rpm_sample[0] + rpm_sample[1] + rpm_sample[2] + rpm_sample[3];
      sample_total = sample_total >> 2;  // divide by 4 to get average

      /* Use 800 as a low threshold for the averaged RPM (tach) value. */
      if (( sample_total < 800 ) && ( fan_error_trigger == NO ))
      {
        fan_error_trigger = YES;
        led_setup( MEMB_RED, LED_BLINK, 500, 500, FOREVER );
        ctrl_mode_state( ERROR_MODE, SET_DATA );
        error_bit_ctrl( SET_ERROR_BIT, FAN_1_FAIL );
      }
    }
    wait_time = 11500;  // reset count to check again in about 500mSec...
  }

}  // end check_fan_error()

/*******************************************************************************
** Function:     MX_TIM1_Init
** Description:  Initialize the timer used for the fans - PWM drive output.
**               Up to 4 fans can be used on the 221-0144 hardware.
**               See pwm.h for table of fan numbers to board ref. des.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void MX_TIM1_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = preScale24KHz;  // recommended fan pwm frequency
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = PERIOD_VALUE;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* We will preset a duty cycle here, but normally, this is set in the
  ** fan_ctrl function.  Note that the FAN3 and FAN4 may be used as an external
  ** LED control output, and the duty cycle will affect brightness. */
  set_fan_duty_cycle( FAN1_CH, 50 );  // outside fan (J15) hot side
  set_fan_duty_cycle( FAN3_CH, 50 );  // external LED for Sonendo
  set_fan_duty_cycle( FAN4_CH, 50 );  // external LED for Sonendo
  set_fan_duty_cycle( FAN2_CH, 50 );  // inside fan (J18) cold side

  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;  // this should be OK for fans...
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim1);

}  // end MX_TIM1_Init()

/*******************************************************************************
** Function:     MX_TIM3_Init
** Description:  Initialize the timer used for the fan tachometer input.
**               There are up to 4 fans available on the 221-0144 board.
**               NOTE: the prescaler value was chosen to give us the proper
**               clock frequency to measure 25Hz to 250Hz signals, which will
**               translate to 750 to 7500 RPM.  This value allows us to use the
**               clock value to directly calculate the RPM value in the
**               interrupt callback function.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
static void MX_TIM3_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 29;  // see note in description...
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 0xFFFF;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* Start the Input Capture in interrupt mode.  (Outside fan for ISC). */
  if(HAL_TIM_IC_Start_IT(&htim3, FAN1_CH) != HAL_OK)
  {
    Error_Handler();  // Starting Error
  }

  /* Start the Input Capture in interrupt mode.  (Inside fan for ISC). */
  if(HAL_TIM_IC_Start_IT(&htim3, FAN2_CH) != HAL_OK)
  {
    Error_Handler();  // Starting Error
  }

}  // end MX_TIM3_Init()


/*******************************************************************************
** Function:     HAL_TIM_IC_CaptureCallback
** Description:  Conversion complete callback in non blocking mode.
**               The fans give 2 pulses per revolution, so the basic formula is
**               to multiply the input Hz (cycles per second) value by 60 to
**               get RPM (revs per minute), and divide by 2 for pulse/rev.
**               The calc for .rpm_tach below gives us the correct RPM value.
**               NOTE: We need the fan tach task timer, because once the
**               interrupts stop, we're stuck with the old value of .rpm_tach.
**               If no interrupts have been detected in over 1 second, we will
**               consider the fans stopped, and then we can manually reset the
**               .rpm_tach values.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void HAL_TIM_IC_CaptureCallback( TIM_HandleTypeDef *htim )
{

  if ( htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1 )  // fan 1 channel
  {
    /* NOTE: structure index for fan 1 is 0. */
    if ( fan_tach[0].capture_idx == 0 )
    {
      /* Get the 1st Input Capture value */
      fan_tach[0].in_capture1 = HAL_TIM_ReadCapturedValue( htim, FAN1_CH );
      fan_tach[0].capture_idx = 1;
    }
    else if ( fan_tach[0].capture_idx == 1 )
    {
      /* Get the 2nd Input Capture value */
      fan_tach[0].in_capture2 = HAL_TIM_ReadCapturedValue( htim, FAN1_CH );

      /* Capture computation */
      if ( fan_tach[0].in_capture2 > fan_tach[0].in_capture1 )
      {
        fan_tach[0].diff_capture = ( fan_tach[0].in_capture2 - fan_tach[0].in_capture1 );
      }
      else if ( fan_tach[0].in_capture2 < fan_tach[0].in_capture1 )
      {
        /* 0xFFFF is max TIM1_CCRx value */
        fan_tach[0].diff_capture = (( 0xFFFF - fan_tach[0].in_capture1 ) + fan_tach[0].in_capture2 ) + 1;
      }
      else
      {
        /* Capture values are equal; reached the limit of frequency measures */
        Error_Handler();
      }
      /* RPM computation: based on prescaler value and clock APB1Clk. */
      fan_tach[0].rpm_tach = HAL_RCC_GetPCLK1Freq() / fan_tach[0].diff_capture;
      fan_tach[0].capture_idx = 0;
    }
    task_timer_start( FAN1_TACH_IC_INTR, 1000, ONE_SHOT );  // see note in description...
  }

  if ( htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4 )  // fan 2 channel - remember re-ordering!
  {
    /* NOTE: structure index for fan 2 is 1. */
    if ( fan_tach[1].capture_idx == 0 )
    {
      /* Get the 1st Input Capture value */
      fan_tach[1].in_capture1 = HAL_TIM_ReadCapturedValue( htim, FAN2_CH );
      fan_tach[1].capture_idx = 1;
    }
    else if ( fan_tach[1].capture_idx == 1 )
    {
      /* Get the 2nd Input Capture value */
      fan_tach[1].in_capture2 = HAL_TIM_ReadCapturedValue( htim, FAN2_CH );

      /* Capture computation */
      if ( fan_tach[1].in_capture2 > fan_tach[1].in_capture1 )
      {
        fan_tach[1].diff_capture = ( fan_tach[1].in_capture2 - fan_tach[1].in_capture1 );
      }
      else if ( fan_tach[1].in_capture2 < fan_tach[1].in_capture1 )
      {
        /* 0xFFFF is max TIM1_CCRx value */
        fan_tach[1].diff_capture = (( 0xFFFF - fan_tach[1].in_capture1 ) + fan_tach[1].in_capture2 ) + 1;
      }
      else
      {
        /* Capture values are equal; reached the limit of frequency measures */
        Error_Handler();
      }
      /* RPM computation: based on prescaler value and clock APB1Clk. */
      fan_tach[1].rpm_tach = HAL_RCC_GetPCLK1Freq() / fan_tach[1].diff_capture;
      fan_tach[1].capture_idx = 0;
    }
    task_timer_start( FAN2_TACH_IC_INTR, 1000, ONE_SHOT );  // see note in description
  }
}  // end HAL_TIM_IC_CaptureCallback()

/* fans.c *************************************************************** EOF */
