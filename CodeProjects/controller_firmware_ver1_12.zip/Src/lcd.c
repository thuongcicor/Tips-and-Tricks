/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    lcd.c
**
** Description: Functions related to the LCD module (alphanumeric, 8-bit
**              parallel, 2X16).  This module uses the standard HD44780
**              controller chip and command set.  Used in write-only mode,
**              due to the hardware (see schematic 221-0145).
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/03/2019  Update text string for year "2019".  Mods for SPH and
**                       SPL using floats instead of x10 int values.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "lcd.h"
#include "adc.h"
#include "gpio.h"
#include "pwm.h"
#include "beep.h"
#include "keys.h"
#include "versions.h"
#include "config.h"
#include "eeprom.h"
#include <string.h>

/*                                   1........10....16  (position reference) */
const char  VERSION_STR[]         = " FW ver. ";
/* Scrolling II-VI splash text (copyright symbol in pos[0] added later). */
const char  II_VI_SPLASH_SCREEN[]  = "II-VI Incorporated";  // 20 chars total (scrolling msg)
const char  II_VI_SPLASH_SCREEN1[] = "  2019 II-VI ";  // leave space for copyright in pos[0]
const char  II_VI_SPLASH_SCREEN2[] = "  Incorporated";
const char  CTRL_SPH_TEMP_TEXT[]   = "SP High: ";
const char  CTRL_SPL_TEMP_TEXT[]   = "SP Low:  ";
const char  SPH_SPL_TEXT[]         = "SP H/L: ";
const char  CURRENT_TEMP_TEXT[]    = "Sensor: ";

static  lcd_ctrl_t  lcd_controls;  // declare struct for LCD control variables

/*******************************************************************************
** Function:     lcd_init
** Description:  Initialize the LCD module.
**               Due to the relatively long delays required between commands,
**               this function will be called multiple times from the main init
**               loop.  This will give the necessary delay between each command
**               write.  The first command should be issued after at least
**               40mSec from power-up.  Also, it is recommended that the reset
**               command be repeated at this init stage.  This func issues the
**               reset command 3 times.
** Inputs:       RESET or CONTINUE.
** Outputs:      DONE or NOT_DONE.
*******************************************************************************/
lcd_t lcd_init( lcd_t operation )
{
  static lcd_t  lcd_init_sequence = LCD_START;
  static U8     lcd_init_sequence_cnt = 0;

  HAL_Delay(40);  // make sure we've waited long enough since power-up...

  /* Guard check.  Reset to initial conditions.  OK to fall thru to next if. */
  if ( operation == LCD_RESET )
  {
    lcd_init_sequence = LCD_START;
    lcd_init_sequence_cnt = 0;
  }

  if ( lcd_init_sequence == LCD_START )
  {
    /* Leave RW pin low always! No reads are done on the lCD module. */
    HAL_GPIO_WritePin( LCD_RW_GPIO_Port, LCD_RW_Pin, GPIO_PIN_RESET );
    lcd_init_sequence_cnt = 0;
    lcd_init_sequence = LCD_NOT_DONE;
  }
  /* OK to fall thru to here - we'll skip the above part after the 1st pass. */
  if ( lcd_init_sequence == LCD_NOT_DONE )
  {
    switch ( lcd_init_sequence_cnt )
    {
      case 1:
        LCD_Write( LCD_CMND, 0x38 );  // function set - 8-bit, 2 lines, 5x8 dots
        break;

      case 2:
        LCD_Write( LCD_CMND, 0x38 );  // command reset
        break;

      case 3:
        LCD_Write( LCD_CMND, 0x38 );  // command reset
        break;

      case 4:
        LCD_Write( LCD_CMND, 0x06 );  // command clear
        break;

      case 5:
        LCD_Write( LCD_CMND, 0x0C );  // command clear
        break;

      case 6:
        LCD_Write( LCD_CMND, 0x01 );  // command clear display (takes 1.53mSec)
        break;

      case 7:
        /* Done with the module setup portion of the init sequence.  We can now
        ** init the scrolling display array for use during idle mode. */
        load_display_array_for_scroll( );
        lcd_init_sequence = LCD_DONE;
        break;

      default:
        break;
    }  // end switch

    ++lcd_init_sequence_cnt;
  }

  scrolling_set( ON );
  display_busy_set( NO );
  set_manual_ok_to_start_flag( NO );

  return lcd_init_sequence;

}  // end lcd_init()

/*******************************************************************************
** Function:     splash_screen
** Description:  Display the intial LCD splash screen.  Only performed during
**               initialization, so some delays OK.
** Inputs:       full or quick, (for ISC PWR-OFF to ON).
** Outputs:      none.
*******************************************************************************/
void  splash_screen( U8 option )
{
  static lcd_t lcd_splash_status = LCD_START;
  char temp_str[17];  // big enough to hold the longest LCD message
  U32   delay;

  LCD_Write( LCD_CMND, LCD_CLEAR );  // clear display (takes 1.53mSec)
  HAL_Delay(2);

  /* Don't do the scrolling message... instead display top and bottom lines for
  ** the legal copyright notice (no scroll). */
//  screen_shift_left( );  // puts the scroll text together and sends to LCD

  /* Display top line and include the copyright symbol in string position 0. */
  strcpy( temp_str, II_VI_SPLASH_SCREEN1 );
  temp_str[0] = LOAD_CGRAM_3;  // copyright symbol CGRAM location
  do
  {
    lcd_splash_status = send_lcd_message( temp_str, LCD_LINE1 );
  }
  while ( lcd_splash_status == LCD_NOT_DONE );

  /* Display the bottom line for the user. */
  strcpy( temp_str, II_VI_SPLASH_SCREEN2 );
  do
  {
    lcd_splash_status = send_lcd_message( temp_str, LCD_LINE2 );
  }
  while ( lcd_splash_status == LCD_NOT_DONE );

  /* If beeper was started (example; for ISC power-on), then turn it off after
  ** about 250 mSec (give-or-take). */
  HAL_Delay( 250 );
  audio_pwm_on_off( OFF );

  /* Now compute the rest of the display delay... */
  if ( option == SPLASH_FULL )
  {
    delay = 3125 - 250;
  }
  else
  {
    delay = 2250 - 250;
  }
  HAL_Delay( delay );  // delay to view initial copyright message screen

  setup_LCD( LCD_CLEAR, 0 );  // reset LCD module

  /* Put the firmware version info together and display on line 2. */
  strcpy( temp_str, VERSION_STR );
  strcat( temp_str, str_(MAJOR_VER_NUM) );
  strcat( temp_str, str_(NUM_SEPARATOR) );
  strcat( temp_str, str_(MINOR_VER_NUM) );
  do
  {
    lcd_splash_status = send_lcd_message( temp_str, LCD_LINE1 );
  }
  while ( lcd_splash_status == LCD_NOT_DONE );

  /* Only need this extra delay for the "fast" option, (used in ISC after
  ** power-on).  Otherwise, the initial_tasks will handle the delay. */
  if ( option == SPLASH_FAST )
  {
    HAL_Delay( delay + 300 );  // delay to view firmware version message screen
  }

}  // end splash_screen()

/*******************************************************************************
** Function:     send_lcd_message
** Description:  Send each character to the display. Display setup (init) is
**               complete before calling this function.  Due to the timing
**               involved, write a single character during each pass thru this
**               routine - the program will continue to call this function until
**               the "DONE" flag is returned.  Also, right to left scrolling is
**               performed on strings longer than 16 characters.
** Inputs:       char display string, line number.
** Outputs:      DONE or NOT_DONE.
*******************************************************************************/
lcd_t send_lcd_message( char * str, U8 line )
{
  static lcd_t  lcd_write_sequence = LCD_START;
  static U8     pos = 0;  // buffer (string) position
  U8            len = strlen( str );
  U8            first_pos;  // left-most position on line1 or line2
  lcd_t         rtn_val = LCD_NOT_DONE;  // default state

  if ( lcd_write_sequence == LCD_START )
  {
    lcd_write_sequence = LCD_NOT_DONE;  // return value & sequence the same here
    /* Set the display to the first position on either line 1 or line 2. */
    first_pos = ( line == LCD_LINE1 ) ? LCD_LINE1_HOME : LCD_LINE2_HOME;
    setup_LCD( LCD_MOVETO, first_pos );
    pos = 0;
  }
  else if ( lcd_write_sequence == LCD_NOT_DONE )
  {
    if ( pos >= len )
    {
      /* We're done, but reset the sequence for the next message. */
      rtn_val = LCD_DONE;
      lcd_write_sequence = LCD_START;
    }
    else
    {
      LCD_Write( LCD_DATA, str[pos++] );  // send data to LCD

      /* Scroll the text if we have passed the screen limit of 16 chars. */
      if ( pos > 16 )
      {
        LCD_Write( LCD_CMND, 0x18 );      // scroll from right to left
        small_delay( DELAY_40uSEC );
      }
    }
  }
  else
  {
    rtn_val = LCD_DONE;  // should not arrive here...
  }

  return  rtn_val;

}  // end send_lcd_message()

/*******************************************************************************
** Function:     screen_shift_left
** Description:  Display the line of LCD data, starting with the first character
**               in the rightmost display position, and shifting one character
**               position each time.  The original string holds the text that
**               the final display will show, along with 16 extra chars so that
**               the text will shift-off the display on the left, while shifting
**               space chars in on the right.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  screen_shift_left( void )
{
  lcd_t lcd_splash_status;
  char  str1[22 + 16];  // holds original message data string + 16 extra
  U8    shift_len;
  U8    x1;

  /* Load the copyright symbol and add a space, (reason for the "+ 2" below),
  ** and then add in the rest of the text. The extra 16 bytes account for the
  ** scroll-off-screen space chars. */
  str1[0] = LOAD_CGRAM_3;  // copyright symbol CGRAM location
  str1[1] = SPACE_CHAR;    // space after the copyright symbol
  shift_len = strlen( II_VI_SPLASH_SCREEN );
  /* Now add in the text for the scroll message. */
  for ( x1 = 0; x1 < shift_len + 16; ++x1 )
  {
    if ( x1 < shift_len )
    {
      str1[x1 + 2] = II_VI_SPLASH_SCREEN[x1];
    }
    else
    {
      str1[x1 + 2] = SPACE_CHAR;
    }
  }  // end for
  str1[x1 + 2] = NULL;  // terminate string

  do
  {
    lcd_splash_status = send_lcd_message( str1, LCD_LINE1 );
    HAL_Delay( 250 );  // this is the freeze screen time while shifting
  }
  while ( lcd_splash_status == LCD_NOT_DONE );

}  // end screen_shift_left()

/*******************************************************************************
** Function:     setup_LCD
** Description:  Set the display for the following:
**               1. Clear both display lines and move cursor to line 1, position 1.
**               2. Move cursor to line 1, position 1 without clearing.
**               3. Set current display position to line 1 or 2, at position X.
**               Note - parameter "pos" is a don't care for commands LCD_CLEAR
**               and LCD_HOME.
** Inputs:       command code (U8), LCD character position (U8)
** Outputs:      none
*******************************************************************************/
void setup_LCD( U8 cmnd, U8 pos )
{

  switch ( cmnd )
  {
    case LCD_CLEAR:
      /* Clear entire display and reset cursor to home position (1.53mSec). */
      LCD_Write( LCD_CMND, LCD_CLEAR );
      HAL_Delay(2);
      break;

    case LCD_HOME:
      /* Return cursor to home position without clearing display (1.53mSec). */
      LCD_Write( LCD_CMND, LCD_HOME );
      HAL_Delay(2);
      break;

    case LCD_MOVETO:
      /* Move cursor position - see character position info in lcd.h (39uSec). */
      LCD_Write( LCD_CMND, 0x80 + pos );
      HAL_Delay(1);
      break;

    default:
      break;

  }  // end switch

}  // end setup_LCD()

/*******************************************************************************
** Function:     clear_line
** Description:  Clear the specified LCD line (top=1, bottom=2).  Fill the line
**               with space characters, (0x20 or " ").  Return cursor position
**               to the first position on the cleared line.
** Inputs:       U8 - line number, 1 or 2
** Outputs:      none
*******************************************************************************/
void  clear_line( U8 line )
{
  char  tmp_str[17];  // holds the line data string + NULL
  lcd_t lcd_status;
  U8    pos;

  /* Set LCD command code for (DDRAM address, set bit 0x80), and or in the
  ** address for 1st position line 1 or line 2. */
  pos = ( line == 1 ) ? 0x80 + LCD_LINE1_HOME : 0x80 + LCD_LINE2_HOME;

  /* Load spaces in string array, and set position 1 on selected line. */
  memset( tmp_str, SPACE_CHAR, strlen( tmp_str ));
  LCD_Write( LCD_CMND, pos );
  HAL_Delay(1);
  do
  {
    lcd_status = send_lcd_message( tmp_str, line );
  }
  while ( lcd_status == LCD_NOT_DONE );

  /* Reset cursor position to start of line. */
  LCD_Write( LCD_CMND, pos );
  HAL_Delay(1);

}  // end clear_line()

/*******************************************************************************
** Function:     LCD_Write
** Description:  Set up the command (RS=0) or data (RS=1) to send to the LCD.
**               Note that we always write to LCD, never read. So the R/~W line
**               is always low.  The timing must be observed between LCD write
**               operations, so this scheme will give us the time required.
** Inputs:       data byte to send to LCD (U8), register select (U8)
** Outputs:      none
*******************************************************************************/
void LCD_Write( lcd_t rs, U8 db )
{

  if ( rs == LCD_CMND )
  {
    /* Set RS (register select) line on the LCD low (0) for commands. */
    HAL_GPIO_WritePin( LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_RESET );
  }
  else
  {
    /* Set RS (register select) line on the LCD high (1) for data. */
    HAL_GPIO_WritePin( LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_SET );
  }
  small_delay( DELAY_20uSEC );

  /* Set the E (LCD module enable) high (1). */
  HAL_GPIO_WritePin( LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_SET );
  small_delay( DELAY_12uSEC );

  /* Set up the 8-bit parallel data bus on LCD. */
  LCD_Data_Bits_Set( db );
  small_delay( DELAY_20uSEC );

  /* Set the E (LCD module enable) low to latch data in the module. */
  HAL_GPIO_WritePin( LCD_EN_GPIO_Port, LCD_EN_Pin, GPIO_PIN_RESET );

}  // end LCD_Write()

/*******************************************************************************
** Function:     LCD_Data_Bits_Set
** Description:  The LCD module has an 8-bit parallel data bus, and is driven
**               with 8 GPIO pins from the micro.  This function simply sets
**               the state of each output GPIO bit for each byte of data to be
**               sent (written) to the module.
** Inputs:       data byte to send to LCD (U8)
** Outputs:      none
*******************************************************************************/
void LCD_Data_Bits_Set( U8 dByte )
{
  GPIO_PinState bit_on_off;

  /* Set the 8 output data bits (DB0 - DB7) going to the LCD module. */
  bit_on_off = ( dByte & BIT0_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB0_GPIO_Port, LCD_DB0_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT1_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB1_GPIO_Port, LCD_DB1_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT2_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB2_GPIO_Port, LCD_DB2_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT3_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB3_GPIO_Port, LCD_DB3_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT4_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB4_GPIO_Port, LCD_DB4_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT5_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB5_GPIO_Port, LCD_DB5_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT6_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB6_GPIO_Port, LCD_DB6_Pin, bit_on_off );

  bit_on_off = ( dByte & BIT7_MASK ) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  HAL_GPIO_WritePin( LCD_DB7_GPIO_Port, LCD_DB7_Pin, bit_on_off );

}  // end LCD_Data_Bits_Set()

/*******************************************************************************
** Function:     scrolling_set
** Description:  Sets the current LCD scrolling control enable/disable.
** Inputs:       lcd_controls.scroll (1=enable, 0=disable)
** Outputs:      -none-
*******************************************************************************/
void  scrolling_set( BOOL scroll_on_off )
{

  lcd_controls.scroll = scroll_on_off;

}  // end scrolling_set()

/*******************************************************************************
** Function:     scrolling_get
** Description:  Returns the current setting for the scrolling mode.
** Inputs:       -none-
** Outputs:      lcd_controls.scroll (1=enable, 0=disable)
*******************************************************************************/
BOOL  scrolling_get( void )
{

  return  lcd_controls.scroll;

}  // end scrolling_get()

/*******************************************************************************
** Function:     display_busy_set
** Description:  Sets the current LCD busy/not busy flag.  If busy, for example,
**               when the "Values Set..." message is being displayed for some
**               time, then no further display updates take place until after
**               this time expires.
** Inputs:       lcd_controls.display_busy (YES, NO)
** Outputs:      -none-
*******************************************************************************/
void  display_busy_set( BOOL busyflag )
{

  lcd_controls.display_busy = busyflag;

}  // end display_busy_set()

/*******************************************************************************
** Function:     display_busy_get
** Description:  Returns the current value for the LCD busy/not busy flag.
** Inputs:       -none-
** Outputs:      lcd_controls.display_busy (YES, NO)
*******************************************************************************/
BOOL  display_busy_get( void )
{

  return  lcd_controls.display_busy;

}  // end display_busy_get()

/*******************************************************************************
** Function:     set_manual_ok_to_start_flag
** Description:  Sets the flag for the "OK to start normal operation in manual
**               startup mode".
** Inputs:       lcd_controls.ok_to_start (1=yes, 0=no)
** Outputs:      -none-
*******************************************************************************/
void  set_manual_ok_to_start_flag( BOOL ok2startyesno )
{

  lcd_controls.ok_to_start = ok2startyesno;

}  // end set_manual_ok_to_start_flag()

/*******************************************************************************
** Function:     get_manual_ok_to_start_flag
** Description:  Returns the current setting for the "OK to start normal
**               operation in manual startup mode" flag.
** Inputs:       -none-
** Outputs:      lcd_controls.ok_to_start (1=yes, 0=no)
*******************************************************************************/
BOOL  get_manual_ok_to_start_flag( void )
{

  return  lcd_controls.ok_to_start;

}  // end get_manual_ok_to_start_flag()

/*******************************************************************************
** Function:     lcd_backlight_control
** Description:  Low-level driver to turn the LCD module backlight on or off.
** Inputs:       bool, ON or OFF.
** Outputs:      .
*******************************************************************************/
void  lcd_backlight_control( BOOL onoff )
{

  if ( onoff == ON )
  {
    HAL_GPIO_WritePin( LCD_BKLT_EN_GPIO_Port, LCD_BKLT_EN_Pin, GPIO_PIN_SET );
  }
  else
  {
    HAL_GPIO_WritePin( LCD_BKLT_EN_GPIO_Port, LCD_BKLT_EN_Pin, GPIO_PIN_RESET );
  }

}  // end lcd_backlight_control()

/*******************************************************************************
** Function:     update_display_events
** Description:  Called periodically (approx. 1mSec) from the main task super
**               loop.  This function will coordinate the display functions by
**               time-slicing the LCD update activity, since it's relatively
**               slow to update.  We only need to update the display about every
**               1.5 seconds.
**               Leave a few cycles between each display phase section...
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
void  update_display_events( void )
{
  static  char     lcd_line[16];
  static  F32      spH;
  static  F32      spL;
  static  U16      display_phase = 0;  // used to space out update sections
  static  U8       tu;                 // temperature units
          F32      sensor;
          char     t_str[6];
          lcd_t    display_status;

  op_ctrl_states_t cm = ctrl_mode_state( NONE, GET_DATA );  // current control mode

  /* No display updates needed if:
  ** > Sonendo control (no display),
  ** > in power off mode (either in manual or auto start),
  ** > in factory test mode, or completed (pass or fail),
  ** > LCD is busy with "Values saved..." message,
  ** > in manual start mode and not ready to display,
  ** > keys IN_PROCESS for menu activity.  */
  if (( board_cfg_get( ) == SONENDO_CONTROL )                ||
      ( cm == PWR_OFF_MODE )   || ( cm == TEST_MODE_ACTIVE ) ||
      ( cm == TEST_MODE_PASS ) || ( cm == TEST_MODE_FAIL )   ||
      ( get_pushbutton_mode( PB_ALL ) == IN_PROCESS )        ||
      ( display_busy_get( ) == YES )                         ||
      ( get_manual_ok_to_start_flag( ) == NO ))
  {
    /* Reset in case PWR button pressed in the middle of display update. */
    display_phase = 0;
    return;
  }

  if ( display_phase == 1 )
  {
    /* Get the temperature units we need for the display (1=F, 0=C). */
    tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
    if ( tu == DEGREES_F )
    {
      spH = get_sp_value( SPH_F );
      spL = get_sp_value( SPL_F );
    }
    else
    {
      spH = get_sp_value( SPH_C );
      spL = get_sp_value( SPL_C );
    }
    strcpy( lcd_line, SPH_SPL_TEXT );
  }
  else if ( display_phase == 4 )
  {
    /* The high setpoint can have up to three digits, (max of 104 degrees F).
    ** Just display whole numbers, so some rounding may be needed. */
    sprintf( t_str, "%3.0f", spH );
    strcat( lcd_line, t_str );  // space for 3 temperature digits
    strcat( lcd_line, "/" );    // separator for high/low values
  }
  else if ( display_phase == 7 )
  {
    /* The low setpoint can have one or two digits,
    ** Just display whole numbers, so some rounding may be needed. */
    sprintf( t_str, "%2.0f", spL );
    strcat( lcd_line, t_str );  // space for 2 temperature digits
    strcat( lcd_line, " " );    // space separator
  }
  else if ( display_phase == 8 )
  {
    /* Reset and clear LCD module, and display top line characters. */
    setup_LCD( LCD_CLEAR, 0 );  // reset and clear LCD module
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE1 );
    }
    while ( display_status == LCD_NOT_DONE );
  }
  else if ( display_phase == 9 )
  {
    setup_LCD( LCD_MOVETO, 0x0E );    // position (15) for compact temp symbol
    if ( tu == DEGREES_F )
    {
      LCD_Write( LCD_DATA, LOAD_CGRAM_7 );  // load the compact F symbol
    }
    else
    {
      LCD_Write( LCD_DATA, LOAD_CGRAM_6 );  // load the compact C symbol
    }
  }
  else if ( display_phase == 11 )
  {
    /* Create the 2nd text that remains static.  The temperature values will
    ** be added later - no need to re-create this display part every time. */
    strcpy( lcd_line, CURRENT_TEMP_TEXT );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE2 );
    }
    while ( display_status == LCD_NOT_DONE );

    /* Display sensor temperature - could be up to 5 chars, (4 digits + decimal
    ** point). Include the compact temperature symbol after digits. */
    sensor = get_current_temperature( 0, tu );
    sprintf( t_str, "%4.1f", sensor );
    setup_LCD( LCD_MOVETO, 0x49 );    // start position (10th) for t-digits
    LCD_Write( LCD_DATA, t_str[0] );
    LCD_Write( LCD_DATA, t_str[1] );
    LCD_Write( LCD_DATA, t_str[2] );
    LCD_Write( LCD_DATA, t_str[3] );
    /* If 4 digits + decimal point, e.g., 102.5, then show the last digit. */
    if ( strlen( t_str ) > 4 )
    {
      LCD_Write( LCD_DATA, t_str[4] );
    }
    if ( tu == DEGREES_F )
    {
      LCD_Write( LCD_DATA, LOAD_CGRAM_7 );  // load the compact F symbol
    }
    else
    {
      LCD_Write( LCD_DATA, LOAD_CGRAM_6 );  // load the compact C symbol
    }
  }

  if ( ++display_phase > 1500 )
  {
    display_phase = 0;  // reset after about 1.5 seconds
  }

}  // end update_display_events()

/*******************************************************************************
** Function:     small_delay
** Description:  Need a small delay for some intermediate LCD write operations,
**               on the order of a few microseconds.  With our 48MHz clock,
**               the scope measurements show about a 4 * val (uSec) value for
**               the total delay.  So val = 25 gives about a 100uSec delay.
** Inputs:       delay value (U8)
** Outputs:      none
*******************************************************************************/
void small_delay( U8 val )
{
  volatile U8 cnt;  // volatile to avoid optimizing out and compile warnings

  while ( val > 0 )
  {
    for ( cnt = 0; cnt < 10; ++cnt )
    {
      _NOP( );
    }
    val--;
  }  // end while

}  // end small_delay()

/* lcd.c **************************************************************** EOF */
