/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    keys.c
**
** Description: Functions associated with the pushbuttons (keys).
**              The current hardware configuration supports 4 pushbuttons;
**              ON/OFF (PWR), SET, UP and DOWN.
**
** Version/Author/Date/Description:
** 1   DMA   07/12/2018  Began coding.
** 2   DMA   02/22/2019  Numerous mods for checking control modes, and keypress
**                       timeout.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "gpio.h"
#include "project.h"
#include "keys.h"
#include "config.h"
#include "eeprom.h"
#include "beep.h"
#include "main.h"
#include "lcd.h"
#include "intrinsics.h"  // need for instrinsic __nop function

pb_struct_t   pb;        // declare struct for pushbutton control variables

/*******************************************************************************
** Function:     pb_init
** Description:  Set all structure elements for the pushbutton controls.
** Inputs:       U8 - flag for various clear actions.
** Outputs:      .
*******************************************************************************/
void pb_init( U8 action )
{
  if ( action == PB_SET_DONE )
  {
    /* Indicates the pushbutton action has completed, (SET has been pushed
    ** to save the entered value).
    ** Leave pb.state alone so that the debounce can complete normally. */
    pb.mode[PB_PWR]  = READY;
    pb.mode[PB_SET]  = READY;
    pb.mode[PB_DOWN] = READY;
    pb.mode[PB_UP]   = READY;
  }
  else
  {
    /* Loop thru list and init each pushbutton struct member. */
    for ( U8 i = 0; i < NUM_PB; ++i )
    {
      pb.mode[i]  = READY;     // pushbutton starts off in ready mode
      pb.state[i] = RELEASED;  // assume this for all buttons at init time
      pb.hold[i]  = 0;         // hold time (continuous button press) for repeating key
    }  // end for
    set_manual_entry_keys(  MANUAL_NO_KEYS_ALLOWED );
  }

  pb_clr_timeout( );  // clear the keypress timeout

}  // end pb_init()

/*******************************************************************************
** Function:     pb_clr_timeout
** Description:  Clears the pushbutton timeout value.  Usually done after the
**               keypress action has completed, and we do not need to wait for
**               a key timeout to tranistion to another mode.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void pb_clr_timeout( void )
{

  pb.key_timeout = 0;

}  // end pb_clr_timeout()

/*******************************************************************************
** Function:     get_manual_entry_keys
** Description:  Gets the flag value that allows all pushbutton keys while in
**               Manual start-up mode.
** Inputs:       .
** Outputs:      U8.
*******************************************************************************/
U8  get_manual_entry_keys( void )
{
  return  pb.manual_keys;

}  // end get_manual_entry_keys()

/*******************************************************************************
** Function:     set_manual_entry_keys
** Description:  Sets the flag to allow all pushbutton keys while in Manual
**               start-up mode.  (Initially, only the PB_PWR button is allowed,
**               and once this is pressed, the other keys are allowed).
** Inputs:       U8 - which key(s) are allowed
** Outputs:      .
*******************************************************************************/
void  set_manual_entry_keys( U8 mankey )
{

  pb.manual_keys = mankey;

}  // end set_manual_entry_keys()

/*******************************************************************************
** Function:     update_pb_events
** Description:  This function is called from the periodic task timer, every
**               1mSec,  One switch is checked each func call, so the same
**               switch is check on a 4mSec cycle.  Each switch is checked for:
**               1. complete debounce,
**               2. not currently pressed, and
**               3. the switch is active (READY, not disabled or previous
**                  action still in-process).
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  update_pb_events( void )
{
  static U8 check_this_key_now = PB_PWR;  // pushbutton values 0 - 3

  if ( check_this_key_now == PB_PWR )
  {
    /* Time to check for ON/OFF (PWR) keypress. */
    if ( debounce_switch( PB_PWR ) == ON )
    {
      if ( pb.hold[PB_PWR] < MAX_PB_HOLD_TIME )
      {
        pb.hold[PB_PWR]++;  // continuous keypress hold time
      }
      /* Was RELEASED, now PRESSED.  Check if keypress action is allowed,
      ** (lockout time is up), and set key states/modes. */
      if (( pb.state[PB_PWR] == RELEASED ) &&
          ( task_timer_done_check( PROCESS_TIME_PWR_KEY )))
      {
        keypress_actions( PB_PWR );
      }
    }
    else
    {
      if ( pb.state[PB_PWR] == PRESSED )
      {
        /* Was PRESSED, now RELEASED.  Set the lockout time for this key until
        ** the next key action is allowed. */
        task_timer_start( PROCESS_TIME_PWR_KEY, 500, ONE_SHOT );
        pb.state[PB_PWR] = RELEASED;
        pb.hold[PB_PWR] = 0;
      }
    }
  }

  if ( check_this_key_now == PB_SET )
  {
    /* Time to check for SET keypress. */
    if ( debounce_switch( PB_SET ) == ON )
    {
      if ( pb.hold[PB_SET] < MAX_PB_HOLD_TIME )
      {
        pb.hold[PB_SET]++;  // continuous keypress hold time
      }
      /* Was RELEASED, now PRESSED.  Check if keypress action is allowed
      ** (lockout time is up), and set key states/modes. */
      if (( pb.state[PB_SET] == RELEASED ) &&
          ( task_timer_done_check( PROCESS_TIME_SET_KEY )))
      {
        keypress_actions( PB_SET );
      }
    }
    else
    {
      if ( pb.state[PB_SET] == PRESSED )
      {
        /* Was PRESSED, now RELEASED.  Set the lockout time for this key until
        ** the next key action is allowed. */
        task_timer_start( PROCESS_TIME_SET_KEY, 500, ONE_SHOT );
        pb.state[PB_SET] = RELEASED;
        pb.hold[PB_SET] = 0;
      }
    }
  }

  if ( check_this_key_now == PB_DOWN )
  {
    if ( debounce_switch( PB_DOWN ) == ON )
    {
      if ( pb.hold[PB_DOWN] < MAX_PB_HOLD_TIME )
      {
        pb.hold[PB_DOWN]++;  // continuous keypress hold time
      }
      /* Was RELEASED, now PRESSED.  Check if keypress action is allowed
      ** (lockout time is up), and set key states/modes. */
      if (( pb.state[PB_DOWN] == RELEASED ) &&
          ( task_timer_done_check( PROCESS_TIME_DOWN_KEY )))
      {
        keypress_actions( PB_DOWN );
      }
    }
    else
    {
      if ( pb.state[PB_DOWN] == PRESSED )
      {
        /* Was PRESSED, now RELEASED.  Set the lockout time for this key until
        ** the next key action is allowed. */
        task_timer_start( PROCESS_TIME_DOWN_KEY, 500, ONE_SHOT );
        pb.state[PB_DOWN] = RELEASED;
        pb.hold[PB_DOWN] = 0;
      }
    }
  }

  if ( check_this_key_now == PB_UP )
  {
    if ( debounce_switch( PB_UP ) == ON )
    {
      if ( pb.hold[PB_UP] < MAX_PB_HOLD_TIME )
      {
        pb.hold[PB_UP]++;  // continuous keypress hold time
      }
      /* Was RELEASED, now PRESSED.  Check if keypress action is allowed
      ** (lockout time is up), and set key states/modes. */
      if (( pb.state[PB_UP] == RELEASED ) &&
          ( task_timer_done_check( PROCESS_TIME_UP_KEY )))
      {
        keypress_actions( PB_UP );
      }
    }
    else
    {
      if ( pb.state[PB_UP] == PRESSED )
      {
        /* Was PRESSED, now RELEASED.  Set the lockout time for this key until
        ** the next key action is allowed. */
        task_timer_start( PROCESS_TIME_UP_KEY, 500, ONE_SHOT );
        pb.state[PB_UP] = RELEASED;
        pb.hold[PB_UP] = 0;
      }
    }
  }

  if ( ++check_this_key_now >= NUM_PB )
  {
    check_this_key_now = PB_PWR;  // reset back to first pushbutton ID
  }

  /* Holding down the key combination (ON/OFF & SET) indicates we want to start
  ** factory test mode.  Else, perform the regular single keypress action. */
  if (( pb.hold[PB_PWR] == MAX_PB_HOLD_TIME ) &&
      ( pb.hold[PB_SET] == MAX_PB_HOLD_TIME ))
  {
    ctrl_mode_state( TEST_MODE_ACTIVE, SET_DATA );
    task_timer_start( PROCESS_TIME_PWR_KEY, 1500, ONE_SHOT );
    task_timer_start( PROCESS_TIME_SET_KEY, 1500, ONE_SHOT );
  }
  else
  {
    key_timeout_check( );
  }

}  // end update_pb_events()

/*******************************************************************************
** Function:     keypress_actions
** Description:  This function is called after any (allowed) key is pressed.
**               Start the beep, and check for multiple key presses.  The
**               specific menu/display action associated with the key is
**               performed.
** Inputs:       U8 - pushbutton key value, 0-3
** Outputs:      none
*******************************************************************************/
void  keypress_actions( U8 key )
{
//          U8  om_val;
          U8  man_key;
          op_ctrl_states_t  cm;

  /* Get operating mode, Manual or Auto start. */
//  om_val = (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 );
  /* Get allowed pushbutton keys, in case we are in manual start mode. */
  man_key = get_manual_entry_keys( );

//  {
    pb.ID = key;

//      if ( pb.mode[pb.ID] == READY )
//      {
        pb.state[pb.ID] = PRESSED;
        pb.mode[pb.ID]  = IN_PROCESS;
        pb.key_timeout  = KEY_TIMEOUT;
        /* If operating mode=Manual, only initially allow the ON/OFF (PB_PWR)
        ** key action. After this, allow the SET key.  Then other keys allowed.
        ** Auto mode allows all key press actions, because not in PWR_OFF_MODE
        ** in this case. */
        cm = ctrl_mode_state( NONE, GET_DATA );

        if (( cm != PWR_OFF_MODE ) ||
           (( cm == PWR_OFF_MODE ) && ( pb.ID == PB_PWR )) ||
           (( cm == PWR_OFF_MODE ) && ( man_key == MANUAL_SET_KEY_ALLOWED )))
        {
          beeper_trigger( );
          menu_process( pb.ID );   // menu/display action

//          pb.mode[pb.ID] = READY;  // key action done
        }
//      }
//  }

}  // end keypress_actions()

/*******************************************************************************
** Function:     get_pushbutton_id
** Description:  Returns the current pushbutton keypress ID.
** Inputs:       -none-
** Outputs:      U8 - key pushbutton ID value
*******************************************************************************/
U8  get_pushbutton_id( void )
{

  return  pb.ID;

}  // end get_pushbutton_id()

/*******************************************************************************
** Function:     get_pushbutton_mode
** Description:  Returns the current pushbutton keypress mode.
** Inputs:       U8 - specific key or all keys
** Outputs:      pb_mode_t (READY, NOT_READY, or IN_PROCESS)
*******************************************************************************/
pb_mode_t  get_pushbutton_mode( U8 key )
{
  pb_mode_t  rtn_val = READY;

  if ( key == PB_ALL )
  {
    /* Loop thru list and check for any pushbuttons that are IN_PROCESS or
    ** NOT_READY. */
    for ( U8 i = 0; i < NUM_PB; ++i )
    {
      if ( pb.mode[i] == IN_PROCESS )
      {
        rtn_val = IN_PROCESS;
      }
      else if ( pb.mode[i] == NOT_READY )
      {
        rtn_val = NOT_READY;
      }
      else
      {
        ;  // nothing here (yet)!
      }
    }  // end for

    return  rtn_val;       // the case for checking all of the pushbuttons
  }
  else
  {
    return  pb.mode[key];  // the case for an individual, specific pushbutton
  }

}  // end get_pushbutton_mode()

/*******************************************************************************
** Function:     key_timeout_check
** Description:  This function checks the key timeout value.  If a timeout is
**               detected, the action taken is defined in the control modes
**               structure.
** Inputs:       .
** Outputs:      none
*******************************************************************************/
void  key_timeout_check( void )
{
//  op_ctrl_states_t  cm;

  if ( pb.key_timeout > 0 )
  {
    if ( --pb.key_timeout == 0 )
    {

//         cm = ctrl_mode_state( NONE, GET_DATA );

//      /* If we're still in manual start mode, clear the LCD and turn the
//      ** backlight off. */
//      if ( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == MANUAL_MODE )
//      {
//        setup_LCD( LCD_CLEAR, 0 );
//        lcd_backlight_control( OFF );
//        led_on_off( MEMB_GREEN, OFF );
//        set_manual_ok_to_start_flag( NO );  // NO!! return to previous mode...
//      }
//
//      set_idle_mode( );   // turns scrolling back on (if enabled)
      pb_init( PB_ALL );  // reset pushbutton state/values
////      main_temp_display( 0 );   <--- NEED TO ADD A "RESET DISPLAY" FUNCTION AFTER TESTS IN ISC OPERATION MODE
      set_manual_entry_keys( MANUAL_NO_KEYS_ALLOWED );
//      // DO WE WANT TO GO TO RUN MODE IF A KEYTIMEOUT IN MANUAL MODE?
//      ctrl_mode_state( RUN_MODE, SET_DATA );  // combine this in the set_idle_mode() - but for now, ...
    }
  }

}  // end key_timeout_check()

/*******************************************************************************
** Function:     debounce_switch
** Description:  Debounce pushbutton switches, using a periodic timer to call
**               this function.  Integrator-style debouncer - if all collected
**               samples > DEBOUNCE_COUNT, switch is ON.  If all samples are 0,
**               switch is OFF.  Debounce 4 switches, one at a time.
**               0 - PWR_SW, power button
**               1 - SET_SW, set button
**               2 - DOWN_SW, down button
**               3 - UP_SW, up button
**               Debounce on both push and release portions of the actuation.
**               Each individual switch is called every 4mSecs, and the count
**               gives a debounce time of approximately 12 * 4mSec = 48mSec.
** Inputs:       U8 - input switch/button ID (0-3).
** Outputs:      U8 - output state of switch (ON or OFF), or ERROR.
*******************************************************************************/
U8 debounce_switch( U8 sw_id )
{
  static U8 sample_total[4]   = {0, 0, 0, 0};  // total accumulated bit samples
  static U8 switch_value[4]   = {0, 0, 0, 0};  // initial value - 0 is OFF
         U8 new_sw_value;                      // new input button read value

  if ( sw_id == PB_PWR )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_PWR_SW_GPIO_Port, MEMB_PWR_SW_Pin );
  }
  else if ( sw_id == PB_SET )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_SET_SW_GPIO_Port, MEMB_SET_SW_Pin );
  }
  else if ( sw_id == PB_DOWN )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_D_ARR_SW_GPIO_Port, MEMB_D_ARR_SW_Pin );
  }
  else if ( sw_id == PB_UP )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_U_ARR_SW_GPIO_Port, MEMB_U_ARR_SW_Pin );
  }
  else
  {
    return  SW_ID_ERROR;  // error - we only have 4 switches (0-3)!
  }

  /* Add to the integrator total if input=1, else subtract from the total. */
  if ( new_sw_value )
  {
    if ( sample_total[sw_id] < DEBOUNCE_COUNT )
    {
      sample_total[sw_id]++;
    }
  }
  else
  {
    if ( sample_total[sw_id] > 0 )
    {
      sample_total[sw_id]--;
    }
  }

  /* Determine if switch is ON, OFF or in-between (bouncing). */
  if ( sample_total[sw_id] == 0 )
  {
    switch_value[sw_id] = OFF;
  }
  else if ( sample_total[sw_id] == DEBOUNCE_COUNT )
  {
    switch_value[sw_id] = ON;
  }
  else
  {
    _NOP( );  // switch is bouncing - don't change previous switch result
  }

  return  switch_value[sw_id];

}  // end debounce_switch()

/* keys.c *************************************************************** EOF */
