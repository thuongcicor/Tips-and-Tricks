/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    lcd_special.c
**
** Description: This module handles the user generated "special" images created
**              for the LCD module.  The module can store up to 8 user-created
**              images in the CGRAM of the HD44780. Each image consists of 8
**              bytes that define each row of the 5X8 pixel arrangement.  Note
**              that each byte only uses the 5 lower bits for each row.  We can
**              use the full 5X8, instead of 5X7, since we are not planning on
**              using the lower row as a cursor.
**
** Version/Author/Date/Description:
** 1   DMA   02/13/2018  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "lcd.h"
#include "gpio.h"

char  display_array[16];  // display characters for idle scrolling screens

/* The first 8 default images listed here will be the starting point to load
** into CGRAM. To simply coding, we can arrange the image bytes as a continuous
** array, since the internal HD44780 address counter will auto-increment. */
const U8 lcd_special_default_images[64] =
{
    0x0C,    //  .##..   row 1   temperature degree symbol - CGRAM (0)
    0x12,    //  #..#.   row 2
    0x12,    //  #..#.   row 3
    0x0C,    //  .##..   row 4
    0x00,    //  .....   row 5
    0x00,    //  .....   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8

    0x04,    //  ..#..   row 1   up arrow - CGRAM (1)
    0x0E,    //  .###.   row 2
    0x15,    //  #.#.#   row 3
    0x04,    //  ..#..   row 4
    0x04,    //  ..#..   row 5
    0x04,    //  ..#..   row 6
    0x04,    //  ..#..   row 7
    0x04,    //  ..#..   row 8

    0x04,    //  ..#..   row 1   down arrow - CGRAM (2)
    0x04,    //  ..#..   row 2
    0x04,    //  ..#..   row 3
    0x04,    //  ..#..   row 4
    0x04,    //  ..#..   row 5
    0x15,    //  #.#.#   row 6
    0x0E,    //  .###.   row 7
    0x04,    //  ..#..   row 8

    0x1F,    //  #####   row 1   copyright character, (C), inverse - CGRAM (3)
    0x11,    //  #...#   row 2
    0x15,    //  #.#.#   row 3
    0x17,    //  #.###   row 4
    0x15,    //  #.#.#   row 5
    0x11,    //  #...#   row 6
    0x1F,    //  #####   row 7
    0x00,    //  .....   row 8

    0x04,    //  ..#..   row 1   bell 2 - CGRAM (4) - DELETE AND ADD NEW ICON
    0x0E,    //  .###.   row 2
    0x0E,    //  .###.   row 3
    0x0E,    //  .###.   row 4
    0x1F,    //  #####   row 5
    0x08,    //  .#...   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8

    0x04,    //  ..#..   row 1   bell 3 - CGRAM (5) - DELETE AND ADD NEW ICON
    0x0E,    //  .###.   row 2
    0x0E,    //  .###.   row 3
    0x0E,    //  .###.   row 4
    0x1F,    //  #####   row 5
    0x02,    //  ...#.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8

    0x18,    //  ##...   row 1   degree symbol and C - CGRAM (6)
    0x18,    //  ##...   row 2
    0x00,    //  .....   row 3
    0x03,    //  ...##   row 4
    0x04,    //  ..#..   row 5
    0x04,    //  ..#..   row 6
    0x04,    //  ..#..   row 7
    0x03,    //  ...##   row 8

    0x18,    //  ##...   row 1   degree symbol and F - CGRAM (7)
    0x18,    //  ##...   row 2
    0x00,    //  .....   row 3
    0x07,    //  ..###   row 4
    0x04,    //  ..#..   row 5
    0x07,    //  ..###   row 6
    0x04,    //  ..#..   row 7
    0x04,    //  ..#..   row 8
};

/* Extra images to create special animations and other icons/graphics.
** These will get loaded as needed. */
const U8 lcd_special_checkmark[8] =
{
    0x00,    //  .....   row 1   checkmark symbol
    0x00,    //  .....   row 2
    0x01,    //  ....#   row 3
    0x03,    //  ...##   row 4
    0x16,    //  #.##.   row 5
    0x1C,    //  ###..   row 6
    0x08,    //  .#...   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_bell_pos0[8] =
{
    0x04,    //  ..#..   row 1   bell 1 - clanger mid position
    0x0E,    //  .###.   row 2
    0x0E,    //  .###.   row 3
    0x0E,    //  .###.   row 4
    0x1F,    //  #####   row 5
    0x00,    //  .....   row 6
    0x04,    //  ..#..   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_bell_pos1[8] =
{
    0x04,    //  ..#..   row 1   bell 2 - clanger left position
    0x0E,    //  .###.   row 2
    0x0E,    //  .###.   row 3
    0x0E,    //  .###.   row 4
    0x1F,    //  #####   row 5
    0x08,    //  .#...   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_bell_pos2[8] =
{
    0x04,    //  ..#..   row 1   bell 3 - clanger right position
    0x0E,    //  .###.   row 2
    0x0E,    //  .###.   row 3
    0x0E,    //  .###.   row 4
    0x1F,    //  #####   row 5
    0x02,    //  ...#.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_12_00[8] =
{
    0x00,    //  .....   row 1   clock - 12:00 position
    0x0E,    //  .###.   row 2
    0x15,    //  #.#.#   row 3
    0x15,    //  #.#.#   row 4
    0x11,    //  #...#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_01_30[8] =
{
    0x00,    //  .....   row 1   clock - 1:30 position
    0x0E,    //  .###.   row 2
    0x13,    //  #..##   row 3
    0x15,    //  #.#.#   row 4
    0x11,    //  #...#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_03_00[8] =
{
    0x00,    //  .....   row 1   clock - 3:00 position
    0x0E,    //  .###.   row 2
    0x11,    //  #...#   row 3
    0x17,    //  #.###   row 4
    0x11,    //  #...#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_04_30[8] =
{
    0x00,    //  .....   row 1   clock - 4:30 position
    0x0E,    //  .###.   row 2
    0x11,    //  #...#   row 3
    0x15,    //  #.#.#   row 4
    0x13,    //  #..##   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_06_00[8] =
{
    0x00,    //  .....   row 1   clock - 6:00 position
    0x0E,    //  .###.   row 2
    0x11,    //  #...#   row 3
    0x15,    //  #.#.#   row 4
    0x15,    //  #.#.#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_07_30[8] =
{
    0x00,    //  .....   row 1   clock - 7:30 position
    0x0E,    //  .###.   row 2
    0x11,    //  #...#   row 3
    0x15,    //  #.#.#   row 4
    0x19,    //  ##..#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_09_00[8] =
{
    0x00,    //  .....   row 1   clock - 9:00 position
    0x0E,    //  .###.   row 2
    0x11,    //  #...#   row 3
    0x1D,    //  ###.#   row 4
    0x11,    //  #...#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

const U8 lcd_special_clock_10_30[8] =
{
    0x00,    //  .....   row 1   clock - 10:30 position
    0x0E,    //  .###.   row 2
    0x19,    //  ##..#   row 3
    0x15,    //  #.#.#   row 4
    0x11,    //  #...#   row 5
    0x0E,    //  .###.   row 6
    0x00,    //  .....   row 7
    0x00,    //  .....   row 8
};

/* The double stroke (bold) number fonts are put into a single array - then
** a simple offset can be used to access each individual digit array block.
** Each digit block consists of 8 bytes.  10 digits for a total of 80 bytes. */
const U8 double_stroke_numeric_font[8 * 10] =
{
    0x0E,    //  .###.   row 1   digit zero double stroke (d.s.) font
    0x1B,    //  ##.##   row 2
    0x1B,    //  ##.##   row 3
    0x1B,    //  ##.##   row 4
    0x1B,    //  ##.##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8

    0x02,    //  ...#.   row 1   digit one d.s. font
    0x06,    //  ..##.   row 2
    0x0E,    //  .###.   row 3
    0x06,    //  ..##.   row 4
    0x06,    //  ..##.   row 5
    0x06,    //  ..##.   row 6
    0x06,    //  ..##.   row 7
    0x00,    //  .....   row 8

    0x0E,    //  .###.   row 1   digit two d.s. font
    0x1B,    //  ##.##   row 2
    0x03,    //  ...##   row 3
    0x06,    //  ..##.   row 4
    0x0C,    //  .##..   row 5
    0x18,    //  ##...   row 6
    0x1F,    //  #####   row 7
    0x00,    //  .....   row 8

    0x0E,    //  .###.   row 1   digit three d.s. font
    0x1B,    //  ##.##   row 2
    0x03,    //  ...##   row 3
    0x0E,    //  .###.   row 4
    0x03,    //  ...##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8

    0x03,    //  ...##   row 1   digit four d.s. font
    0x07,    //  ..###   row 2
    0x0F,    //  .####   row 3
    0x1B,    //  ##.##   row 4
    0x1F,    //  #####   row 5
    0x03,    //  ...##   row 6
    0x03,    //  ...##   row 7
    0x00,    //  .....   row 8

    0x1F,    //  #####   row 1   digit five d.s. font
    0x18,    //  ##...   row 2
    0x1E,    //  ####.   row 3
    0x03,    //  ...##   row 4
    0x03,    //  ...##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8

    0x0E,    //  .###.   row 1   digit six d.s. font
    0x1B,    //  ##.##   row 2
    0x18,    //  ##...   row 3
    0x1E,    //  ####.   row 4
    0x1B,    //  ##.##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8

    0x1F,    //  #####   row 1   digit seven d.s. font
    0x03,    //  ...##   row 2
    0x06,    //  ..##.   row 3
    0x0C,    //  .##..   row 4
    0x0C,    //  .##..   row 5
    0x0C,    //  .##..   row 6
    0x0C,    //  .##..   row 7
    0x00,    //  .....   row 8

    0x0E,    //  .###.   row 1   digit eight d.s. font
    0x1B,    //  ##.##   row 2
    0x1B,    //  ##.##   row 3
    0x0E,    //  .###.   row 4
    0x1B,    //  ##.##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8

    0x0E,    //  .###.   row 1   digit nine d.s. font
    0x1B,    //  ##.##   row 2
    0x1B,    //  ##.##   row 3
    0x0F,    //  .####   row 4
    0x03,    //  ...##   row 5
    0x1B,    //  ##.##   row 6
    0x0E,    //  .###.   row 7
    0x00,    //  .....   row 8
};

/*******************************************************************************
** Function:     load_custom_lcd_images
** Description:  Load a custom image into CGRAM or all 8 custom images in the
**               LCD module.  There are 64 bytes dedicated to custom character
**               generation, with each character/image using 8 bytes.
**               Care should be taken when calling this function, since there
**               are some small delays needed.
** Inputs:       Image identifier (all or one specific image).
** Outputs:      none.
*******************************************************************************/
void  load_custom_lcd_images( lcd_special_t im_id /*, U8 * im_adrs*/ )
{
  U8  x_start;
  U8  x_end;

  if ( im_id == LOAD_ALL )
  {
    x_start = CG_START;  // starting address for CGRAM
    x_end   = CG_END;    // ending address
  }
  else
  {
    x_start = im_id * 8;    // start address
    x_end   = x_start + 8;  // ending address
  }

  LCD_Write( LCD_CMND, 0x40 );  // set address to first CGRAM location
  HAL_Delay(1);

  /* Load all 64 bytes (8 images) at one time.  As each byte is sent and stored,
  ** the internal HD44780 address pointer will auto increment.
  ** During system initialization, we can tolerate the delays.  However, during
  ** normal application run, only load one image to avoid long task times.  */
  while ( x_start <= x_end )
  {
//    LCD_Write( LCD_DATA, im_adrs[x_start] );
    LCD_Write( LCD_DATA, lcd_special_default_images[x_start] );
    ++x_start;
    HAL_Delay(1);
  }   // end while

  LCD_Write( LCD_CMND, 0x02 );  // return to home position in the LCD module
  HAL_Delay(2);

}  // end load_custom_lcd_images()

/*******************************************************************************
** Function:     load_double_stroke_number
** Description:  Load the double stroke (bold) font data into the CGRAM in the
**               LCD module.
**               NOTE:  Use CGRAM_5 to store the bold digit - the 0 location
**               will screw up the display func with a 0 inserted in the string.
** Inputs:       num (0 - 9)  - also used for array offset
** Outputs:      none.
*******************************************************************************/
void  load_double_stroke_number( U8 num )
{

  if ( num > 9 )
  {
    num = 0;  // limit check - it's an error, but just set to 0 for now
  }

  LCD_Write( LCD_CMND, 0x40 + CGRAM_5 );  // set CGRAM location
  HAL_Delay(1);

  /* Load the font image. */
  for ( U8 x = 0; x < 8; ++x )
  {
    LCD_Write( LCD_DATA, double_stroke_numeric_font[( num * 8 ) + x] );
    small_delay( DELAY_40uSEC );
  }

}  // end load_double_stroke_number()

/*******************************************************************************
** Function:     show_idle_scrolling
** Description:  During the idle state, show the scrolling characters on the
**               display.  Show one complete screen per function call.
** Inputs:       .
** Outputs:      none.
*******************************************************************************/
void  show_idle_scrolling( void )
{
  U8 x = 0;

  /* Check if scrolling is enabled.  If not, skip this function and exit. */
  if ( scrolling_get( ) == YES )
  {

    LCD_Write( LCD_CMND, 0x01 );  // clear display
    HAL_Delay(2);

    /* Fill the top line of the display with the current 16 characters for the
    ** scrolling screen. */
    while ( x < 16 )
    {
      LCD_Write( LCD_DATA, display_array[x++] );
      HAL_Delay(1);
    }  // end while

    shift_display_array( );  // set up array for the next pass
  }

}  // end show_idle_scrolling()

/*******************************************************************************
** Function:     load_display_array_for_scroll
** Description:  Set the initial display for the idle screens, with the special
**               scrolling character set in position 1.
** Inputs:       .
** Outputs:      none.
*******************************************************************************/
void  load_display_array_for_scroll( void )
{

  /* Load display array with the starting screen.  Skip position [0] for now -
  ** this will be set later.  Just uses the LCD module top line. */
  for ( U8 x = 1; x < 16; ++x )
  {
    display_array[x] = SPACE_CHAR;
  }
  display_array[0] = SCROLL_CHAR;  // value to scroll across screen

}  // end load_display_array_for_scroll()

/*******************************************************************************
** Function:     shift_display_array
** Description:  Shift the display array contents right or left.  This function
**               is called repeatedly from show_idle_scrolling().
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  shift_display_array( void )
{
  static U8 y = 1;  // counts total shifts (left or right)
  static lcd_t direction = LCD_RIGHT;  // start with the right shift
  S8 x;
  U8 pos;

  if ( direction == LCD_RIGHT )
  {
    x = 15;   // for right, shift characters 1-15 into positions 2-16
    pos = 0;  // new char goes in pos 0 (used later)
    while ( x >= 0 )
    {
      display_array[x + 1] = display_array[x];  // shift display contents right
      x--;
    }
  }
  else
  {
    x = 0;     // for left, shift characters 2-16 into positions 1-15
    pos = 15;  // new char goes in last LCD character position (used later)
    while ( x < 15 )
    {
      display_array[x] = display_array[x + 1];  // shift display contents left
      ++x;
    }
  }

  /* Only 5 max characters on the screen at any one time. Put in the new
  ** character in the first or last display position (0) or (15). */
  if (( y > 0 ) && ( y < 6 ))
  {
    display_array[pos] = SCROLL_CHAR;  // char value to scroll across screen
  }
  else
  {
    display_array[pos] = SPACE_CHAR;
  }

  /* Once all the scrolling chars have been shifted off the screen, reset. */
  if ( y++ > 20 )
  {
    y = 1;
    direction = ( direction == LCD_RIGHT ) ? LCD_LEFT : LCD_RIGHT;
  }

}  // end shift_display_array()

//* lcd_special.c ******************************************************* EOF */
