/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    main.c
**
** Description: This module initializes and controls the main functionality of
**              the compact controller project (ISC and others, TBD)
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/23/2019  Added various updates for Sonendo/ISC operation.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "main.h"
#include "beep.h"
#include "adc.h"
#include "eeprom.h"
#include "gpio.h"
#include "config.h"
#include "lcd.h"
#include "pwm.h"
#include "keys.h"
#include "intrinsics.h"  // need for instrinsic __nop function
#include <string.h>

/* Instantiate memory/structure for all defined task timers. */
static timer_params_t    timed_task[END_OF_OWNERS];
/* Instantiate memory/structure for all control and operational modes. */
static control_struct_t  ctrl_modes;
static U32               error_bits;
//char   lcd_top_line[16];     // holds text/images for display on LCD top line

/*******************************************************************************
** Function:     main
** Description:  General description of the firmware architecture scheme:
**               1. Call the initial tasks function, which does:
**                  Init the main STM32F0 processor modules; clock, systick,
**                  memory, I2C, ADC, GPIO, PWM timers and input capture timers.
**               2. Start the initialization loop; cycle thru the various items
**                  that take some time to start; e.g., LCD module, TEC, fan
**                  and thermistor POST, etc.
**               3. Start the main superloop, which will control the application
**                  throughout the normal product on-time. Uses the 1mSec tick-
**                  counter as a time base for all tasks.
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
int main( void )
{
  U32    old_tick_cnt;
  U32    new_tick_cnt;

  initial_hardware_and_parms( );
  initial_tasks( );

  error_bit_ctrl( CLR_ALL_ERROR_BITS, NO_ERROR_BITS_SET );

  /* Set up the main superloop timing values. */
  old_tick_cnt = HAL_GetTick();
  new_tick_cnt = old_tick_cnt;

  task_timer_init( );

  menu_mode_state( NORM_OP_SCREEN, SET_DATA );  // initial menu mode
  led_setup( ONB_WHITE, LED_BLINK, 200, 2250, FOREVER );  // "i'm alive" blink

  if ( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == AUTO_MODE )
  {
    led_on_off( MEMB_GREEN, ON );        // green LED - power on, unit OK
    fan_ctrl( FAN2_CH, FAN_SPEED_MED );  // inside fan at 50%
    set_manual_ok_to_start_flag( YES );  // ready to display (if ISC)
    ctrl_mode_state( DEADBAND_MODE, SET_DATA );

    if ( board_cfg_get( ) == SONENDO_CONTROL )
    {
      fan_start_stop( FAN_START, FAN1_CH );  // start fan
    }
  }
  else  // in MANUAL MODE (must be ISC)
  {
    ctrl_mode_state( PWR_OFF_MODE, SET_DATA );
  }

  /* The main super loop. */
  while ( 1 )
  {
    while ( old_tick_cnt == new_tick_cnt )
    {
      new_tick_cnt = HAL_GetTick();
      /* During this "spin-time" check if beeper active. (Rev. 2 hardware only). */
#ifdef  BOARD_221_0144_REV2
      beeper_control( );
#endif
    }  // end while

    /* At least 1 mSec has elapsed at this point. */
    old_tick_cnt = new_tick_cnt;

  debug_pin_output( TOGGLE_OUTPUT );  // test output - connect scope to J8

    update_task_timer( );
    update_adc_events( );
    update_operation_events( );
    update_comm_events( );
    update_pb_events( );
    update_beeper_events( );
    update_misc_events( );
    update_led_ctrl_events( );
    update_display_events( );
    update_error_check_events( );

  }  // end while (super-loop)

}  // end main()

/*******************************************************************************
** Function:     task_timer_init
** Description:  Initialize the task-timing, record-keeping structure/array.
**               Load default values.  The first timed_event array value is for
**               [NO_OWNER], so start with [NO_OWNER + 1].
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
void  task_timer_init( void )
{
  U8 ii;  // NOTE: ii is enum type, but no warnings with U8 (task_owner_t)

  for ( ii = NO_OWNER + 1; ii < END_OF_OWNERS; ii++ )
  {
    timed_task[ii].start    = FALSE;     // timer_start() sets this TRUE
    timed_task[ii].done     = TRUE;      // initially in this state
    timed_task[ii].value    = 0;
    timed_task[ii].cnt_down = 0;
    timed_task[ii].type     = ONE_SHOT;  // default
  }

}  // end task_timer_init()

/*******************************************************************************
** Function:     task_timer_start
** Description:  Sets up the timer parameters for the task timer owner.
**               Setting the .start=TRUE should be the last thing done in this
**               function, to avoid interrupt race condition.  Maximum mSeconds
**               count value is 65535mSec (65.5 seconds).
**
** Inputs:       Timer owner, (timer_owner_t)
**               timer count value, (U16, value in mSec)
**               timer type, (timer_type_t)
** Outputs:      none
*******************************************************************************/
void  task_timer_start( task_owner_t owner, U16 t_cnt, timer_type_t t_type )
{

  timed_task[owner].value    = t_cnt;   // value to load and/or re-load
  timed_task[owner].cnt_down = t_cnt;   // this variable gets decremented
  timed_task[owner].type     = t_type;  // one-shot or periodic
  timed_task[owner].done     = FALSE;   // just started, not done yet
  timed_task[owner].start    = TRUE;    // start (enable) the timed event

}  // end task_timer_start()

/*******************************************************************************
** Function:     task_timer_stop
** Description:  Stops the timer associated with the owner task.
**
** Inputs:       Task owner.
** Outputs:      none
*******************************************************************************/
void  task_timer_stop( task_owner_t owner )
{

  timed_task[owner].start = FALSE;  // stop the timed task event
  timed_task[owner].done  = TRUE;

}  // end task_timer_stop()

/*******************************************************************************
** Function:     update_task_timer
** Description:  For task timing functions, called from main using the 1 mSec
**               clock tick.  All active (.start=TRUE) tasks will get their
**               countdown value decremented and tested for 0 (done). Reload
**               countdown value if timer is done and it's PERIODIC.
**               NOTE: the "for" loop in this interrupt routine should be
**               reasonably fast for the number of timed events in our app.
** Inputs:
** Outputs:
*******************************************************************************/
void  update_task_timer( void )
{
  U8 ii;  // NOTE: using ii as enum type (task_owner_t)

  /* Find the active (started) timers.  Decrement the countdown value. */
  for ( ii = NO_OWNER + 1; ii < END_OF_OWNERS; ii++ )
  {
    if ( timed_task[ii].start == TRUE )
    {
      if ( timed_task[ii].cnt_down > 0 )
      {
        timed_task[ii].cnt_down--;
      }
      else
      {
        timed_task[ii].done = TRUE;
        if ( timed_task[ii].type == PERIODIC )
        {
          timed_task[ii].cnt_down = timed_task[ii].value;  // reload for periodic
        }
        else
        {
          timed_task[ii].start = FALSE;  // stop the one-shot timed event
        }
      }
    }
  }  // end for
}  // end update_task_timer()

/*******************************************************************************
** Function:     task_timer_done_check
** Description:  Check if the task is complete (.done = TRUE).  If the task is
**               complete and periodic, return TRUE, but reset the .done flag
**               back to FALSE for the next period time.
** Inputs:       task_owner_t
** Outputs:      TRUE if done, else FALSE
*******************************************************************************/
BOOL  task_timer_done_check( task_owner_t owner )
{
  BOOL  task_status;

  task_status = timed_task[owner].done;
  if (( task_status ) && ( timed_task[owner].type == PERIODIC ))
  {
    /* Was TRUE, but since it's periodic, set to FALSE for future checks.
    ** (this flag gets set in the timer_update function). */
    timed_task[owner].done = FALSE;
  }

  return  task_status;

}  // end task_timer_done_check()

/*******************************************************************************
** Function:     get_next_task
** Description:  Query the list of task owners to find which task timer is done,
**               or which task is the first one done.  Then set the task to the
**               next task item from the enum list.  If we are at the end of
**               the list, then we're done - set to NO_OWNER.
** Inputs:       .
** Outputs:      (task_ownwer) - next to execute.
*******************************************************************************/
task_owner_t  get_next_task( void )
{
  register  U8 ii;  // NOTE: ii is enum type (task_owner_t)

  for ( ii = NO_OWNER + 1; ii < END_OF_OWNERS; ii++ )
  {              // IF THIS EVER GETS USED, VERIFY THE LOGIC BELOW...
    if (( timed_task[ii].start == TRUE ) && ( timed_task[ii].done == TRUE ))
    {
      /* Get the next task in the list, unless we're at the end of the list. */
      ii = ii + 1;
      if ( ii >= END_OF_OWNERS )
      {
        ii = NO_OWNER;
      }
      break;
    }
  }  // end for
  return  (task_owner_t) ii;

}  // end get_next_task()

/*******************************************************************************
** Function:     control_modes_init
** Description:  Initialize the operational modes and controls that are used
**               to handle various controls and functions related to the user
**               interface (display and pushbuttons), fan and TEC operation.
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
void  control_modes_init( void )
{

  ctrl_modes.menu_mode = NORM_OP_SCREEN;  // default starting menu state/mode

  if ( ctrl_mode_state( NONE, GET_DATA ) != PWR_OFF_MODE )
  {
    ctrl_mode_state( INIT_MODE, SET_DATA );
  }
  else
  {
    ctrl_mode_state( PWR_OFF_MODE, SET_DATA );
  }
  ctrl_modes.menu_level = LEVEL_0;         // first menu level in idle/init mode
//  ctrl_modes.tout_level = LEVEL_0;         // level to go to on a timeout
  /* Read board configuration (jumpers on J8).  See config.h and docs for
  ** explanation of the various board configurations.  */
  ctrl_modes.board_cfg = read_board_config_pins( );

}  // end control_modes_init()

/*******************************************************************************
** Function:     set_idle_mode
** Description:  Set the unit to operate in IDLE mode.  If we are in Factory
**               Test mode, do not automatically reset everything.  (This is
**               called from keytimeout func, and should not stop the tests in
**               this case.
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
void  set_idle_mode( void )
{

  if (( ctrl_mode_state( NONE, GET_DATA ) != TEST_MODE_ACTIVE ) &&
      ( ctrl_mode_state( NONE, GET_DATA ) != TEST_MODE_PASS )   &&
      ( ctrl_mode_state( NONE, GET_DATA ) != TEST_MODE_FAIL ))
  {
  // ADD NEW FUNCTION TO SET CONTROL MODE TO THE SETPOINT/SENSOR SCREEN...
    control_modes_init( );
    scrolling_set( YES );   // (re)enable scrolling screen

    /* Turn all fans off. */
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
  }

}  // end set_idle_mode()

/*******************************************************************************
** Function:     menu_mode_state
** Description:  Gets or sets the menu mode or state. With this value and the
**               pushbutton value, we can determine the next menu state and the
**               control function to call.  A GET doesn't use the menu_state
**               variable, (state = MENU_NONE). For SET, the menu_state is
**               updated, and the function returns MENU_NONE.
** Inputs:       menu item from menu_states_t, get_set_access_t
** Outputs:      menu_states_t
*******************************************************************************/
menu_states_t  menu_mode_state( menu_states_t opm, get_set_access_t gs )
{
  menu_states_t  rtn_val;

  if ( gs == SET_DATA )
  {
    ctrl_modes.menu_mode = opm;
    rtn_val = MENU_NONE;
  }
  else if ( gs == GET_DATA )
  {
    rtn_val = ctrl_modes.menu_mode;
  }
  else
  {
    rtn_val = MENU_NONE;  // access code not defined or used...
  }
  return  rtn_val;

}  // end menu_mode_state()

/*******************************************************************************
** Function:     ctrl_mode_state
** Description:  Gets or sets the control/operational mode/state.
**               A GET doesn't use the op_ctrl_state variable, (state = NONE),
**               and the current value for the control operational state is
**               returned.  For SET, the op_ctrl_state variable is updated and
**               the function returns NONE.
** Inputs:       op_ctrl_states_t, get_set_access_t
** Outputs:      op_ctrl_states_t
*******************************************************************************/
op_ctrl_states_t  ctrl_mode_state( op_ctrl_states_t state, get_set_access_t gs )
{
  op_ctrl_states_t  rtn_val;

  if ( gs == SET_DATA )
  {
    ctrl_modes.ctrl_mode = state;
    rtn_val = NONE;
  }
  else if ( gs == GET_DATA )
  {
    rtn_val = ctrl_modes.ctrl_mode;
  }
  else
  {
    rtn_val = NONE;  // access code not defined or used...
  }
  return  rtn_val;

}  // end ctrl_mode_state()

/*******************************************************************************
** Function:     board_cfg_get
** Description:  Returns the board configuration (J8 jumper setting).  See docs
**               and config.h for descriptions of various configurations.
** Inputs:       -none-
** Outputs:      U8 - jumper setting
*******************************************************************************/
U8  board_cfg_get( void )
{
  return  ctrl_modes.board_cfg;
}  // end board_cfg_get()

/*******************************************************************************
** Function:     update_misc_events
** Description:  Random, misc. functions that don't fit neatly into other
**               modules. Some may not require real-time repsonse, some
**               functions are non-regularly occurring, and others...
**               > Soft reset command from the serial command (CLI) protocol.
**               > Test modes, from the combo switches on the membrane.
**               > Totalizing functions; total on-time, total TEC on-time, etc.
**               > Check for fan error (RPM is below threshold).
**               > Check if LCD is still busy with message display.
** Inputs:       -none-
** Outputs:      .
*******************************************************************************/
void  update_misc_events( void )
{
  op_ctrl_states_t cms;
  U8  fan_setup;

  /* Check if a serial comm reset command has been issued. */
  reset_stm32( CHECK_STATUS );

  /* Check if we are in the EOL or factory test mode. */
  if ( ctrl_mode_state( NONE, GET_DATA ) == TEST_MODE_ACTIVE )
  {
    test_mode_event_control( );
  }

  totals_tracker( );   // update time totalizers...

  /* If in STOP_MODE, (for Sonendo), don't check for fan errors.  Also, don't
  ** check errors if fan setup is configured to ignore tach feedback. */
  cms = ctrl_mode_state( NONE, GET_DATA );
  fan_setup = (U8)get_ee_parameter( EE_FAN1_SETUP, EE_DATA_8 );
  if (( board_cfg_get( ) == SONENDO_CONTROL ) &&
      ( cms != STOP_MODE ) &&
      ( fan_setup != FAN_WIRE4_NO_ERR ))
  {
    check_fan_error( );  // check if fan RPM is < threshold
  }

  /* This is called continuously and true most of the time, but this should be
  ** OK, since it is only needed for LCD display updates. */
  if ( task_timer_done_check( LCD_BUSY ) )
  {
    display_busy_set( NO );
  }

}  // end update_misc_events()

/*******************************************************************************
** Function:     update_error_check_events
** Description:  Handle the periodic checks for various error conditions;
**               1. thermistor sensor error (ADC count out of range value).
**               2. thermistor sensor overtemp error.
**               3. thermistor sensor undertemp error.
**               4. input voltage over/under (out of range value) TBD...
**               5. TBD...
** Inputs:       -none-
** Outputs:      .
*******************************************************************************/
void  update_error_check_events( void )
{
  static U16  thrm_error_cnt = 0;        // ctrl thermistor error count
  static U8   thrm_error_trigger = NO;   // flag indicates an error found
  static U16  temp_error_cnt = 0;        // ctrl thermistor overtemp error count
  static U8   temp_error_trigger = NO;   // flag indicates an error found
  static U16  volts_error_cnt = 0;       // 24V input voltage error count
  static U8   volts_error_trigger = NO;  // flag indicates an error found
         U16  v_val;
         F32  sensor;
         F32  upper_alarm;
         F32  lower_alarm;

  /* Any ADC count below this limit is considered an error; typically an un-
  ** connected sensor.  Since initial counts will be low until the averaging
  ** routine settles out, make the error count threshold relatively high. */
  if ( get_current_adc_counts( 0 ) < 100 )
  {
    if ( ++thrm_error_cnt > 1250 )
    {
      if ( thrm_error_trigger == NO )
      {
        /* The ADC counts for thermistor 1 (ctrl) have been in the error range
        ** long enough - set the LED indicator for ERROR - (blink at a 1Hz
        ** rate indefinately). */
        led_setup( MEMB_RED, LED_BLINK, 500, 500, FOREVER );
        thrm_error_trigger = YES;
        ctrl_mode_state( ERROR_MODE, SET_DATA );
        error_bit_ctrl( SET_ERROR_BIT, TEMP_SENSOR_FAIL );
      }
      thrm_error_cnt = 1250;  // cap value for error recoverery (below)
    }
  }
  else
  {
    if (( thrm_error_cnt > 0 ) && ( thrm_error_trigger == YES ))
    {
      if ( --thrm_error_cnt == 0 )
      {
        /* The ADC counts for thermistor 1 (ctrl sensor) are now back in the
        ** legal value range.  Turn off error indication, and reset trigger. */
        led_setup( MEMB_RED, LED_OFF, 0, 0, 0 );
        thrm_error_trigger = NO;
        ctrl_mode_state( RUN_MODE, SET_DATA );
        error_bit_ctrl( CLR_ERROR_BIT, TEMP_SENSOR_FAIL );
      }
    }
  }

  /* Check the 24V input voltage; issue an alarm for above/below the limits.
  ** We can tolerate > 20% margin, but this is good to start.  Refer to the
  ** values in config.h for the upper and lower limits. */
  v_val = get_current_adc_counts( 4 );  // channel 4 - 24V monitor
  if (( v_val > IN_VOLTS_UPPER_COUNTS ) || ( v_val < IN_VOLTS_LOWER_COUNTS ))
  {
    if ( ++volts_error_cnt > 1800 )
    {
      if ( volts_error_trigger == NO )
      {
        /* The ADC counts for 24V monitor channel have been in the error range
        ** long enough - set the LED indicator for ERROR - (blink at a 1Hz
        ** rate indefinately). */
        led_setup( MEMB_RED, LED_BLINK, 500, 500, FOREVER );
        volts_error_trigger = YES;
        ctrl_mode_state( ERROR_MODE, SET_DATA );
        error_bit_ctrl( SET_ERROR_BIT, VOLTAGE_24_FAIL );
      }
      volts_error_cnt = 1800;  // cap value for error recoverery (below)
    }
  }
  else
  {
    if (( volts_error_cnt > 0 ) && ( volts_error_trigger == YES ))
    {
      if ( --volts_error_cnt == 0 )
      {
        /* The ADC counts for 24V monitor channel is now back in the legal
        ** value range.  Turn off error indication, and reset trigger. */
        led_setup( MEMB_RED, LED_OFF, 0, 0, 0 );
        volts_error_trigger = NO;
        ctrl_mode_state( RUN_MODE, SET_DATA );
        error_bit_ctrl( CLR_ERROR_BIT, VOLTAGE_24_FAIL );
      }
    }
  }

  /* Check the control thermistor temperatue; issue an alarm for above/below the
  ** limits. Refer to the values in config.h for the upper and lower limits.
  ** Set the upper and lower limits dependent on product type. */
  if ( board_cfg_get( ) == SONENDO_CONTROL )
  {
    upper_alarm = SONENDO_UPPER_ALARM_TEMP_C;
    lower_alarm = SONENDO_LOWER_ALARM_TEMP_C;
  }
  else
  {
    upper_alarm = ISC_UPPER_ALARM_TEMP_C;
    lower_alarm = ISC_LOWER_ALARM_TEMP_C;
  }

  sensor = get_current_temperature( 0, DEGREES_C );  // control sensor temp
  if (( sensor > upper_alarm ) || ( sensor < lower_alarm ))
  {
    if ( ++temp_error_cnt > 1000 )
    {
      if ( temp_error_trigger == NO )
      {
        /* The control thermistor 1 (ctrl) have been in the error range
        ** long enough - set the LED indicator for ERROR - (blink at a 1Hz
        ** rate indefinately). */
        led_setup( MEMB_RED, LED_BLINK, 500, 500, FOREVER );
        temp_error_trigger = YES;
        ctrl_mode_state( ERROR_MODE, SET_DATA );
        if ( sensor > upper_alarm )
        {
          error_bit_ctrl( SET_ERROR_BIT, TEMP_TOO_HIGH );
        }
        else  // must be the low temp alarm...
        {
          error_bit_ctrl( SET_ERROR_BIT, TEMP_TOO_LOW );
        }
      }
      temp_error_cnt = 1000;  // cap value for error recoverery (below)
    }
  }
  else
  {
    if (( temp_error_cnt > 0 ) && ( temp_error_trigger == YES ))
    {
      if ( --temp_error_cnt == 0 )
      {
        /* Thermistor 1 (ctrl sensor) is now back in the good value range.
        ** Turn off error indication, and reset trigger. */
        led_setup( MEMB_RED, LED_OFF, 0, 0, 0 );
        temp_error_trigger = NO;
        ctrl_mode_state( RUN_MODE, SET_DATA );
        if ( sensor > upper_alarm )
        {
          error_bit_ctrl( CLR_ERROR_BIT, TEMP_TOO_HIGH );
        }
        else  // must be the low temp alarm...
        {
          error_bit_ctrl( CLR_ERROR_BIT, TEMP_TOO_LOW );
        }
      }
    }
  }

}  // end update_error_check_events()

/*******************************************************************************
** Function:     error_bit_ctrl
** Description:  This function will set or clear the indicate error bit.  The
**               error bit defines are in config.h.  We have a U32 data type to
**               hold up to 32 unique error conditions.  Only 11 are defined so
**               far, (as of firmware version 1.5).
** Inputs:       error_bit_t - clear/set/clear_all, U32 - error bit.
** Outputs:      .
*******************************************************************************/
void  error_bit_ctrl( error_bit_t cs, U32 error_ )
{
  if ( cs == SET_ERROR_BIT )
  {
    error_bits |= error_;  // add "or" the error bit
  }
  else if ( cs == CLR_ERROR_BIT )
  {
    error_bits &= ~(error_);  // clear the error bit
  }
  else
  {
    error_bits = 0;  // clear all error bits
  }

}  // end error_bit_ctrl()

/*******************************************************************************
** Function:     get_error_bits
** Description:  Return the current error bit setting.
** Inputs:       -none-
** Outputs:      U32 - error bit data values.
*******************************************************************************/
U32  get_error_bits( void )
{

  return  error_bits;

}  // end get_error_bits()

/*******************************************************************************
** Function:     read_board_config_pins
** Description:  Read the parameter config bits on the PCBA.
**               This value determines board functionality (run-time
**               configuration).  See config.h for more info.
**               Remember that the 6th pin (formerly CONF_FW_BIT5_Pin) is now
**               a debug output pin (DEBUG_OUT_Pin). This is the pin closest to
**               the J8 reference designator (and the flex connect) on the board
**               silkscreen.  See debug_output_pin() function.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
U8 read_board_config_pins( void )
{
  U8 config_setting = 0;  // board run-time config setting

  /* The input config pins are pulled-up, so if a jumper is present, that input
  ** will read 0 (GPIO_PIN_RESET). */
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT0_GPIO_Port, CONF_FW_BIT0_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1 << 0;  // position xxxx1
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT1_GPIO_Port, CONF_FW_BIT1_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1 << 1;  // position xxx1x
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT2_GPIO_Port, CONF_FW_BIT2_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1 << 2;  // position xx1xx
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT3_GPIO_Port, CONF_FW_BIT3_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1 << 3;  // position x1xxx
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT4_GPIO_Port, CONF_FW_BIT4_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1 << 4;  // position 1xxxx
  }

  return  config_setting;

}  // end read_board_config_pins()

/*******************************************************************************
** Function:     debug_pin_output
** Description:  Set the debug output pin - see read_board_config_pins()
**               function.  This is primarily used for debug and scope timing
**               measurements.  This pin is located near the big caps and the
**               reference designator (J8).
** Inputs:       Flag for output on debug pin on J8. High, low or toggle.
** Outputs:      -none-.
*******************************************************************************/
void  debug_pin_output( debug_pin_t pin_high_low_toggle )
{
  if ( pin_high_low_toggle == OUTPUT_HIGH )
  {
    HAL_GPIO_WritePin( DEBUG_OUT_GPIO_Port, DEBUG_OUT_Pin, GPIO_PIN_SET );
  }
  else if ( pin_high_low_toggle == OUTPUT_LOW )
  {
    HAL_GPIO_WritePin( DEBUG_OUT_GPIO_Port, DEBUG_OUT_Pin, GPIO_PIN_RESET );
  }
  else
  {
    HAL_GPIO_TogglePin( DEBUG_OUT_GPIO_Port, DEBUG_OUT_Pin );
  }

}  // end debug_pin_output()

/*******************************************************************************
** Function:     SystemClock_Config
** Description:  Set up the STM32F0 micro clock and timer interrupts.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void SystemClock_Config( void )
{
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

  /* Initializes the CPU, AHB and APB busses clocks */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* Initializes the CPU, AHB and APB busses clocks */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_SYSCLK;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_SYSCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* Configure the Systick interrupt time */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

  /* Configure the Systick */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

}  // end SystemClock_Config()

/*******************************************************************************
** Function:     _Error_Handler
** Description:  This is the STM32F0-provided function to handle errors with
**               module and register setup operations.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  _Error_Handler(char * file, int line)
{
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
    // add to error count, and reset??
  }
}  // end _Error_Handler()

#ifdef USE_FULL_ASSERT
/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
}

#endif

/* main.c *************************************************************** EOF */
