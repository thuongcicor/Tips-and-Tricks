/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    leds.c
**
** Description: Functions associated with the LEDs.  There are a total of 5
**              LEDs on the current hardware configuration;  2 on the 221-0144
**              control board assembly, and 3 on the membrane switch panel,
**              (221-0145).
**
** Version/Author/Date/Description:
** 1   DMA   01/12/2018  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "gpio.h"
#include "project.h"
#include "config.h"
#include "pwm.h"
#include "main.h"
#include "eeprom.h"
#include "intrinsics.h"  // need for instrinsic __nop function

led_struct_t  leds[NUM_LEDS];  // declare struct(s) for all LED control variables

/*******************************************************************************
** Function:     led_init
** Description:  Controls the various LEDS on the main control board, 221-0144,
**               and the external membrane switch panel, which contains 3 LEDs.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void led_init( void )
{
  /* Start by making sure all LEDs are off on the main controller. */
  LED_R1_OFF;  // on-board RED
  LED_W_OFF;   // on-board WHITE

  /* Include the membrane panel LEDs if the build is for that configuration. */
  if ( NUM_LEDS == 5 )
  {
    LED_G_OFF;   // membrane GREEN - PWR
    LED_B_OFF;   // membrane BLUE - COOL
    LED_R2_OFF;  // membrane RED - HEAT
  }

  /* Loop thru LED list and init each LEDs struct. */
  for ( U8 i = ONB_RED; i < NUM_LEDS; i++ )
  {
    leds[i].mode = LED_OFF;
    leds[i].counts = 0;
    leds[i].init_1st = FALSE;
    leds[i].on_counts = 0;
    leds[i].off_counts = 0;
    leds[i].cycle = 0;
    leds[i].repeat = 0;
  }  // end for

}  // end led_init()

/*******************************************************************************
** Function:     led_status
** Description:  Returns the status (ON or OFF) of the LED.  The LED is ON if
**               the current state is BLINKING, even if it's off at the time.
**               Consider this a "LED is in-use" type of query.
** Inputs:       led_id_t - LED ID of interest.
** Outputs:      led_t - LED mode, on or off.
*******************************************************************************/
led_t led_status( led_id_t id )
{
  if (( leds[id].mode == LED_OFF ) || ( leds[id].mode == LED_NOTHING ))
  {
    return  LED_OFF;
  }
  else
  {
    return  LED_ON;
  }

}  // end led_status()

/*******************************************************************************
** Function:     led_setup
** Description:  Set up the LED control.  Parameters set here are used in
**               update_led_ctrl_events() for timing and sequence control.
**               Example 1; on-board red LED on once for 2 seconds:
**                 led_setup(ONB_RED, LED_SINGLE, 2000, 0, 1);
**               Example 2; on for 1 sec, off for 1/2 sec, repeat sequence 3x:
**                 led_setup(MEM_BLUE, LED_BLINK, 1000, 500, 3);
**               Example 3; on-board white LED continuously on:
**                 led_setup(ONB_WHITE, LED_CONTINUOUS, 0, 0, 0);
**               Example 4; turn off all LEDs:
**                 led_setup(ALL_LEDS, LED_ALL_OFF, 0, 0, 0);
**
** Inputs:       (see description above)
**               Note that parameters that are not used for a specific LED
**               function are don't care, (use 0).
** Outputs:      -none-
*******************************************************************************/
void  led_setup( led_id_t id, led_t mode, U16 on_time, U16 off_time, U8 repeat )
{

  /* Handle the special case of turning off all LEDS. */
  if ( mode == LED_ALL_OFF )
  {
    led_init();
  }
  else
  {
    leds[id].mode       = mode;
    leds[id].init_1st   = FALSE;   // multiple pass flag - TRUE after 1st time thru
    leds[id].on_counts  = on_time;
    leds[id].off_counts = off_time;
    leds[id].state      = OFF;
    leds[id].repeat     = repeat;  // blink repeat count, or FOREVER
  }

}  // end led_setup()

/*******************************************************************************
** Function:     update_led_ctrl_events
** Description:  This function is called from the periodic task timer, every
**               1mSec, and controls the led timing and sequencing.  The
**               previously called led_setup controls which case is executed.
**               For the blinking LED functions, each repeat count equals 1 on
**               cycle + 1 off cycle.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  update_led_ctrl_events( void )
{
  led_id_t  i;  // used to cycle thru LED list

  /* Loop thru LED list and determine action for each LED. */
  for ( i = ONB_RED; i < NUM_LEDS; i++ )
  {
    switch ( leds[i].mode )
    {
      case LED_OFF:
        led_on_off( i, OFF );        // turn off selected LED
        leds[i].state = OFF;
        leds[i].init_1st = FALSE;    // reset for next pass
        leds[i].mode = LED_NOTHING;  // nothing more to do until next led setup
        break;

      case LED_CONTINUOUS:
        led_on_off( i, ON );
        leds[i].state = ON;
        break;

      case LED_SINGLE:
      case LED_BLINK:
        if ( leds[i].init_1st == FALSE )  // 1st time thru...
        {
          led_on_off( i, ON );  // turn on the selected LED
          leds[i].state = ON;
          leds[i].counts = leds[i].on_counts;
          leds[i].init_1st = TRUE;
        }
        else
        {
          if ( leds[i].counts > 0 )
          {
            leds[i].counts--;
          }
          else
          {
            if ( leds[i].state == ON )
            {
              if ( leds[i].mode == LED_SINGLE )
              {
                leds[i].mode = LED_OFF;  // done with single LED flash
              }
              else
              {
                led_on_off( i, OFF );
                leds[i].counts = leds[i].off_counts;  // pre-load for next off cycle
                leds[i].state = OFF;
              }
            }
            else
            {
              leds[i].cycle++;  // on-off cycle count
              if (( leds[i].cycle < leds[i].repeat ) || ( leds[i].repeat == 0xFF ))
              {
                led_on_off( i, ON );
                leds[i].counts = leds[i].on_counts;  // pre-load for next on cycle
                leds[i].state = ON;
              }
              else
              {
                leds[i].mode = LED_OFF;  // done with multiple flashes
              }
            }
          }
        }
        break;

      default:  // default case handles the "nothing" led mode...
      break;

    }  // end switch
  }  // end for

}  // end update_led_ctrl_events()

/*******************************************************************************
** Function:     led_on_off
** Description:  Low level hardware control for the various LEDS - on or off.
**               Note that the Sonendo application uses FANS 3 & 4 for the
**               external RED and BLUE LEDs.
** Inputs:       led_id_t id, ON or OFF.
** Outputs:      .
*******************************************************************************/
void led_on_off( led_id_t id, BOOL state )
{

  switch ( id )
  {
    case ONB_RED:  // on-board red
      if ( state == ON )
      {
        LED_R1_ON;
      }
      else
      {
        LED_R1_OFF;
      }
      break;

    case ONB_WHITE:  // on-board white
      if ( state == ON )
      {
        LED_W_ON;
      }
      else
      {
        LED_W_OFF;
      }
      break;

    case MEMB_GREEN:  // membrane panel green
      if ( state == ON )
      {
        LED_G_ON;
      }
      else
      {
        LED_G_OFF;
      }
      break;

    case MEMB_BLUE:  // membrane panel blue (Sonendo: fan4 connect used for LED)
      if ( state == ON )
      {
        /* To avoid the quick blinks in Sonendo mode from pwm adjusts in the
        ** fan_ctrl(), if the LED is already on, skip. */
        if (( board_cfg_get( ) == SONENDO_CONTROL ) &&
            ( leds[MEMB_BLUE].state != ON ))
        {
          fan_ctrl( FAN4_CH, FAN_SPEED_HIGH );
        }
        else
        {
          LED_B_ON;
        }
      }
      else
      {
        if ( board_cfg_get( ) == SONENDO_CONTROL )
        {
          fan_ctrl( FAN4_CH, FAN_SPEED_OFF );
        }
        else
        {
          LED_B_OFF;
        }
      }
      break;

    case MEMB_RED:  // membrane panel red (Sonendo: fan3 connect used for LED)
      if ( state == ON )
      {
        /* To avoid the quick blinks in Sonendo mode from pwm adjusts in the
        ** fan_ctrl(), if the LED is already on, skip. */
        if (( board_cfg_get( ) == SONENDO_CONTROL ) &&
            ( leds[MEMB_RED].state != ON ))
        {
          fan_ctrl( FAN3_CH, FAN_SPEED_HIGH );
        }
        else
        {
          LED_R2_ON;
        }
      }
      else
      {
        if ( board_cfg_get( ) == SONENDO_CONTROL )
        {
          fan_ctrl( FAN3_CH, FAN_SPEED_OFF );
        }
        else
        {
          LED_R2_OFF;
        }
      }
      break;

    default:
      break;

  }  // end switch

}  // end led_on_off()

/* leds.c *************************************************************** EOF */
