/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    debug.c
**
** Description: This module contains various functions associated with debug-
**              related functionally.  Other misc functions included here as
**              well.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   09/03/2019  Don't automatically (re)print out the menu if an
**                       unrecognized command is received.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "versions.h"
#include "serial_comm.h"
#include "adc.h"
#include <string.h>
#include <stdlib.h>
#include "intrinsics.h"  // need for instrinsic __nop function

extern UART_HandleTypeDef huart1;

/* Set up some debug print strings.
** NOTE:  ALWAYS PERFORM A "REBUILD ALL" TO INCLUDE THE LATEST COMPILE DATE. */
const char  FIRMWARE_TITLE[]    = "\r\nII-VI Marlow 221-0144 Controller, ";
const char  FIRMWARE_VER_STR[]  = "firmware ver. ";
const char  COMPILE_DATE_STR[]  = "Build date: ";

/*******************************************************************************
** Function:     output_initial_debug_info
** Description:  Prints (debug output) the startup info, including program name,
**               firmware version, date, etc.
** Inputs:       debug print options (add <cr>, <lf>, comma, etc.)
** Outputs:      none
*******************************************************************************/
void output_initial_debug_info( dbug_print_options_t dpo )
{
  char temp_str[60];  // big enough to hold the longest print string

  /* Combine the program title and firmware version info. */
  strcpy( temp_str, FIRMWARE_TITLE );
  strcat( temp_str, FIRMWARE_VER_STR );
  strcat( temp_str, str_(MAJOR_VER_NUM) );
  strcat( temp_str, str_(NUM_SEPARATOR) );
  strcat( temp_str, str_(MINOR_VER_NUM) );
  send_debug( temp_str, dpo );   // add the debug print option to end of string

  /* Combine the "built on" and date strings. */
  strcpy( temp_str, COMPILE_DATE_STR );
  strcat( temp_str, __DATE__ );  // compile date here, format: "Mmm dd yyyy"
  send_debug( temp_str, dpo );   // add the debug print option to end of string

}  // end output_initial_debug_info()

/*******************************************************************************
** Function:     update_comm_events
** Description:  If a complete message (CR or NL terminated) has been received,
**               process it and clear the input receive buffer.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void update_comm_events( void )
{

  if ( check_message_received( ) == YES )
  {
    process_message();     // no need to check return value
    input_buffer_reset();  // also resets "msg_complete" flag
  }

}  // end update_comm_events()


// MOVE TO CONVERT.C ...................

/*******************************************************************************
** Function:     real_temp_to_string
** Description:  Converts the real (F32) temperature to a printable string.
**               Note that the real temperature value must be within the range
**               of -3276.8 to 3276.8 to allow for the integer conversion with
**               one fractional digit.  This is more than adequate for our use.
** Inputs:       F32 floating point temperature value
** Outputs:      string of input temperature + decimal point + fractional digit
*******************************************************************************/
char * real_temp_to_string( F32 temp_val )
{
  S16  int_val;           // holds signed int conversion of real temperature
  S16  fractional_digit;  // holds last fractional digit value
  char static str1[8];    // temporary string (static for return)
  char str2[2];           // temporary string for last digit

  /* First perform the bounds check. */
  if (( temp_val > UPPER_TEMP_LIMIT ) || ( temp_val < LOWER_TEMP_LIMIT ))
  {
    temp_val = UPPER_TEMP_LIMIT;  // could be min value also
  }

  int_val = (S16)( temp_val );  // get the integer part
  fractional_digit = (S16)(( temp_val - int_val ) * 10 );

  memset( str1, NULL, strlen( str1 ));

  /* The following test is needed because values from 0 to -0.5 would not have
  ** the negative sign becasue the S16 cast rounded the value to 0.  This is a
  ** less than ideal workaround...  */
  if ( temp_val < 0 )
  {
    strcpy( str1, " -" );
    int_val = -int_val;
  }
  else if ( temp_val > 0 )
  {
    strcpy( str1, "  " );
  }
  else
  {
    strcpy( str1, "  0.0" );  // don't bother converting, just load and go
    return str1;
  }
  strcat( str1, s16_to_string( int_val, NO_SPACE_OR_0 ));
  strcat( str1, "." );
  str2[0] = abs( fractional_digit ) + '0';  // convert last digit to ASCII
  str2[1] = NULL;
  strcat( str1, str2 );  // add the last digit and NULL to string

  return str1;

} // end real_temp_to_string()


/*******************************************************************************
** Function:     s16_to_string
** Description:  Convert a signed 16-bit int to a 5 digit decimal string.
**               Ex:  0x03A7, or 935 decimal, converts to string array:
**               a) "00935", with leading 0's, or
**               b) "  935", with leading spaces, or
**               c) "935",   with no leading spaces or 0's.
**               Ex:  0xFFF4 = -12 decimal, string "-12".
** Inputs:       signed 16-bit integer, with leading 0's or spaces.
** Outputs:      Up to a 5 digit string (with opt. '-' sign and NULL) in global
**               char array "dec_buf[]".
*******************************************************************************/
char * s16_to_string( S16 num, dbug_print_options_t lz )
{
  U8 index;
  U8 digit;
  U8 sign = 0;                          // indcates positive or negative value
  U8 found_at_least_one_digit = FALSE;  // used for the no spaces or 0's adjustment
  char temp_buf[7];
  // Need a static for the decimal buffer, so that we can return the pointer.
  char static dec_buf[7];  // holds decimal string (5 digits + (sign) + null)

  if ( num < 0 )
  {
    sign = 1;
    num = -num;  // make it positive for the conversion loop
  }

  /* Pre-load the array with either spaces or 0's.  If needed, we will modify
  ** for no leading spaces and no leading 0's (see below). */
  digit = ( lz == LEADING_0 ) ? '0' : ' ';

  for ( index = 0; index < 6; index++ )
  {
    dec_buf[index] = digit;  // pre-load buffer with 0's or spaces
  }

  dec_buf[5] = '0';        // in case input num = 0, and no leading 0's
  dec_buf[6] = 0;          // add null for string operations

  index = 0;
  while (( num > 0 ) && ( index < 6 ))
  {
    digit = (U8)(num % 10);            // extract last decimal digit from num
    dec_buf[5 - index] = '0' + digit;  // convert to ascii and store
    num = num / 10;                    // next decimal digit position
    index += 1;
  }  // end while
  if ( sign )
  {
    dec_buf[5 - index] = '-';          // add the '-' sign
  }
  /* We're done if we needed a right justified array with leading spaces or 0's.
  ** Check if we need a left justified, no leading spaces or 0's string array. */
  if ( lz == NO_SPACE_OR_0 )
  {
    U8 x2 = 0;
    for ( index = 0; index < 6; index++ )
    {
      if (( dec_buf[index] != '0' && dec_buf[index] != ' ' ) ||
         ( found_at_least_one_digit ))
      {
        /* Found a digit or '-', move to front of array. */
        temp_buf[x2++] = dec_buf[index];
        found_at_least_one_digit = TRUE;
      }
    }  // end for
    if ( found_at_least_one_digit )
    {
      temp_buf[x2] = NULL;  // found digits to move, so just terminate string
    }
    else
    {
      strcpy( temp_buf, "0" );  // dec_buf was "     0", so make this "0"
    }
    strcpy( dec_buf, temp_buf );
  }

  return  dec_buf;

}  // end s16_to_string()

/*******************************************************************************
** Function:     printable_timestamp
** Description:  Converts an unsigned 32-bit value, 4 bytes, to its decimal
**               string equivalent.  This value is the system time tick count
**               in milliseconds.  Values from 0 to 0xFFFFFFFF, (4,294,967,295).
**               The format is: "1234567.123" seconds, which is 7 significant
**               digits (for seconds), and 3 millisecond digits.
**               NOTE: There is no real-time clock on this system, and no
**               external crystal - just the internal systick timer!
**               Not acurate over long timespans, but close enough for us!
** Inputs:       Unsigned 32 bit hex value to convert.
** Outputs:      ASCII string (10 digits with decimal point).
*******************************************************************************/
char * printable_timestamp( U32 num, dbug_print_options_t lz )
{
  U8 index;
  U8 digit;
  // Need a static for the decimal buffer, so that we can return the pointer.
  char static dec_buf[12];  // holds decimal string (10 digits + (sign) + null)

  digit = ( lz == LEADING_0 ) ? '0' : ' ';  // set for spaces ' ' or zero's '0'

  for ( index = 0; index < 10; index++ )
  {
    dec_buf[index] = digit;  // pre-load buffer with 0's or spaces
  }
  dec_buf[10] = '0';  // in case input num = 0, and no leading 0's
  dec_buf[11] = 0;    // add null for string operations

  index = 0;
  /* TODO: The while loop uses expensive modulo and divide operations, but we
  ** will optomize later if needed. -dalbert */
  while (( num > 0 ) && ( index < 12 ))
  {
    digit = (U8)(num % 10);             // extract last decimal digit from num
    dec_buf[10 - index] = '0' + digit;  // convert to ascii and store
    num = num / 10;                     // next decimal digit position
    index += 1;
    if ( index == 3 )
    {
      /* Put the decimal point here, and skip to next index position. */
      dec_buf[10 - index] = '.';
      index += 1;
    }
  }  // end while

  return  dec_buf;

}  // end printable_timestamp()

/*******************************************************************************
** Function:     string2int16
** Description:  String to integer conversion.  Take input from the parameter
**               substinrgs and convert to an unigned int (U16).  The goal is to
**               eliminate the code bloat and other problems using atoi, atof,
**               sscanf, etc.
** Inputs:       char - input string with the numeric representation.
** Outputs:      U16 value of the input string.
*******************************************************************************/
U16 string2int16( char * str )
{
  U16 result = 0;
  U8  n = 0;                    // string index
  U8  len = strlen( str );

  if ( str[0] == '-' || str[0] == '+' )
  {
    n = 1;   // skip to position 1 if + or - preceeds number
  }

  for ( ; n < len; ++n )  // n already set to position of first number digit
  {
    result = result * 10 + ( str[n] - '0' );
  }  // end for

  return result;

}  // end string2int16()

/*******************************************************************************
** Function:     reset_stm32
** Description:  Calls the system library reset (soft re-start) function.
**               The UART command to reset the processor begins the reset
**               sequence (option = START).  All other calls to this function
**               (option = CHECK_STATUS) will check if the reset has started,
**               and then after at least one full pass thru the main loop, the
**               second CHECK_STATUS after the trigger will call the actual
**               system reset function.  This was done to allow time to
**               complete any pending debug outputs.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void reset_stm32( reset_options_t opt )
{
  static U8  reset_flag = 0;

  if ( opt == START )
  {
    send_debug( "\r\nStart soft reset...", ADD_CRLF );
    reset_flag = 1;  // flag indicates reset process has started
  }
  else if ( opt == CHECK_STATUS )
  {
    if ( reset_flag > 0 )
    {
      /* Trigger is set - increment flag count until ready to actually reset. */
      if ( ++reset_flag > 5 )
      {
        /* At this point, we've been thru a few passes of the main loop
        ** after getting the reset trigger, so now we can actually reset. */
        NVIC_SystemReset();  // restart from main()... (no return)
      }
    }
  }
  else
  {
    ;  // not a valid option... exit func
  }

} // end reset_stm32()


#if 0
/*******************************************************************************
** Function:     debug_output
** Description:  Send the requested debug data out via the UART.
** Inputs:
** Outputs:
*******************************************************************************/
void  debug_output( U32 time_tick, U16 adc_cnt, F32 tC, U8 drive )
{
  char  str1[26];
  char  str2[26];

  /* Start by printing the timestamp. */
  strcpy( str1, printable_timestamp( time_tick, LEADING_0 ));
  send_debug( str1, NO_CRLF );

  strcpy( str1, "  " );  // spaces between timestamp and following message
  /* Add the text to define the debug output. */
  strcat( str1, DEBUG_DATA );
  /* Add the average ADC count value. */
  strcpy( str2, s16_to_string( adc_cnt, LEADING_SPACES ));
  strcat( str1, str2 );
  send_debug( str1, NO_CRLF );
  /* Add the real temperature in C value. */
  strcpy( str1, real_temp_to_string( tC ));
  send_debug( str1, NO_CRLF );
  /* Add the TEC drive % value. */
  strcpy( str1, s16_to_string( drive, LEADING_SPACES ));
  send_debug( str1, ADD_CRLF );

}  // end debug_output()

/*******************************************************************************
** Function:     fast_decimal_to_binary
** Description:  Convert decimal value to binary hex value.
** Inputs:       Range 0 to 4,294,967,295.
** Outputs:      32-bit unsigned int.
*******************************************************************************/
void  fast_decimal_to_binary( U32 dval, U32 * bval )
{
  for ( U8 i = 0; i < 32; ++i )
  {
    *(bval++) = (dval >> i) & 0x1;
  }  // end for

}  // end fast_decimal_to_binary()

/*******************************************************************************
** Function:     fast_binary_to_decimal
** Description:  Convert binary hex value to decimal value.
** Inputs:       32-bit unsigned int.
** Outputs:      Range 0 to 4,294,967,295.
*******************************************************************************/
void  fast_binary_to_decimal( unsigned long int * n, U32 * c )
{
  U8 i = 32;

  *n = 0;
  while ( --i )
  {
    *n <<= 1;
    *n += *(c + i);
  }  // end while

}  // end fast_binary_to_decimal()
#endif

/* debug.c ************************************************************** EOF */
