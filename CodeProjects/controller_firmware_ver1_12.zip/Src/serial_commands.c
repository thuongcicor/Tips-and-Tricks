/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    serial_commands.c
**
** Description: This module contains the function pointer table and serial
**              data parsing for the various UART commands.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/30/2019  Added restore defaults function.
** 3   DMA   09/04/2019  Added "help" and "?" for menu print function.  Now the
**                       message process will not automatically print out the
**                       menu on an unrecognized command.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "serial_comm.h"
#include "eeprom.h"
#include "beep.h"
#include "adc.h"
#include "pwm.h"
#include "lcd.h"
#include "config.h"
#include "intrinsics.h"  // need for instrinsic __nop function
#include <string.h>
#include <stdio.h>       // need for sprintf()

/* Either of the following two command strings will print out the full menu. */
const char  HELP_STR1[]  = "help";
const char  HELP_STR2[]  = "?";

extern char debug_in_buf[MAX_DEBUG_IN_BUFFER_SIZE];  // debug input via UART

char input_parm1[MAX_DEBUG_IN_PARM1_SIZE];  // input parm 1
char input_parm2[MAX_DEBUG_IN_PARM2_SIZE];  // input parm 2
char split_strings[3][10];                  // 3 strings up to 10 chars each

typedef void ( *cmd_fptr ) ( void );       // define for the function pointer

typedef struct menu_strings_and_command_functions
{
  char      user_command[MAX_MENU_STRING_LENGTH];
  cmd_fptr  command_func;
} command_entry_type;

/* Main menu array:
** First part is the printable menu string, and the second is the associated
** function for the menu item.  Add lines anywhere as needed.  No need to
** add a terminating NULL at the end of the list - see MENU_LINES below.
** Make sure there is at least one space between the main menu item and the
** description, since the input function will try to match only the first part
** of the menu string.
** NOTE - make sure MAX_DEBUG_OUT_BUFFER_SIZE is adjusted as new items added.
** Also, make sure each string text line is < MAX_MENU_STRING_LENGTH. */
const  command_entry_type  console_entry_cmd_menu[] =
{
  /* "---------1---------2---------3---------4---|" <--(string length gauge) */
  {  "COMMANDS & DESCRIPTIONS:",                   cmd_null },
  {  "beta     - get/set thermistor beta",         cmd_beta },
  {  "beep     - off/on (debug)",                  cmd_beep },
  {  "control  - man/auto, start/stop, etc.",      cmd_control },
  {  "counts   - ADC averaged values",             cmd_adc_counts },
  {  "getEE    - get block of EEPROM data",        cmd_get_ee },
  {  "fan      - fan rpm 1-4",                     cmd_fan_funcs },
  {  "output   - output combined data (x)",        cmd_dbug_out },
  {  "PID-cool - Cooling P & I terms",             cmd_pi_cool_values },
  {  "PID-heat - Heating P & I terms",             cmd_pi_heat_values },
  {  "reset    - Reboot/reset micro",              cmd_reboot_stm32 },
  {  "restore  - (re)set default values",          cmd_restore_parms },
  {  "runtest  - perform test (x)",                cmd_null },
  {  "setEE    - write byte (address, data)",      cmd_set_ee },
  {  "spH      - setpoint high, (uses C/F)",       cmd_setpoint_high },
  {  "spL      - setpoint low, (uses C/F)",        cmd_setpoint_low },
  {  "stm32    - micro & board info",              cmd_stm32_info },
  {  "thrm     - thermistors 1-4, degree C/F",     cmd_thermistors },
  {  "T_units  - get/set temp units C/F",          cmd_temp_units_fc },
  {  "ver      - get firmware version",            cmd_firmware_ver },
  {  "volts    - voltages 24V, 12V, 3.3V, 3V",     cmd_voltages }
};
                    // other commands:  fan speed in deadband.  min ON time for TEC, min OFF time for TEC

/* Get total number of menu lines from the above main menu array. */
#define  MENU_LINES  ( sizeof( console_entry_cmd_menu ) / sizeof( console_entry_cmd_menu[ 0 ] ))

/*******************************************************************************
** Function:     print_debug_menu
** Description:  Output the various debug (main_menu) messages.  This function
**               just prints the ASCII strings, and ignores the associated
**               functions for now.
** Inputs:
** Outputs:
*******************************************************************************/
void print_debug_menu( void )
{
  command_entry_type  cmd_st;
  char temp_str[MAX_MENU_STRING_LENGTH];
  U16  m_ptr = 0;     // array pointer to individual menu strings

  /* Start with a blank line (to skip over the typed input line), and add the
  ** carriage return and line feed. */
  send_debug( "", ADD_CRLF );

  /* Get each menu line item (individual string) and print it. */
  while ( m_ptr < MENU_LINES )
  {
    strcpy( cmd_st.user_command, console_entry_cmd_menu[m_ptr].user_command );
    strcpy( temp_str, cmd_st.user_command );
    send_debug( temp_str, ADD_CRLF );
    ++m_ptr;
  }  // end while

  cmd_prompt( );  // add command prompt, "CMD >"

}  // end print_debug_menu()

/*******************************************************************************
** Function:     process_message
** Description:  This func is called by the app after a complete message has
*                been received.  The message is compared to the main menu items
*                to find the match and call the corresponding function.
**               The following will be parsed from the input string:
**               1. split_strings[0][] - command - should match MAIN_MENU item
**               2. split_strings[1][] - optional parameter 1
**               3. split_strings[2][] - optional parameter 2
** Inputs:       none
** Outputs:      TRUE = command match found, FALSE = no match
*******************************************************************************/
U8 process_message( void )
{
  command_entry_type  cmd_st;
  char *input_str;
  char *menu_str;

  U16  m_ptr = 0;      // array pointer to individual menu strings
  U8   match = FALSE;  // flag for command match found
  U8   ch_cnt = 0;     // character counter in each substring
  U8   str_cnt = 0;    // substring counter, for 3 sub-strings

  input_parm1[0] = NULL;  // clear out left-over or garbage data
  input_parm2[0] = NULL;

  /* The console user input from the UART is saved in the debug_in_buf. */
  input_str = strip_blanks( debug_in_buf );  // get rid of any leading spaces

  /* Split the input string into 3 strings. The first string will be the command
  ** part, the next (optional) string is parameter 1, and the next (optional)
  ** string is parameter 2. */
  U8 i = 0;  // while-loop index
  while ( i < strlen( input_str ) )
  {
    /* Check for space delimiter and end of string delimiters. */
    if ( input_str[i] == ' '  || input_str[i] == '\0'  ||
         input_str[i] == '\r' || input_str[i] == '\n' )
    {
      split_strings[str_cnt][ch_cnt] = NULL;
      if ( ++str_cnt > 2 )
      {
        break;  // done - we have all allowed paramters
      }
      ch_cnt = 0;   // for next string parameter, reset index to 0

      /* Skip blanks after a complete sub-string found. */
      while ( i < strlen( input_str ) && input_str[i] == ' ' )
      {
        ++i;
      }  // end while
    }
    else
    {
      split_strings[str_cnt][ch_cnt] = input_str[i];
      /* Error check - no more than 10 chars per parameter. */
      if ( ++ch_cnt > 10 - 1 )
      {
        send_debug( "\r\n\nInput error!", ADD_CRLF );
        break;
      }
      ++i;
    }
  }  // end while

  /* We should now have the command sub-string with up to two (optional)
  ** parameter sub-strings. */
  while ( m_ptr < MENU_LINES )
  {
    /* Get the menu item line, then get basic menu command by stripping the
    ** extra description bytes.  Then look for match (case insensitive). */
    strcpy( cmd_st.user_command, console_entry_cmd_menu[m_ptr].user_command );
    menu_str = get_main_menu_item( cmd_st.user_command );

    if ( strcasecmp( menu_str, split_strings[0] ))
    {
      ++m_ptr;  // no match, get next menu item
    }
    else
    {
      /* We have a command match!  Call func and break out of while... */
      cmd_st.command_func = console_entry_cmd_menu[m_ptr].command_func;
      cmd_st.command_func();
      match = TRUE;
      break;
    }
  }  // end while

  if ( match != TRUE )
  {
    /* We've gone thru the full menu command list, and no match was found.  Now
    ** check for the *hidden* commands, "help" or "?" (case insensitive).  If a
    ** match is found, print out the full menu list. */
    if (( strcasecmp( HELP_STR1, split_strings[0] ) == 0 )  ||
        ( strcasecmp( HELP_STR2, split_strings[0] ) == 0 ))
      {
        print_debug_menu();  // user CLI menu list(console_entry_cmd_menu)
        match = TRUE;
      }
  }

  send_debug( "", ADD_CRLF );  // add line feed after input
  return match;

}  // end process_message()

/*******************************************************************************
** Function:     strip_blanks
** Description:  Get rid of leading blanks in the input message buffer.
** Inputs:       Received input message buffer
** Outputs:      Stripped message buffer.
*******************************************************************************/
char * strip_blanks( char * the_buff )
{
  U8 num_to_move;
  char * ret_buff = the_buff;  // start with complete buffer

  while( ( the_buff[0] == ' ' ))
  {
    num_to_move = strlen( the_buff );
    for ( U8 i = 0; i < num_to_move; i++ )
    {
      ret_buff[i] = the_buff[i + 1];
    }  // end for
  }  // end while

  return ret_buff;

}  // end strip_blanks()

/*******************************************************************************
** Function:     get_main_menu_item
** Description:  Returns the string up to the first space character.  Get rid
**               of extra description characters in the menu string.  We only
**               need the main menu item for compare with console input.
** Inputs:       Main menu item string with description.
** Outputs:      Main menu item without description.
*******************************************************************************/
char * get_main_menu_item( char * menu_str )
{
  U8 menu_str_len;
  U8 i = 0;                    // buffer pointer
  char * ret_buff = menu_str;  // start with complete buffer

  menu_str_len = strlen( menu_str );

  while( ( menu_str[i] != ' ' ) && ( i < menu_str_len ))
  {
    ++i;
  }  // end while

  /* At this point, we've found the first space char, or we're at the end of
  ** string.  Either way, put a NULL here, and return. */
  ret_buff[i] = NULL;

  return ret_buff;

}  // end get_main_menu_item()

/*******************************************************************************
** Function:     cmd_reboot_stm32
** Description:  Starts the reset process for the STM32.
**               This sets the trigger, the rest is handled in the
**               update_misc_events function.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_reboot_stm32( void )
{

  reset_stm32( START );

}  // end cmd_reboot_stm32()

/*******************************************************************************
** Function:     cmd_firmware_ver
** Description:  Display the firmware version info and build date.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_firmware_ver( void )
{

  output_initial_debug_info( ADD_CRLF );

}  // end cmd_firmware_ver()

/*******************************************************************************
** Function:     cmd_pi_cool_values
** Description:  Show/enter the PID values for cooling.  We will just use
**               P and I gain values for our application (Dgain=0).
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_pi_cool_values( void )
{
  char str1[20];
  char str2[18];
  F32  Pgain;       // PID - p gain term
  F32  Igain;       // PID - i gain term

  if ( split_strings[1][0] == NULL )
  {
    /* No parameters entered - just show current values. */
    Pgain = pid_terms( 0, PGAIN_COOL, GET_DATA );
    Igain = pid_terms( 0, IGAIN_COOL, GET_DATA );
    strcpy( str1, "\r\nP, I = " );
    sprintf( str2, "%05.3f, %05.3f", Pgain, Igain );
    strcat( str1, str2 );
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* Parameter(s) entered - convert the Pgain value to bytes and store. */
    Pgain = string2float( split_strings[1] );
    set_real_data( Pgain, EE_PGAIN_COOL );       // save to EE memory
    pid_terms( Pgain, PGAIN_COOL, SET_DATA );    // save in pid struct

    /* User may have entered just one parameter (Pgain).  If 2nd parameter
    ** (Igain) entered, convert from float to bytes and store. */
    if ( split_strings[2][0] != NULL )
    {
      Igain = string2float( split_strings[2] );
      set_real_data( Igain, EE_IGAIN_COOL );     // save to EE memory
      pid_terms( Igain, IGAIN_COOL, SET_DATA );  // save in pid struct
    }

    /* Reset PID counts due to new parms, for either SONENDO (normal PID
    ** control)  or ISC ( deadband mode control). */
    pid_value_init( RESET_ERROR_SUM );
  }
}  // end cmd_pi_cool_values()

/*******************************************************************************
** Function:     cmd_pi_heat_values
** Description:  Show/enter the PID values for heating.  We will just use
**               P and I gain values for our application (Dgain=0).
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_pi_heat_values( void )
{
  char str1[20];
  char str2[18];
  F32  Pgain;       // PID - p gain term
  F32  Igain;       // PID - i gain term

  if ( split_strings[1][0] == NULL )
  {
    /* No parameters entered - just show current values. */
    Pgain = pid_terms( 0, PGAIN_HEAT, GET_DATA );
    Igain = pid_terms( 0, IGAIN_HEAT, GET_DATA );
    strcpy( str1, "\r\nP, I = " );
    sprintf( str2, "%05.3f, %05.3f", Pgain, Igain );
    strcat( str1, str2 );
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* Parameter(s) entered - convert the Pgain value to bytes and store. */
    Pgain = string2float( split_strings[1] );
    set_real_data( Pgain, EE_PGAIN_HEAT );     // save to EE memory
    pid_terms( Pgain, PGAIN_HEAT, SET_DATA );  // save in pid struct

    /* User may have entered just one parameter (Pgain).  If 2nd parameter
    ** (Igain) entered, convert from float to bytes and store. */
    if ( split_strings[2][0] != NULL )
    {
      Igain = string2float( split_strings[2] );
      set_real_data( Igain, EE_IGAIN_HEAT );     // save to EE memory
      pid_terms( Igain, IGAIN_HEAT, SET_DATA );  // save in pid struct
    }

    /* Reset PID counts due to new parms, for either SONENDO (normal PID
    ** control)  or ISC ( deadband mode control). */
    pid_value_init( RESET_ERROR_SUM );
  }
}  // end cmd_pi_heat_values()

/*******************************************************************************
** Function:     cmd_dbuf_out
** Description:  This function is used to output the data "assemblies" for
**               logging or periodic monitoring of controller data.  The data
**               items are comma separated, and each assemlby terminates with
**               the /r and /n characters.
**               Currently, there are 3 data assemblies defined;
**               1 - output static data; i.e., firmware version, beta, PID vals,
**                   setpoints, jumpers, etc.
**               2 - output dynamic data; i.e., thermistor temps, voltages,
**                   TEC PWM, operating mode, fan speed, error bits, etc.
**               3 - random values; rate-of-cooling (roc), Ki value, etc.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_dbug_out( void )
{
  char str1[46];  // long enough to hold the full string
  char str2[12];
  static char  err_msg[] = "\r\nNeed assembly number 1-3.";
  U16 temp_int;
  U32 temp_long_int;
  F32 temp_real;
  U8  assy_num;
  U8  tu;
  U32  dummy1;
  U8   pwm;
  heat_cool_t  dummy3;

  /* First check for no parameter (null string). */
  if ( split_strings[1][0] == NULL )
  {
    strcpy( str1, err_msg );
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* Paramter 1 (input sub-string[1][]) has the output assembly number. */
    assy_num = string2int16( split_strings[1] );
    if ( assy_num == 1 )
    {
      /* This grouping is the "assembly 1" data package (static data).
      ** Start with the firmware name, version, & build date info. */
      output_initial_debug_info( ADD_COMMA );

      /* Add the thermistor beta value. */
      temp_int = get_ee_parameter( EE_BETA, EE_DATA_16 );
      strcpy( str1, " " );
      strcpy( str2, s16_to_string( temp_int, NO_SPACE_OR_0 ));
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add PI parms, COOLING. */
      strcpy( str1, " " );
      temp_real = pid_terms( 0, PGAIN_COOL, GET_DATA );
      sprintf( str2, "%05.3f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );
      temp_real = pid_terms( 0, IGAIN_COOL, GET_DATA );
      sprintf( str2, "%05.3f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add PI parms, HEATING. */
      strcpy( str1, " " );
      temp_real = pid_terms( 0, PGAIN_HEAT, GET_DATA );
      sprintf( str2, "%05.3f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );
      temp_real = pid_terms( 0, IGAIN_HEAT, GET_DATA );
      sprintf( str2, "%05.3f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add temperature units (C or F). */
      tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
      if ( tu == DEGREES_C )
      {
        strcpy( str1, " C" );
      }
      else
      {
        strcpy( str1, " F" );
      }
      send_debug( str1, ADD_COMMA );

      /* Add the SPH value. */
      strcpy( str1, " " );
      if ( tu == DEGREES_C )
      {
        temp_real = get_sp_value( SPH_C );
      }
      else
      {
        temp_real = get_sp_value( SPH_F );
      }
      sprintf( str2, "%04.1f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the SPL value. */
      strcpy( str1, " " );
      if ( tu == DEGREES_C )
      {
        temp_real = get_sp_value( SPL_C );
      }
      else
      {
        temp_real = get_sp_value( SPL_F );
      }
      sprintf( str2, "%04.1f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the board jumper setting (in hex). */
      strcpy( str1, " " );
      sprintf( str2, "%02X", read_board_config_pins( ));
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the manual or auto start mode setting. */
      if ( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == MANUAL_MODE )
      {
        strcpy( str1, "Manual" );
      }
      else
      {
        strcpy( str1, "Auto" );
      }
      send_debug( str1, ADD_CRLF );  // last item, terminate with \r, \n
    }
    else if (assy_num == 2 )
    {
      /* This grouping is the "assembly 2" data package (dynamic data).
      ** Start with the 4 thermistor temp values in the stored temp units. */
      tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

      strcpy( str1, "\r\n" );
      temp_real = get_current_temperature( 0, tu );  // channel 0, therm 1
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );
      temp_real = get_current_temperature( 1, tu );  // channel 1, therm 2
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );
      temp_real = get_current_temperature( 2, tu );  // channel 2, therm 3
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );
      temp_real = get_current_temperature( 3, tu );  // channel 3, therm 4
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the voltages.  See description in func "cmd_voltages" for details
      ** on how the voltages are calculated. */
      temp_int = get_current_adc_counts( 4 );  // channel 4 - 24V monitor
      temp_real = ( 3.3f * 10.3f ) * ( (F32)temp_int / 4095.0f );
      sprintf( str2, "%7.2f", temp_real );
      strcpy( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_current_adc_counts( 5 );  // channel 5 - 12V monitor
      temp_real = ( 3.3f * 4.67f ) * ( (F32)temp_int / 4095.0f );
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_current_adc_counts( 6 );  // channel 6 - 3.3V monitor
      temp_real = ( 3.3f * 1.26f ) * ( (F32)temp_int / 4095.0f );
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_current_adc_counts( 7 );  // channel 7 - 3V monitor
      temp_real = ( 3.3f * 1.26f ) * ( (F32)temp_int / 4095.0f );
      sprintf( str2, "%7.2f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the fan tachometer data values. */
      temp_int = get_fan_tach( 1 );
      sprintf( str2, "%d", temp_int );
      strcpy( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_fan_tach( 2 );
      sprintf( str2, "%d", temp_int );
      strcat( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_fan_tach( 3 );
      sprintf( str2, "%d", temp_int );
      strcat( str1, str2 );
      strcat( str1, ", " );

      temp_int = get_fan_tach( 4 );
      sprintf( str2, "%d", temp_int );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Add the operation mode info. */
      strcpy( str1, get_mode_text( ));
      send_debug( str1, ADD_COMMA );

      /* Add the PWM duty cycle value. */
      /* Convert the TEC PWM duty cycle value to ASCII (BCD). */
      pid_vals( &dummy1, &pwm, &dummy3, GET_PWM_VAL );
      strcpy( str1, hex_2_bcd( pwm ));
      send_debug( str1, ADD_COMMA );

      /* Add the error word (U32). */
      temp_long_int = get_error_bits( );
      sprintf( str1, "%X", temp_long_int );  // report errors in hex format
      send_debug( str1, ADD_CRLF );          // last item, terminate with \r, \n
    }
    else if (assy_num == 3 )
    {
      /* This grouping is the "assembly 3" data package (random info data).
      ** Start with the rate-of-cooling value. */
      temp_real = rate_of_cooling( 0.0f, RETRIEVE_VAL );

      strcpy( str1, "\r\n" );
      sprintf( str2, "%7.4f", temp_real );
      strcat( str1, str2 );
      send_debug( str1, ADD_COMMA );

      /* Just add 6 placeholders for now until we get the rest of the data... */
      strcpy( str1, " 0, 0, 0, 0, 0, 0" );
      send_debug( str1, ADD_CRLF );          // last item, terminate with \r, \n
    }
    else
    {
      strcpy( str1, err_msg );
      send_debug( str1, ADD_CRLF );
    }
  }

}  // end cmd_dbug_out()

/*******************************************************************************
** Function:     cmd_thermistors
** Description:  Show the temperature values for all 4 thermistors.
**               Include spaces in the sprintf format specifier between temps.
**               See docs for identification of thermistor connectors.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_thermistors( void )
{
  char str1[46];  // long enough to hold the full string
  char str2[12];
  U8   tu;
  F32  t_val;

  /* Get the temperature units needed for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
  strcpy( str1, "\r\nThrm(x) 1-4: " );  // the 'x' will be either 'C' or 'F'

  if ( tu == DEGREES_C )
  {
    str1[7] = 'C';  // replace the 'x' in the string with 'C'
  }
  else
  {
    str1[7] = 'F';  // replace the 'x' in the string with 'F'
  }
  t_val = get_current_temperature( 0, tu );  // channel 0, thermistor 1, J11
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );
  t_val = get_current_temperature( 1, tu );  // channel 1, thermistor 2, J12
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );
  t_val = get_current_temperature( 2, tu );  // channel 2, thermistor 3, J13
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );
  t_val = get_current_temperature( 3, tu );  // channel 3, thermistor 4, J14
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );

  send_debug( str1, ADD_CRLF );

}  // end cmd_thermistors()

/*******************************************************************************
** Function:     cmd_adc_counts
** Description:  Show the ADC count averaged values for the 4 thermistor
**               temperature sensor channels.
**               The convert function "s16_to_string" expects a signed value,
**               but since the ADC count value max is 4095, we're safe.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_adc_counts( void )
{
  char str1[76];  // long enough to hold the full string
  char str2[10];
  S16  t_val;

  strcpy( str1, "\r\nADC counts 1-9: " );
  t_val = (S16)get_current_adc_counts( 0 );  // channel 0, ctrl thermistor
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 1 );  // channel 1 - thermistor 2
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 2 );  // channel 2 - thermistor 3
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 3 );  // channel 3 - thermistor 4
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 4 );  // channel 4 - 24V monitor
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 5 );  // channel 5 - 12V monitor
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 6 );  // channel 6 - 3.3V monitor
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 7 );  // channel 7 - 3V monitor
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );
  t_val = (S16)get_current_adc_counts( 8 );  // channel 16 - internal STM32 temp
  strcpy( str2, s16_to_string( t_val, LEADING_SPACES ));
  strcat( str1, str2 );

  send_debug( str1, ADD_CRLF );

}  // end cmd_adc_counts()

/*******************************************************************************
** Function:     cmd_temp_units_fc
** Description:  Sets or displays the current temperature units.  Temperature
**               is in Fahrenheit (F), or Celsius (C).  C is the default.
**
** Inputs:       "F" or "f" for Fahrenheit, "C" or "c" for Celsius.
                 No parms sent with command prints out current value.
** Outputs:
*******************************************************************************/
void cmd_temp_units_fc( void )
{
  U8   temp_unit;
  char str1[25] = "\r\nTemperature units: ";

  temp_unit = (U8)get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

  /* Check for no parameter (null string). */
  if ( split_strings[1][0] == NULL )
  {
    if ( temp_unit )
    {
      strcat( str1, "F" );  // 1 = F
    }
    else
    {
      strcat( str1, "C" );  // 0 = C
    }
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* Check paramter 1 (input sub-string[1][]) (case-insensitive).  */
    if ( strcasecmp( "f", split_strings[1] ) == 0 )
    {
      i2c_ee_write( DEGREES_F, EE_TEMP_UNITS, EE_DATA_8 );  // match "f" or "F"
    }
    else if ( strcasecmp( "c", split_strings[1] ) == 0 )
    {
      i2c_ee_write( DEGREES_C, EE_TEMP_UNITS, EE_DATA_8 );  // match "c" or "C"
    }
    else
    {
      /* Parm1 doesn't match "c" or "f" - error!  Leave units unchanged. */
      _NOP( );
    }
  }

}  // end cmd_temp_units_fc()

/*******************************************************************************
** Function:     cmd_setpoint_high
** Description:  Sets or displays the current high, upper control setpoint.
**               The SPH is stored in EE in degrees C.  EE address = EE_SPH.
** Inputs:       Temperature string value converted to F32 value.  No parms
**               sent with command will print out current value.
** Outputs:
*******************************************************************************/
void cmd_setpoint_high( void )
{
  char str1[10];
  char str2[10];
  F32  sph;  // temporary float sph value
  U8   tu;

  /* Get the temperature units (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

  /* If no parameter (null string) sent with command, then this is a "get". */
  if ( split_strings[1][0] == NULL )
  {
    strcpy( str1, "\r\nSPH = " );

    if ( tu == DEGREES_C )
    {
      sph = get_sp_value( SPH_C );
      sprintf( str2, "%04.1f", sph );
      strcat( str1, str2 );
      strcat( str1, " C" );
    }
    else
    {
      sph = get_sp_value( SPH_F );
      sprintf( str2, "%04.1f", sph );
      strcat( str1, str2 );
      strcat( str1, " F" );
    }
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* "Set" command - use sent parameter to update the setpoint high value. */
    sph = string2float( split_strings[1] );

    /* Limit check will look at board ID, temp units and SPH/SPL to determine
    ** the proper upper and lower limit values. */
    sph = limit_check_temperature( sph, SP_HIGH );
    if ( tu == DEGREES_C )
    {
      set_sp_value( sph, SPH_C );
    }
    else
    {
      set_sp_value( sph, SPH_F );
    }

    /* Regardless of current temp units, always store SPH value in degrees C.
    ** Round to 2 decimal places. */
    sph = get_sp_value( SPH_C );
    sph = round_float( sph, 2 );
    /* Store value - don't bother to compare the existing value in EE memory -
    ** this write happens infrequently - EE wear-out shouldn't be a problem. */
    set_real_data( sph, EE_SPH );

    /* Reset PID counts due to new parms, for either SONENDO (normal PID
    ** control)  or ISC ( deadband mode control). */
    pid_value_init( RESET_ERROR_SUM );
  }

}  // end cmd_setpoint_high()

/*******************************************************************************
** Function:     cmd_setpoint_low
** Description:  Sets or displays the current low setpoint, The SPL is stored
**               in EE in degrees C.  EE address = EE_SPL.
** Inputs:       Temperature string value converted to F32 value.  No parms
**               sent with command will print out current value.
** Outputs:
*******************************************************************************/
void cmd_setpoint_low( void )
{
  char str1[10];
  char str2[10];
  F32  spl;  // temporary float spl value
  U8   tu;

  /* Get the temperature units (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

  /* If no parameter (null string) sent with command, then this is a "get". */
  if ( split_strings[1][0] == NULL )
  {
    strcpy( str1, "\r\nSPL = " );

    if ( tu == DEGREES_C )
    {
      spl = get_sp_value( SPL_C );
      sprintf( str2, "%04.1f", spl );
      strcat( str1, str2 );
      strcat( str1, " C" );
    }
    else
    {
      spl = get_sp_value( SPL_F );
      sprintf( str2, "%04.1f", spl );
      strcat( str1, str2 );
      strcat( str1, " F" );
    }
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    /* "Set" command - use sent parameter to update the setpoint low value. */
    spl = string2float( split_strings[1] );

    /* Limit check will look at board ID, temp units and SPH/SPL to determine
    ** the proper upper and lower limit values. */
    spl = limit_check_temperature( spl, SP_LOW );
    if ( tu == DEGREES_C )
    {
      set_sp_value( spl, SPL_C );
    }
    else
    {
      set_sp_value( spl, SPL_F );
    }

    /* Regardless of current temp units, always store SPL value in degrees C.
    ** Round to 2 decimal places. */
    spl = get_sp_value( SPL_C );
    spl = round_float( spl, 2 );
    /* Store value - don't bother to compare the existing value in EE memory -
    ** this write happens infrequently - EE wear-out shouldn't be a problem. */
    set_real_data( spl, EE_SPL );

    /* Reset PID counts due to new parms, for either SONENDO (normal PID
    ** control)  or ISC ( deadband mode control). */
    pid_value_init( RESET_ERROR_SUM );
  }

}  // end cmd_setpoint_low()

/*******************************************************************************
** Function:     cmd_voltages
** Description:  Show the voltage monitor values from ADC channels 4-7.
**               The ADC monitor hardware uses 0.1% resistors for the input
**               voltage dividers.  12-bit ADC uses the 4095 count divider.
**               Include spaces in the sprintf format specifier between values.
** Inputs:
** Outputs:
*******************************************************************************/
void cmd_voltages( void )
{
  char str1[46];  // long enough to hold the full print/output string
  char str2[12];  // intermediate string
  U16  v_val;
  F32  t_val;

  strcpy( str1, "\r\nVolts: " );

  /* The 24V monitor uses 49.9K and 5.36K resistors.
  ** Ideal input voltage (24.0) results as 2.33 volts into the ADC (rounded).
  ** Conversion factor 10.30 to get 24V. */
  v_val = get_current_adc_counts( 4 );  // channel 4 - 24V monitor
  t_val = ( 3.3f * 10.3f ) * ( (F32)v_val / 4095.0f );
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );

  /* The 12V monitor uses 3.74K and 1.02K resistors.
  ** Ideal input voltage (12.0) results as 2.57 volts into the ADC (rounded).
  ** Conversion factor 4.67 to get 12V. */
  v_val = get_current_adc_counts( 5 );  // channel 5 - 12V monitor
  t_val = ( 3.3f * 4.67f ) * ( (F32)v_val / 4095.0f );
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );

  /* The 3.3V monitor uses 21.0K and 80.6K resistors.
  ** Ideal input voltage (3.30) results as 2.62 volts into the ADC (rounded).
  ** Conversion factor 1.26 to get 3.3V. */
  v_val = get_current_adc_counts( 6 );  // channel 6 - 3.3V monitor
  t_val = ( 3.3f * 1.26f ) * ( (F32)v_val / 4095.0f );
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );

  /* The 3.0V monitor uses 21.0K and 80.6K resistors.
  ** Ideal input voltage (3.00) results as 2.38 volts into the ADC (rounded).
  ** Conversion factor 1.26 to get 3V. */
  v_val = get_current_adc_counts( 7 );  // channel 7 - 3V monitor
  t_val = ( 3.3f * 1.26f ) * ( (F32)v_val / 4095.0f );
  sprintf( str2, "%7.2f", t_val );
  strcat( str1, str2 );

  send_debug( str1, ADD_CRLF );

}  // end cmd_voltages()

/*******************************************************************************
** Function:     cmd_beta
** Description:  Sets or displays the current thermistor beta value.
** Inputs:       The beta value is a U16 int.  Typically for our use, it will
**               be either 3950 (default) or 3450.
**               EE address = 6 (EE_BETA).
**               No parms sent with command will print out current value.
** Outputs:
*******************************************************************************/
void cmd_beta( void )
{
  char str1[20];
  char str2[10];
  U16  beta;

  /* First check for no parameter (null string). */
  if ( split_strings[1][0] == NULL )
  {
    /* Retrieve the beta value from EE parameter array. */
    beta = get_ee_parameter( EE_BETA, EE_DATA_16 );
    strcpy( str1, "\r\nbeta = " );
    strcpy( str2, s16_to_string( beta, NO_SPACE_OR_0 ));
    strcat( str1, str2 );
    send_debug( str1, ADD_CRLF );
  }
  else
  {
    beta = string2int16( split_strings[1] );
    /* The beta value should fall between these limits; else use default. */
    if (( beta > 4500 ) || ( beta < 2500 ))
    {
      beta = BETA_DEFAULT;
    }
    i2c_ee_write( (U32)( beta ), EE_BETA, EE_DATA_16 );
  }

}  // end cmd_beta()

/*******************************************************************************
** Function:     cmd_get_ee
** Description:  Reads of block of EEPROM data and outputs this data via the
**               comm channel.  Just the raw hex data is printed.
** Inputs:       Starting address from split_strings[1].  No parameter sent
**               with command defaults to address 0.
** Outputs:
*******************************************************************************/
void cmd_get_ee( void )
{
  char str1[56];  // adjust for max size of all get_ee_read_data_str() data
  U16  ee_adrs;

  /* First check for no parameter (null string). Use EEaddress = 0 in this case.
  ** Otherwise, convert parameter string to U16, and use that for EEaddress. */
  if ( split_strings[1][0] == NULL )
  {
    ee_adrs = 0;  // default to EE address 0 if no parameter send with command
  }
  else
  {
    ee_adrs = string2int16( split_strings[1] );
  }

  i2c_ee_read( ee_adrs, 32 );  // put data in 32 byte blocks into RX_i2c_buf[]
  strcpy( str1, "\r\n " );
  strcat( str1, get_ee_read_data_str( 0 ) );
  strcat( str1, " " );         // space separate the data blocks
  strcat( str1, get_ee_read_data_str( 8 ) );
  send_debug( str1, ADD_CRLF );

}  // end cmd_get_ee()

/*******************************************************************************
** Function:     cmd_set_ee
** Description:  Set one byte of EE data.  If any paramter is missing or out-
**               of-bounds, don't do anything.
** Inputs:       parameter 1, U16 ee address; parameter 2, U8 ee data byte.
** Outputs:
*******************************************************************************/
void cmd_set_ee( void )
{

  U16  ee_adrs;
  U16  ee_data;
  U8   err_flag = NO;  // start with no errors

  /* First, validate the parameters. */
  if ( split_strings[1][0] != NULL )
  {
    /* The first parameter 1 will be the 16-bit EEPROM address. */
    ee_adrs = string2int16( split_strings[1] );
  }
  else
  {
    err_flag = YES;  // no parm for address!
  }

  if ( split_strings[2][0] != NULL )
  {
    /* The second parameter 2 will be the 8-bit EEPROM data. */
    ee_data = string2int16( split_strings[2] );
  }
  else
  {
    err_flag = YES;  // no parm for data!
  }

  if ( err_flag == NO )
  {
    if ( ee_adrs > 999 )
    {
      err_flag = YES;  // address out-of-bounds! (need to get the actual upper limit...)
    }
  }

  /* If we've passed all the error checks, write the data byte1 */
  if ( err_flag == NO )
  {
    i2c_ee_write( ee_data, ee_adrs, EE_DATA_8 );
    send_debug( "\r\nData written to EE!", ADD_CRLF );
  }
  else
  {
    send_debug( "\r\nInput error!", ADD_CRLF );
  }

}  // end cmd_set_ee()

/*******************************************************************************
** Function:     cmd_fan_funcs
** Description:  Handle various fan related functions.  Turn fan ON or OFF for
**               a quick manual test.  Must be in STOP mode.
** Inputs:       Fan ID number (parameter 1), ON/OFF (parameter 2).
** Outputs:
*******************************************************************************/
void cmd_fan_funcs( void )
{
  char s1[22];
  char s2[8];

  U16  fan_num = 0;
  U16  fan_rpm;

//  U16  fan_option = OFF;

  /* Check for no parameter (null string, parameter 1). */
  if ( split_strings[1][0] == NULL )
  {
    send_debug( "\r\nNeed fan number (1-4).", ADD_CRLF );
  }
  else
  {
    /* The number will identify the fan, 1-4. */
    fan_num = string2int16( split_strings[1] );
    fan_rpm = get_fan_tach( (U8)fan_num );
    sprintf( s2, "%d", fan_rpm );
    strcpy( s1, "\r\n RPM: " );
    strcat( s1, s2 );
    send_debug( s1, ADD_CRLF );
  }

// NEED TO MAKE A CHANGE IN FAN_CTRL SO THAT NORMAL OPERATION IS OVERRIDDEN IN "STOP" MODE...
// THIS FUNC WILL SEND COMMAND FOR FANS, BUT IT IS IMMEDIATELY OVERRIDDEN IN THE CONTROL CODE...
// ... move this functionality to the "runtest (x)" command....
#if 0
  /* Output error message if not in STOP mode; else proceed... */
  if ( ctrl_mode_state( NONE, GET_DATA ) != STOP_MODE )
  {
    send_debug( "\r\nMust be in STOP mode!", ADD_CRLF );
  }
  else
  {
    /* Check for no parameter (null string, parameter 1). */
    if ( split_strings[1][0] != NULL )
    {
      /* The number will identify the fan, 1-4. */
      fan_num = string2int16( split_strings[1] );
    }

    if ( split_strings[2][0] != NULL )
    {
      /* Check paramter 2 (input sub-string[2][]) - not case sensitive). */
      if ( strcasecmp( "off", split_strings[2] ) == 0 )
      {
        fan_option = OFF;  // match found for "off" or "OFF"
      }
      else if ( strcasecmp( "on", split_strings[2] ) == 0 )
      {
        fan_option = ON;  // match found for "on" or "ON"
      }
      else
      {
        /* Parm1 doesn't match "on" or "off" - error! */
        fan_option = OFF;   // default to OFF for now
      }
    }

    /* FAN 1, J15 connector. */
    if (( fan_num == 1 ) && ( fan_option == ON ))
    {
      fan_ctrl( FAN1_CH, FAN_SPEED_HIGH );
    }
    else if (( fan_num == 1 ) && ( fan_option == OFF ))
    {
      fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    }

    /* FAN 2, J18 connector. */
    else if (( fan_num == 2 ) && ( fan_option == ON ))
    {
      fan_ctrl( FAN2_CH, FAN_SPEED_HIGH );
    }
    else if (( fan_num == 2 ) && ( fan_option == OFF ))
    {
      fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
    }

    /* FAN 3, J16 connector. */
    else if (( fan_num == 3 ) && ( fan_option == ON ))
    {
      fan_ctrl( FAN3_CH, FAN_SPEED_HIGH );
    }
    else if (( fan_num == 3 ) && ( fan_option == OFF ))
    {
      fan_ctrl( FAN3_CH, FAN_SPEED_OFF );
    }

    /* FAN 4, J17 connector. */
    else if (( fan_num == 4 ) && ( fan_option == ON ))
    {
      fan_ctrl( FAN4_CH, FAN_SPEED_HIGH );
    }
    else if (( fan_num == 4 ) && ( fan_option == OFF ))
    {
      fan_ctrl( FAN4_CH, FAN_SPEED_OFF );
    }

    else
    {
      _NOP( );  // not a legal fan number and/or option
    }
  }
#endif

}  // end cmd_fan_funcs()

/*******************************************************************************
** Function:     cmd_control
** Description:  This function can be used to stop and start the TECs (manual
**               and normal operation).  Also print out the current operational
**               mode, manual or auto start, and TEC PWM drive value (0-100).
** Inputs:       Run control value from split_strings[1].  START to start TECs,
**               (sets operational mode to RUN_MODE),
**               (auto mode) STOP to stop TECs (manual mode).
** Outputs:
*******************************************************************************/
void cmd_control( void )
{
  char s1[44];
  char s2[8];
  U32  dummy1;
  U8   pwm;
  heat_cool_t  dummy3;

  /* First check for no parameter (null string).  If NULL, report the current
  ** control mode (cool, heat, deadband, idle, etc). */
  if ( split_strings[1][0] == NULL )
  {
    if ( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == MANUAL_MODE )
    {
      strcpy( s1, "\r\n Manual mode" );
      /* If in Man. Mode, also report if ready to go (ON), or not (OFF). */
      if ( get_manual_ok_to_start_flag( ) == NO )
      {
        strcat( s1, "-OFF: " );
      }
      else
      {
        strcat( s1, "-ON: " );
      }
    }
    else
    {
      strcpy( s1, "\r\n Auto mode: " );
    }

    strcpy( s2, get_mode_text( ));  // get the operating mode text
    strcat( s1, s2 );
    strcat( s1, "  PWM:" );
    /* Convert the TEC PWM duty cycle value to ASCII (BCD), and output it. */
    pid_vals( &dummy1, &pwm, &dummy3, GET_PWM_VAL );
    strcat( s1, hex_2_bcd( pwm ));
    send_debug( s1, ADD_CRLF );
  }
  else
  {
    if ( strcasecmp( "STOP", split_strings[1] ) == 0 )  // not case sensitive
    {
      ctrl_mode_state( STOP_MODE, SET_DATA );
    }
    else if ( strcasecmp( "START", split_strings[1] ) == 0 )
    {
      ctrl_mode_state( RUN_MODE, SET_DATA );
    }
    else if ( strcasecmp( "RUN",   split_strings[1] ) == 0 )
    {
      ctrl_mode_state( RUN_MODE, SET_DATA );
    }
    else
    {
      _NOP( );  // input text don't match nothing; ignore input!
    }
  }

}  // end cmd_control()

/*******************************************************************************
** Function:     cmd_stm32_info
** Description:  Output the on-chip info in the STM32F07x for the flash memory
**               size and device ID, and other misc. info.
**               For the 64K flash part, return val = 0xXXXX0040.
**               For the 128K flash part, return val = 0xXXXX0080.
** Inputs:       none.
** Outputs:
*******************************************************************************/
void cmd_stm32_info( void )
{
  char str1[36];
  char str2[11];
  U32  temp;

  temp = get_stm32_info( FLASH_M );     // get flash memory size
  strcpy( str1, "\r\n flash mem=" );
  sprintf( str2, "%X", temp );          // convert u32 to ascii (hex)
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_info( DEVICE_ID );   // identifier for the STM32F07x device
  strcpy( str1, " dev id=" );
  sprintf( str2, "%X", temp );          // convert u32 to ascii (hex)
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_info( INTVREFCAL );  // internal voltage reference, cal value
  strcpy( str1, " intVrefCal=" );
  sprintf( str2, "%d", temp );          // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = (U32)get_current_adc_counts( 9 );  // 9 is channel 17, internal STM32 ref. voltage
  strcpy( str1, " intVrefData=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_info( INT30T );       // internal 30C temp reference cal value
  strcpy( str1, " int30C_Cal=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_info( INT110T );      // internal 110C temp reference cal value
  strcpy( str1, " int110C_Cal=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = (U32)get_current_adc_counts( 8 );  // 8 is channel 16, internal STM32 temp counts
  strcpy( str1, " intTempCounts=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_internal_temp( );     // value in degrees C for internal STM32 temp
  strcpy( str1, " intTempC_Degrees=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_ee_parameter( EE_NUM_RESETS, EE_DATA_32 );  // total number of resets
  strcpy( str1, " Total resets=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_ee_parameter( EE_TOTAL_TIME, EE_DATA_32 );  // total power on-time minutes
  strcpy( str1, " Total power on (mins)=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_ee_parameter( EE_TOTAL_TEC, EE_DATA_32 );  // total TEC on-time minutes
  strcpy( str1, " Total TEC on (mins)=" );
  sprintf( str2, "%d", temp );           // convert to decimal
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  temp = get_stm32_info( OPTIONS );
  strcpy( str1, " Option bytes=" );
  sprintf( str2, "%X", temp );           // convert u32 to ascii (hex)
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

  /* Get the status of the board config jumpers (1-5) on J8.
  ** Remember that the 6th pin on J8 is used for debug output. */
  strcpy( str1, " CFG BITS: " );
  sprintf( str2, "%#X", read_board_config_pins( ));
  strcat( str1, str2 );
  send_debug( str1, ADD_CRLF );

}  // end cmd_stm32_info()

/*******************************************************************************
** Function:     cmd_restore_parms
** Description:  Reset configuration parameters in EE memory to the defaults.
**               This is considered the "out-of-the-box", or the factory
**               configuration setting.  Values depend on jumper (J8) setting,
**               which is currently (as of 10-2018) defined as;
**               0 for ISC operation, 1 for Sonendo operation.
** Inputs:       none.
** Outputs:      .
*******************************************************************************/
void cmd_restore_parms( void )
{
  char  s1[28];
  char  s2[8];

  load_default_values( );  // either ISC or Sonendo values

  strcpy( s1, "\r\n Board ID: " );

  /* Add the board jumper setting (in hex). */
  sprintf( s2, "%02X", read_board_config_pins( ));
  strcat( s1, s2 );
  send_debug( s1, ADD_COMMA );

  strcpy( s1, " default values (re)set." );
  send_debug( s1, ADD_CRLF );

//  send_debug( "cmd > ", NO_CRLF );

}  // end cmd_restore_parms()

/*******************************************************************************
** Function:     cmd_prompt
** Description:  Add the command prompt line to the output.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void cmd_prompt( void )
{
  send_debug( "cmd > ", NO_CRLF );  // MAY NEED OPTION TO ADD \N\R BEFORE THE "CMD"...
}  // end cmd_prompt()

/*******************************************************************************
** Function:     cmd_beep
** Description:  Turn the beeper off, or on (enable). Helpful during debug to
**               keep beeper from sounding while breakpoint/stepping.
**               Always defaults to ON/enable.  Not saved in EEPROM.
** Inputs:       ON or OFF from split_string[1]
** Outputs:      none
*******************************************************************************/
void cmd_beep( void )
{
  U8 msgOnOff;

  /* Check parameter 1 for command or null. */
  if ( split_strings[1][0] != NULL )
  {
    if ( strcasecmp( "off", split_strings[1] ) == 0 )  // not case sensitive
    {
      beeper_control( OFF );
      msgOnOff = OFF;
    }
    else if ( strcasecmp( "on", split_strings[1] ) == 0 )
    {
      beeper_control( ON );
      msgOnOff = ON;
    }
    else
    {
      beeper_control( OFF );  // default to OFF if no match for ON or OFF
      msgOnOff = OFF;
    }
  }
  else
  {
    beeper_control( OFF );  // default to OFF if no parm sent with command
    msgOnOff = OFF;
  }

  if ( msgOnOff )
  {
    send_debug( "\r\n beep on! ", ADD_CRLF );
  }
  else
  {
    send_debug( "\r\n beep off! ", ADD_CRLF );
  }

}  // end cmd_beep()

/*******************************************************************************
** Function:     cmd_null
** Description:  Default function for menu items that do not require any action.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void cmd_null( void )
{
  _NOP( );
}  // end cmd_null()

/*******************************************************************************
** Function:     get_mode_text
** Description:  Take the operational mode code and return the related string.
** Inputs:       .
** Outputs:      String with operational mode text.
*******************************************************************************/
char * get_mode_text( void )
{
  static  char  ret_str[8];
  op_ctrl_states_t  opm;

  opm = ctrl_mode_state( NONE, GET_DATA );

  switch ( opm )
  {
    case PWR_OFF_MODE:       strcpy( ret_str, "P-OFF" );  break;
    case INIT_MODE:          strcpy( ret_str, "INIT" );   break;
    case COOL_MODE:          strcpy( ret_str, "COOL" );   break;
    case HEAT_MODE:          strcpy( ret_str, "HEAT" );   break;
    case DEADBAND_MODE:      strcpy( ret_str, "DEAD" );   break;
    case STOP_MODE:          strcpy( ret_str, "STOP" );   break;
    case RUN_MODE:           strcpy( ret_str, "RUN" );    break;
    case ERROR_MODE:         strcpy( ret_str, "ERROR" );  break;
    case TEST_MODE_ACTIVE:   strcpy( ret_str, "TEST" );   break;
    case TEST_MODE_PASS:     strcpy( ret_str, "PASS" );   break;
    case TEST_MODE_FAIL:     strcpy( ret_str, "FAIL" );   break;
    default:                 strcpy( ret_str, "??" );     break;  // error
  }  // end switch

  return ret_str;

}  // end get_mode_text()

/* serial_commands.c **************************************************** EOF */
