/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    convert.c
**
** Description: This module contains various conversion functions associated
**              with debug-related functionally, units convert, and data-type
**              manipulations.  Other misc functions included here as well.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   02/04/2019  Added function for temperature limit check.
** 3   DMA   09/04/2019  Mod the scale_value() to 95%, to reduce the noise on
**                       the fan tachometer line.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "versions.h"
#include "adc.h"
#include "pwm.h"
#include "eeprom.h"
#include "config.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>        // need for floor, trunc functions
#include "intrinsics.h"  // need for instrinsic __nop function

#if 0
/*******************************************************************************
** Function:     real_temp_to_string
** Description:  Converts the real (F32) temperature to a printable string.
**               Note that the real temperature value must be within the range
**               of -3276.8 to 3276.8 to allow for the integer conversion with
**               one fractional digit.  This is more than adequate for our use.
** Inputs:       F32 floating point temperature value
** Outputs:      string of input temperature + decimal point + fractional digit
*******************************************************************************/
char * real_temp_to_string( F32 temp_val )
{
  S16  int_val;           // holds signed int conversion of real temperature
  S16  fractional_digit;  // holds last fractional digit value
  char static str1[8];   // temporary string (static for return)
  char str2[2];           // temporary string for last digit

  /* First perform the bounds check. */
  if (( temp_val > UPPER_TEMP_LIMIT ) || ( temp_val < LOWER_TEMP_LIMIT ))
  {
    temp_val = UPPER_TEMP_LIMIT;  // could be min value also
  }

  int_val = (S16)( temp_val );  // get the integer part
  fractional_digit = (S16)(( temp_val - int_val ) * 10 );

  memset( str1, NULL, strlen( str1 ));

  /* The following test is needed because values from 0 to -0.5 would not have
  ** the negative sign becasue the S16 cast rounded the value to 0.  This is a
  ** less than ideal workaround...  */
  if ( temp_val < 0 )
  {
    strcpy( str1, " -" );
    int_val = -int_val;
  }
  else if ( temp_val > 0 )
  {
    strcpy( str1, "  " );
  }
  else
  {
    strcpy( str1, "  0.0" );  // don't bother converting, just load and go
    return str1;
  }
  strcat( str1, s16_to_string( int_val, NO_SPACE_OR_0 ));
  strcat( str1, "." );
  str2[0] = abs( fractional_digit ) + '0';  // convert last digit to ASCII
  str2[1] = NULL;
  strcat( str1, str2 );  // add the last digit and NULL to string

  return str1;

} // end real_temp_to_string()

/*******************************************************************************
** Function:     s16_to_string
** Description:  Convert a signed 16-bit int to a 5 digit decimal string.
**               Ex:  0x03A7, or 935 decimal, converts to:
**               string array "00935", with leading 0's, or
**               "  935", with leading spaces, or
**               "935" with no leading spaces or 0's.
**               Ex:  0xFFF4 = -12 decimal, string "-12".
** Inputs:       signed 16-bit integer.
** Outputs:      Up to a 5 digit string (with opt. '-' sign and NULL) in global
**               char array "dec_buf[]".
*******************************************************************************/
char * s16_to_string( S16 num, dbug_print_options_t lz )
{
  U8 index;
  U8 digit;
  U8 sign = 0;                          // indcates positive or negative value
  U8 found_at_least_one_digit = FALSE;  // used for the no spaces or 0's adjustment
  char temp_buf[7];
  // Need a static for the decimal buffer, so that we can return the pointer.
  char static dec_buf[7];  // holds decimal string (5 digits + (sign) + null)

  if ( num < 0 )
  {
    sign = 1;
    num = -num;  // make it positive for the conversion loop
  }

  /* Pre-load the array with either spaces or 0's.  If needed, we will modify
  ** for no leading spaces and no leading 0's (see below). */
  digit = ( lz == LEADING_0 ) ? '0' : ' ';

  for ( index = 0; index < 6; ++index )
  {
    dec_buf[index] = digit;  // pre-load buffer with 0's or spaces
  }

  dec_buf[5] = '0';        // in case input num = 0, and no leading 0's
  dec_buf[6] = 0;          // add null for string operations

  index = 0;
  while (( num > 0 ) && ( index < 6 ))
  {
    digit = (U8)(num % 10);            // extract last decimal digit from num
    dec_buf[5 - index] = '0' + digit;  // convert to ascii and store
    num = num / 10;                    // next decimal digit position
    index += 1;
  }  // end while
  if ( sign )
  {
    dec_buf[5 - index] = '-';          // add the '-' sign
  }
  /* We're done if we needed a right justified array with leading spaces or 0's.
  ** Check if we need a left justified, no leading spaces or 0's string array. */
  if ( lz == NO_SPACE_OR_0 )
  {
    U8 x2 = 0;
    for ( index = 0; index < 6; ++index )
    {
      if (( dec_buf[index] != '0' && dec_buf[index] != ' ' ) ||
         ( found_at_least_one_digit ))
      {
        /* Found a digit or '-', move to front of array. */
        temp_buf[x2++] = dec_buf[index];
        found_at_least_one_digit = TRUE;
      }
    }  // end for
    if ( found_at_least_one_digit )
    {
      temp_buf[x2] = NULL;  // found digits to move, so just terminate string
    }
    else
    {
      strcpy( temp_buf, "0" );  // dec_buf was "     0", so make this "0"
    }
    strcpy( dec_buf, temp_buf );
  }

  return  dec_buf;

}  // end s16_to_string()

/*******************************************************************************
** Function:     printable_timestamp
** Description:  Converts an unsigned 32-bit value, 4 bytes, to its decimal
**               string equivalent.  This value is the system time tick count
**               in milliseconds.  Values from 0 to 0xFFFFFFFF, (4,294,967,295).
**               The format is: "1234567.123" seconds, which is 7 significant
**               digits (for seconds), and 3 millisecond digits.
**               NOTE: There is no real-time clock on this system, and no
**               external crystal - just the internal systick timer!
**               Not acurate over long timespans, but close enough for us!
** Inputs:       Unsigned 32 bit hex value to convert.
** Outputs:      ASCII string (10 digits with decimal point).
*******************************************************************************/
char * printable_timestamp( U32 num, dbug_print_options_t lz )
{
  U8 index;
  U8 digit;
  // Need a static for the decimal buffer, so that we can return the pointer.
  char static dec_buf[12];  // holds decimal string (10 digits + (sign) + null)

  digit = ( lz == LEADING_0 ) ? '0' : ' ';  // set for spaces ' ' or zero's '0'

  for ( index = 0; index < 10; ++index )
  {
    dec_buf[index] = digit;  // pre-load buffer with 0's or spaces
  }
  dec_buf[10] = '0';  // in case input num = 0, and no leading 0's
  dec_buf[11] = 0;    // add null for string operations

  index = 0;
  /* TODO: The while loop uses expensive modulo and divide operations, but we
  ** will optomize later if needed. -dalbert */
  while (( num > 0 ) && ( index < 12 ))
  {
    digit = (U8)(num % 10);             // extract last decimal digit from num
    dec_buf[10 - index] = '0' + digit;  // convert to ascii and store
    num = num / 10;                     // next decimal digit position
    index += 1;
    if ( index == 3 )
    {
      /* Put the decimal point here, and skip to next index position. */
      dec_buf[10 - index] = '.';
      index += 1;
    }
  }  // end while

  return  dec_buf;

}  // end printable_timestamp()
#endif

/*******************************************************************************
** Function:     hex_ascii
** Description:  Convert hex value to ascii value.
** Inputs:       hex value, range 0x0-0xF, in low nibble.
** Outputs:      ascii value, 0x30-0x39 for 0-9, or 0x41-0x46 for A-F.
*******************************************************************************/
U8 hex_ascii( unsigned char hex_nibble )
{
  if ( hex_nibble > 9 )
  {
    hex_nibble += 'A' - '9' - 1;  // difference from '9' to 'A' is 7
  }
  return  '0' + hex_nibble;

}  // end hex_ascii()

/*******************************************************************************
** Function:     ascii_hex
** Description:  Convert ascii value to hex value.
** Inputs:       ascii value, 0x30-0x39 for '0'-'9', or 0x41-0x46 for 'A'-'F'.
** Outputs:      hex value, range 0x0-0xF, in low nibble.
*******************************************************************************/
U8 ascii_hex( unsigned char ascii )
{
  ascii -= '0';
  if ( ascii > 9 )
  {
    ascii -= 7;   // difference between '9' and 'A' is 7
  }
  return  ascii;  // return the converted (now hex) vaule

}  // end ascii_hex()

/*******************************************************************************
** Function:     hex_2_bcd
** Description:  Convert a hex value to the BCD equivalent string.
**               Works on unsigned values now - more work to be done to handle
**               signed nums.
** Inputs:       U16 num, (0x0000-0xFFFF).
** Outputs:      char string, "0" thru "65535" (max of 5 chars + NULL).
*******************************************************************************/
char * hex_2_bcd( U16 hex_num )
{
  char static str1[6];     // declare string (static for return)
  U8 digit;
  U8 pos = 4;               // start with LSD string array position

  strcpy( str1, "    0" );  // pre-load char string, in case hex_num is 0

  while ( hex_num > 0 )
  {
    digit = hex_num % 10;
    str1[pos] = hex_ascii( digit );
    hex_num = hex_num / 10;
    pos--;
  }  // end while

  return  str1;

}  // end hex_2_bcd()

/*******************************************************************************
** Function:     power_func
** Description:  Compute power function X ^ Y, where X and Y are positive
**               integers, and the result will fit in a U32 value.  For example,
**               10 ^ 9 = 1,000,000,000 (max 32-bit value for a power of 10).
**               Note that this algorithm uses the "exponentiation by squaring"
**               method.  This algorithm (for our use, with caveats mentioned)
**               is more efficient and safer than the standard C pow() function.
**               The user must insure that the calling function does not provide
**               inputs that will overflow the result, since no extensive error
**               checking is provided.
** Inputs:       U8 for X(base), U8 for Y(exponent).
** Outputs:      U32 result.
*******************************************************************************/
U32 power_func( U8 base, U8 exp )
{
  U32 result = 1;
  U64 big_base = (U64)base;  // intermediate math can get big!

  while ( exp > 0 )
  {
    if ( exp & 1 )
    {
      result *= big_base;  // U32 cast needed??
    }
    big_base *= big_base;  // the last multiply may need U64 data type
    exp >>= 1;
  }  // end while
  return  result;

}  // end power_func()

/*******************************************************************************
** Function:     string2float
** Description:  String to float conversion.  Take the input from the parameter
**               substinrgs and convert to floating point (F32).  The goal is to
**               eliminate the code bloat and other problems using atoi, atof,
**               sscanf, etc.
** Inputs:       char - input string with the numeric representation.
** Outputs:      F32 value of the input string.
*******************************************************************************/
F32 string2float( char * str )
{

  F32 result = 0.0f;
  U8  dot_pos = 0;              // position of decimal point (from right)
  U8  n = 0;                    // string index
  U8  len = strlen( str );

  if ( str[0] == '-' || str[0] == '+' )
  {
    n = 1;   // skip to position 1 if + or - preceeds number
  }

  for ( ; n < len; ++n )  // n already set to position of first number digit
  {
    if ( str[n] == '.' )
    {
      dot_pos = len - n  - 1;  // decimal point position from right of string
    }
    else
    {
      result = result * 10.0f + ( str[n] - '0' );
    }
  }  // end for

  while ( dot_pos )
  {
    result /= 10.0f;  // adjust result based on decimal point position
    dot_pos--;
  }
  if ( str[0] == '-' )
  {
    result *= (-1.0f);  // adjust result if negative
  }
  return result;

}  // end string2float()

/*******************************************************************************
** Function:     IEEE_754_bytes_to_float
** Description:  Converts 4 unsigned data bytes into its equivalent floating
**               point value.  A union is used to perform the conversion.
**               Note that the internal memory representation in the STM32F0 is
**               little endian.
** Inputs:       U8 - input byte array with the numeric float representation.
**               Array must be in little-endian format, with the LS byte first.
** Outputs:      F32 value of the input array.
*******************************************************************************/
F32 IEEE_754_bytes_to_float( U8 * f_array )
{
  union float_byte_data_little_endian_ieee_754
  {
    F32  fp_num;       // This union needed to create the 32-bit floating...
    U8   fp_bytes[4];  // point nuber from the 4 bytes.
  }  real_bytes;

  /* Stuff the 4 bytes sent into the union byte array. */
  real_bytes.fp_bytes[0] = f_array[0];  // ls byte
  real_bytes.fp_bytes[1] = f_array[1];
  real_bytes.fp_bytes[2] = f_array[2];
  real_bytes.fp_bytes[3] = f_array[3];  // ms byte

  /* The union should now have the floating point representation. */
  return real_bytes.fp_num;

}  // end IEEE_754_bytes_to_float()

/*******************************************************************************
** Function:     IEEE_754_float_to_bytes
** Description:  Converts a floating point (F32) number into the IEEE-754
**               4 data bytes equivalent.  The union performs the conversion.
**               Note that the internal memory representation in the STM32F0 is
**               little endian.
** Inputs:       F32 numeric value.
** Outputs:      Byte array (U8) with the numeric float representation.
**               Array is in little-endian format, with the LS byte first.
*******************************************************************************/
U8 * IEEE_754_float_to_bytes( F32 real_num )
{
  U8  static data_bytes[4];    // declare string (static for return)

  union float_byte_data_little_endian_ieee_754
  {
    F32  fp_num;       // This union needed to extract the individual...
    U8   fp_bytes[4];  // bytes from a 32-bit floating point number.
  }  real_bytes;

  real_bytes.fp_num = real_num;
  /* Stuff the 4 bytes created from the union into the return array. */
  data_bytes[0] = real_bytes.fp_bytes[0];  // ls byte
  data_bytes[1] = real_bytes.fp_bytes[1];
  data_bytes[2] = real_bytes.fp_bytes[2];
  data_bytes[3] = real_bytes.fp_bytes[3];  // ms byte

  /* The array should now have the 4-byte floating point representation. */
  return data_bytes;

}  // end IEEE_754_float_to_bytes()

/*******************************************************************************
** Function:     temperature_convert
** Description:  Convert the temperature value to either Fahrenheit or Celsius.
**               This function uses floating point (real) number values.
** Inputs:       F32 - real temperature value in F or C, U8 - convert F or C.
** Outputs:      F32 - real temperature value in C or F.
*******************************************************************************/
F32 temperature_convert( F32 t_val, U8 f_c )
{
  F32 result;

  if ( f_c == C_to_F )
  {
    result = ( t_val * 1.8f ) + 32.0f;       // convert from C to F
  }
  else
  {
    result = ( t_val - 32.0f ) * 5.0f/9.0f;  // convert from F to C
  }
  return result;

}  // end temperature_convert()

/*******************************************************************************
** Function:     round_float
** Description:  Round a float to one, two or 0 decimal places.  Keep in mind
**               the inexactitude of floating point representation, and the
**               limitations of signed 32-bit integer values - but this method
**               should work for all our use cases.
**               NOTE: Positive values only!
** Inputs:       F32 - real (32-bit floating point) number,
**               U8 - number of decimal places to round (0, 1 or 2).
** Outputs:      F32 - real number.
*******************************************************************************/
F32 round_float( F32 val, U8 places )
{
  F32 result;

  /* Round and truncate the decimal digits. */
  if ( places == 0 )
  {
    result = floor( val + 0.5f );                       // round to 0 decimal
  }
  else if ( places == 1 )
  {
    result = ( floor( val * 10.0f + 0.5f )) / 10.0f;    // round to 1 decimal
  }
  else if ( places == 2 )
  {
    result = ( floor( val * 100.0f + 0.5f )) / 100.0f;  // round to 2 decimal
  }
  else
  {
    result = val;  // leave value alone until other places added...
  }

  return  result;

}  // end round_float()

/*******************************************************************************
** Function:     scale_value
** Description:  Takes a value between 0 and 100, and produces the PWM duty
**               cycle value (0 to 665).
**               If a=0, b=100, min=0, max=665, input value=X, then;
**               (((b - a)*(X - min))/(max - min)) + a
** Inputs:       U8 - value from 0 to 100 (duty cycle).
** Outputs:      U16 - value from 0 to 665 (PWM drive (pulse) value).
*******************************************************************************/
U16  scale_value( U8 duty )
{
  U16 pulse_val;

  if ( duty > 100 )
  {
    duty = 100;
  }
  /* The scaling function reduces to: */
  pulse_val = (U16)(( duty * 665 ) / 100  );

  if ( pulse_val > 631 )  // limit to 95% .... TODO:
  {
    pulse_val = 631;   // TEST TEST TEST - TODO:  see if limiting the TEC PWM eliminates the fan tach noise issue
  }

  return  pulse_val;

}  // end scale_value()

/*******************************************************************************
** Function:     limit_check
** Description:  Compares a floating point number to upper and lower limits and
**               returns;
**               1. the upper limit value if > upper limit,
**               2. the lower limit value if < lower limit,
**               3. the original value if between limit values.
** Inputs:       F32 value, upper limit, lower limit.
** Outputs:      F32 value.
*******************************************************************************/
F32  limit_check( F32 val, F32 upper, F32 lower )
{
  F32 rtn_value;

  if ( val > upper )
  {
    rtn_value = upper;
  }
  else if ( val < lower )
  {
    rtn_value = lower;
  }
  else
  {
    rtn_value = val;
  }

  return  rtn_value;

}  // end limit_check()

/*******************************************************************************
** Function:     limit_check_temperature
** Description:  Compare the real temperature input data to the range limits,
**               and return;
**               1. the upper limit value if > upper limit,
**               2. the lower limit value if < lower limit,
**               3. the original value if between limit values.
**               Limits depend on the board ID (Sonendo or ISC), SPH or SPL,
**               and C or F values. To make it easier to find the limits,
**               create a table value from these inputs, using binary multiples
**               to get unique values for each combination.
** Inputs:       U8 sph/spl identifier, F32 input value to compare to limits.
** Outputs:      F32 value.
*******************************************************************************/
F32  limit_check_temperature( F32 in_val, U8 sp )
{
  F32 rtn_value;
  F32 upper;
  F32 lower;
  U8  tu;     // temperature units, C or F
  U8  bID;    // board ID, Sonendo or ISC
  U8  tva;    // table value, 1 or 2 (for temp units)
  U8  tvb;    // table value, 4 or 8 (for sph/spl identifier)
  U8  tvc;    // table value, 16 or 32 (for board ID, Sonendo or ISC)

  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );  // temperature units
  tva = ( tu == DEGREES_C ) ? 1 : 2;                  // temperature table values

  tvb = ( sp == SP_HIGH ) ? 4 : 8;                    // sph/spl table values

  bID = board_cfg_get( );                             // board config ID
  tvc = ( bID == SONENDO_CONTROL ) ? 16 : 32;         // board ID table values

  switch ( tva + tvb + tvc )
  {
    case 1 + 4 + 16:  // degree C + SPH + Sonendo
      upper = SONENDO_SPH_UPPER_TEMP_LIMIT_C;
      lower = SONENDO_SPH_LOWER_TEMP_LIMIT_C;
      break;

    case 2 + 4 + 16:  // degree F + SPH + Sonendo
      upper = SONENDO_SPH_UPPER_TEMP_LIMIT_F;
      lower = SONENDO_SPH_LOWER_TEMP_LIMIT_F;
      break;

    case 1 + 8 + 16:  // degree C + SPL + Sonendo
      upper = SONENDO_SPL_UPPER_TEMP_LIMIT_C;
      lower = SONENDO_SPL_LOWER_TEMP_LIMIT_C;
      break;

    case 2 + 8 + 16:  // degree F + SPL + Sonendo
      upper = SONENDO_SPL_UPPER_TEMP_LIMIT_F;
      lower = SONENDO_SPL_LOWER_TEMP_LIMIT_F;
      break;

    case 1 + 4 + 32:  // degree C + SPH + ISC
      upper = ISC_SPH_UPPER_TEMP_LIMIT_C;
      lower = ISC_SPH_LOWER_TEMP_LIMIT_C;
      break;

    case 2 + 4 + 32:  // degree F + SPH + ISC
      upper = ISC_SPH_UPPER_TEMP_LIMIT_F;
      lower = ISC_SPH_LOWER_TEMP_LIMIT_F;
      break;

    case 1 + 8 + 32:  // degree C + SPL + ISC
      upper = ISC_SPL_UPPER_TEMP_LIMIT_C;
      lower = ISC_SPL_LOWER_TEMP_LIMIT_C;
      break;

    case 2 + 8 + 32:  // degree F + SPL + ISC
      upper = ISC_SPL_UPPER_TEMP_LIMIT_F;
      lower = ISC_SPL_LOWER_TEMP_LIMIT_F;
      break;

    default:
      break;

  }  // end switch

  /* Now the upper and lower limits are set.  Check the input value. */
  if ( in_val > upper )
  {
    rtn_value = upper;
  }
  else if ( in_val < lower )
  {
    rtn_value = lower;
  }
  else
  {
    rtn_value = in_val;
  }

  return  rtn_value;

}  // end limit_check_temperature()

#if 0
/*******************************************************************************
** Function:     debug_output
** Description:  Send the requested debug data out via the UART.
** Inputs:
** Outputs:
*******************************************************************************/
void  debug_output( U32 time_tick, U16 adc_cnt, F32 tC, U8 drive )
{
  char  str1[26];
  char  str2[26];

  /* Start by printing the timestamp. */
  strcpy( str1, printable_timestamp( time_tick, LEADING_0 ));
  send_debug( str1, NO_CRLF );

  strcpy( str1, "  " );  // spaces between timestamp and following message
  /* Add the text to define the debug output. */
  strcat( str1, DEBUG_DATA );
  /* Add the average ADC count value. */
  strcpy( str2, s16_to_string( adc_cnt, LEADING_SPACES ));
  strcat( str1, str2 );
  send_debug( str1, NO_CRLF );
  /* Add the real temperature in C value. */
  strcpy( str1, real_temp_to_string( tC ));
  send_debug( str1, NO_CRLF );
  /* Add the TEC drive % value. */
  strcpy( str1, s16_to_string( drive, LEADING_SPACES ));
  send_debug( str1, ADD_CRLF );

}  // end debug_output()

/*******************************************************************************
** Function:     fast_decimal_to_binary
** Description:  Convert decimal value to binary hex value.
** Inputs:       Range 0 to 4,294,967,295.
** Outputs:      32-bit unsigned int.
*******************************************************************************/
void  fast_decimal_to_binary( U32 dval, U32 * bval )
{
  for ( U8 i = 0; i < 32; ++i )
  {
    *(bval++) = (dval >> i) & 0x1;
  }  // end for

}  // end fast_decimal_to_binary()

/*******************************************************************************
** Function:     fast_binary_to_decimal
** Description:  Convert binary hex value to decimal value.
** Inputs:       32-bit unsigned int.
** Outputs:      Range 0 to 4,294,967,295.
*******************************************************************************/
void  fast_binary_to_decimal( unsigned long int * n, U32 * c )
{
  U8 i = 32;

  *n = 0;
  while ( --i )
  {
    *n <<= 1;
    *n += *(c + i);
  }  // end while

}  // end fast_binary_to_decimal()
#endif

/* convert.c ************************************************************ EOF */
