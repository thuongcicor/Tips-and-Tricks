/*******************************************************************************
**
** Project:     Marlow Compact TE Controller (ISC-controller).
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    pwm.c
**
** Description: This module controls the timer modules for PWM outputs that are
**              used to control the fans and TEC.  These functions directly
**              control the STM32 registers and board hardware; logic level
**              drivers for the fan PWM control, and MOSFET drivers for the
**              TEC PWM control and direction.
**
** Version/Author/Date/Description:
** 1   DMA   03/06/2018  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "main.h"
#include "pwm.h"
#include "adc.h"
#include "gpio.h"
#include "eeprom.h"
#include "config.h"
#include <math.h>
#include <stdlib.h>

TIM_HandleTypeDef htim1;  // fan pwm drive output
TIM_HandleTypeDef htim2;  // tec pwm drive output
TIM_HandleTypeDef htim3;  // fan tach input capture

/*******************************************************************************
** PID and FAN tach values structs.
*******************************************************************************/
static pid_values_t     pid;
static fan_ic_values_t  fan_tach[2];    // just 2 fans for now...
static U8               fan_speed[2];  // fan status, off, low, med, high

/*******************************************************************************
** Function:     tec_drivers_init
** Description:  Set up the initial conditions for the TEC control outputs and
**               control logic.  Logic enable signal (HB_LOG_nEN_Pin) is no
**               longer used in the H-bridge circuit, so just leave high.
**               The h-bridge direction pin (pol_rvrs - polarity reverse) will
**               switch polarity (high=heat, low=cool).  Refer to the 221-0144
**               schematic for circuit details and the logic truth-table for
**               controlling the h-bridge and preventing shoot-thru or illegal
**               states.  Once the logic is set for the H-bridge, then set the
**               PWM duty cycle value.
** Inputs:
** Outputs:
*******************************************************************************/
void  tec_drivers_init( void )
{
  /* Make sure h-bridge logic circuit starts off disabled, before the TEC PWM
  ** module is initialized. Also, since rev 2.0 hardware, the HB_LOG_nEN_Pin
  ** is no longer used.  Set this output pin high for now. */
  HAL_GPIO_WritePin( HB_LOG_nEN_GPIO_Port,  HB_LOG_nEN_Pin,  GPIO_PIN_SET );

  MX_TIM2_Init();               // TEC pwm STM32 internal module init
  tec_ctrl( NO_HEAT_NO_COOL );  // turn off the PWM output

}  // end tec_drivers_init()

/*******************************************************************************
** Function:     tec_ctrl
** Description:  This function starts or stops the TEC PWM output on channel 3,
**               timer instance 2.  Also sets the logic for heating and cooling.
**               Remember that the logic enable pin output on the STM32F0 is no
**               longer used - see schematic 221-0144 for truth table.
** Inputs:       heat_cool_t - HEAT, COOL or neither (off)
** Outputs:
*******************************************************************************/
void  tec_ctrl( heat_cool_t hc )
{
  static U8  on_now = NO;

  /* If we are in the error state, make sure TEC is off. */
  if (( hc == NO_HEAT_NO_COOL ) || ( ctrl_mode_get( ) == ERROR_MODE ))
  {
    /* Stop the TEC PWM on channel 3. */
    if ( HAL_TIM_PWM_Stop( &htim2, TIM_CHANNEL_3 ) != HAL_OK )
    {
      Error_Handler();
    }

    /* Set the h-bridge logic to turn off the TEC drivers.  (The heat/cool
    ** parameter is a don't care here). */
    HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_RESET );
    HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_RESET );

    /* Turn off both the BLUE and RED LEDs.  Don't turn off the RED LED if we
    ** are in an error mode. */
    if ( ctrl_mode_get( ) != ERROR_MODE )
    {
      led_setup( MEMB_RED, LED_OFF, 0, 0, 0 );
    }
    led_setup( MEMB_BLUE, LED_OFF, 0, 0, 0 );
    set_TEC_pwm_value( 0 );
    on_now = NO;
  }
  else
  {
    if ( on_now == NO )
    {
      on_now = YES;  // must issue NO_HEAT_NO_COOL command to reset this flag
      /* Start the TEC PWM on channel 3. */
      if ( HAL_TIM_PWM_Start( &htim2, TIM_CHANNEL_3 ) != HAL_OK )
      {
        Error_Handler();
      }

      if ( hc == HEAT )
      {
        /* Set MOSFET drive logic for heating. */
        HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_SET );
        HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_SET );
        led_setup( MEMB_RED, LED_CONTINUOUS, 0, 0, 0 );
      }
      else if ( hc == COOL )
      {
        /* Set MOSFET drive logic for cooling. */
        HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_RESET );
        HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_SET );
        led_setup( MEMB_BLUE, LED_CONTINUOUS, 0, 0, 0 );
      }
      else
      {
        // no change...
      }
    }
  }
}  // end tec_ctrl()

/*******************************************************************************
** Function:     fan_ctrl
** Description:  This function starts or stops the fan on the selected channel
**               using the duty cycle parameter.  For reference:
**               channel 1 - fan1 - J15 connector (near mounting hole on board)
**               channel 2 - fan3 - J16
**               channel 3 - fan4 - J17 connector (farthest from mounting hole)
**               channel 4 - fan2 - J18
** Inputs:       pwm output fan channel (U32), and fan speed (U8).
** Outputs:
*******************************************************************************/
void  fan_ctrl( U32 channel, U8 new_speed )
{
  U8  fan_update_needed = YES;  // default is fan needs to be updated...

  if ( new_speed == FAN_SPEED_OFF )
  {
    set_fan_duty_cycle( channel, FAN_SPEED_OFF );
//    HAL_Delay( 1 );  // not sure if this is needed...
//    fan_start_stop( FAN_STOP, channel );  // stop fan

    if ( channel == FAN1_CH )
    {
      fan_speed[0] = FAN_SPEED_OFF;
    }
    if ( channel == FAN2_CH )
    {
      fan_speed[1] = FAN_SPEED_OFF;
    }
  }
  else
  {
    if ( channel == FAN1_CH )
    {
      if ( fan_speed[0] == new_speed )
      {
        fan_update_needed = NO;  // speed already set, nothing more to do
      }
      else
      {
        if ( new_speed < 25 )
        {
          new_speed = 47;  // minimum fan speed (about 3000 RPM)
        }
        else if ( new_speed > 74 )
        {
          new_speed = 99;  // max out speed for all TEC pwm values > 74%
        }
        fan_speed[0] = new_speed;
      }
    }
    if ( channel == FAN2_CH )
    {
      if ( fan_speed[1] == new_speed )
      {
        fan_update_needed = NO;  // speed already set, nothing more to do
      }
      else
      {
        fan_speed[1] = new_speed;
      }
    }

    if ( fan_update_needed == YES )
    {
      /* Set the duty cycle, then start the fan. */
      set_fan_duty_cycle( channel, new_speed );
      HAL_Delay( 1 );  // not sure if this is needed...

      fan_start_stop( FAN_START, channel );  // start fan

//      /* Start the fan on the selected channel. */
//      if ( HAL_TIM_PWM_Start( &htim1, channel ) != HAL_OK )
//      {
//        Error_Handler();
//      }
    }
  }

}  // end fan_ctrl()

/*******************************************************************************
** Function:     fan_init
** Description:  Set up the GPIO pins used for fan control.  See the pwm.h
**               module for the correlation of fan numbers and timer control
**               channels.
**               IMPORTANT NOTE:  Due to a hardware buffer circuit snafu (Tony!)
**               the PWM buffer enable pins must be left low (low to enable,
**               high to disable).  High disables the buffer, but the PWM drive
**               output will still allow the fans to turn full on!
** Inputs:       pwm output fan channel (U32), and ON/OFF.
** Outputs:
*******************************************************************************/
void  fan_init( void )
{

  MX_TIM1_Init();  // FAN pwm
  MX_TIM3_Init();  // FAN tach

  /* Leave the enable low all the time, (see description above), and use the
  ** PWM duty control to turn fans on/off.  There is a pull-down on the fan
  ** enable line, so the output may glitch at power-up/reset, but this is
  ** usually too quick to cause any problems with fan operation. */
  HAL_GPIO_WritePin( FAN1_BUF_nOE_GPIO_Port, FAN1_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN2_BUF_nOE_GPIO_Port, FAN2_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN3_BUF_nOE_GPIO_Port, FAN3_BUF_nOE_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( FAN4_BUF_nOE_GPIO_Port, FAN4_BUF_nOE_Pin, GPIO_PIN_RESET );

  /* Init the variables used for fan tachometer monitor & rpm compute.
  ** We are only using 2 fans for ISC, (one for Sonendo), so just set up 2.
  ** For tach values, FAN1 (outside, index=0), and FAN2 (inside, index=1). */
  for ( U8 i = 0; i < 2; i++ )
  {
    fan_tach[i].in_capture1  = 0;
    fan_tach[i].in_capture2  = 0;
    fan_tach[i].diff_capture = 0;
    fan_tach[i].rpm_tach     = 0;
    fan_tach[i].capture_idx  = 0;

    fan_speed[i] = FAN_SPEED_OFF;
  }

}  // end fan_init()

/*******************************************************************************
** Function:     set_fan_duty_cycle
** Description:  Sets the PWM drive output to a duty cycle value 0 to 100%.
** Inputs:       pwm output channel (U32),  pwm drive value, 0-100, (U8).
** Outputs:
*******************************************************************************/
void  set_fan_duty_cycle( U32 channel, U8 pwm_drive )
{
  U16  fan_duty;
  TIM_OC_InitTypeDef sConfigOC;

  /* Limit check on timer channel. Only channels 1 thru 4 defined for fans. */
  if ( channel <= TIM_CHANNEL_4 )
  {
    /* Before changing duty, make sure the selected pwm channel is stopped. */
    fan_start_stop( FAN_STOP, channel );  // stop fan
//    HAL_TIM_PWM_Stop( &htim1, channel );

    /* Limit check is done in the "scale_value" function. */
    fan_duty = scale_value( pwm_drive );

    sConfigOC.OCMode       = TIM_OCMODE_PWM1;
    sConfigOC.Pulse        = fan_duty;
    sConfigOC.OCPolarity   = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
    sConfigOC.OCFastMode   = TIM_OCFAST_DISABLE;
    sConfigOC.OCIdleState  = TIM_OCIDLESTATE_RESET;
    sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;

    /* Set the output control config struct items. */
    if (HAL_TIM_PWM_ConfigChannel( &htim1, &sConfigOC, channel ) != HAL_OK)
    {
      _Error_Handler(__FILE__, __LINE__);
    }
  }

}  // end set_fan_duty_cycle()

/*******************************************************************************
** Function:     set_tec_duty_cycle
** Description:  Sets the PWM drive output to a duty cycle value 0 to 100%.
** Inputs:       pwm drive value, 0-100, (U8).
** Outputs:
*******************************************************************************/
void  set_tec_duty_cycle( U8 pwm_drive )
{
  U32  tec_duty_pulse_value;
  TIM_OC_InitTypeDef sConfigOC;

  /* If the PWM is already set to the value we want, we can skip this. */
  if ( pwm_drive != get_TEC_pwm_value( ) )
  {
    tec_ctrl( NO_HEAT_NO_COOL );     // set TEC drive OFF before changing duty cycle
    set_TEC_pwm_value( pwm_drive );  // save the new value

    /* Limit check is done in the "scale_value" function. */
    tec_duty_pulse_value = (U32)scale_value( pwm_drive );

    /* The TEC PWM drive, Port B, pin 10 (schematic name: TEC_PWM).  Configured
    ** on timer2, TIM_CHANNEL_3.  Only need to modify .pulse for duty cycle -
    ** leave other items in the sConfigOC struct at default values. */
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = tec_duty_pulse_value;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;

    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
    {
      _Error_Handler(__FILE__, __LINE__);
    }
  }
}  // end set_tec_duty_cycle()

/*******************************************************************************
** Function:     pid_calc
** Description:  This function must be called on a regular, periodic basis to
**               elliminate the need for d/dt calculations.  Also, for this
**               system, we can set the D gain term = 0.
** Inputs:       setpoint value, sensor temperature value.
** Outputs:      .
*******************************************************************************/
void  pid_calc( S16 sp, S16 sensor_temp )
{
//  static S16           old_error = 0;
  static U16           update_pwm_time_cnt = 0;
  static heat_cool_t   pid_init_condition = NOT_SET;
  U8   pid_out;

//  fan_ctrl( FAN1_CH, pwm );  // set fan speed based on TEC pwm value

  /* This section just takes care of the initial, first time thru this function.
  ** Once the heat/cool mode is set, then the normal PID control takes over. */
  if ( pid_init_condition == NOT_SET )
  {
    if ( sensor_temp > sp )
    {
      ctrl_mode_set( COOL_MODE );  // start off in cool mode
      tec_ctrl( COOL );
      pid_init_condition = COOL;
    }
    else if ( sensor_temp < sp )
    {
      ctrl_mode_set( HEAT_MODE );  // start off in heat mode
      tec_ctrl( HEAT );
      pid_init_condition = HEAT;
    }
    else
    {
      ctrl_mode_set( DEADBAND_MODE );
      tec_ctrl( NO_HEAT_NO_COOL );
      pid_init_condition = NO_HEAT_NO_COOL;  // right on target, 0 error!
    }
  }
  else
  {
    /* At this point, we have been thru the proportional band and initial PID
    ** conditions.  Use the PID output counts to determine if we need heating,
    ** cooling or nothing (error = 0). */
//    if ( sensor_temp > sp + 2 )
//    {
//      ctrl_mode_set( COOL_MODE );
//      tec_ctrl( COOL );
//
//      //    fan_ctrl( FAN1_CH, FAN_SPEED_2560 );
//    }
//    else if ( sensor_temp < sp - 2 )
//    {
//      ctrl_mode_set( HEAT_MODE );
//      tec_ctrl( HEAT );
//
//      //    fan_ctrl( FAN1_CH, FAN_SPEED_2560 );
//    }
//    else
//    {
//      /* We're close to setpoint (or right on)! Leave tec control in previous
//      ** mode, and reduce PWM by reseting accumulated error term. */
//      adjust_tec_pwm( RESET_ERROR_SUM );
//      if ( old_error < 0 )
//      {
//        old_error++;
//        pid_out = abs( old_error );  // pwm has to be positive value, 0 - 100
//      }
//      else if ( old_error > 0 )
//      {
//        old_error--;
//        pid_out = old_error;
//      }
//    }

    /* Error is negative for cool (sensor > sp), and positive for heat
    ** (sensor < sp). */
 //   old_error = sp - sensor_temp;

 //   if ( update_pwm_time_cnt++ > 10 )
 //   {
      pid_out = adjust_tec_pwm( sp - sensor_temp );
      update_pwm_time_cnt = 0;
      set_tec_duty_cycle( pid_out );
//    }
  }

}  // end pid_calc()

/*******************************************************************************
** Function:     adjust_tec_pwm
** Description:  Calculate the PWM output based on the error value.
**               Remember, the error value is x10, due to the SP and sensor
**               values.
** Inputs:       S16 error term.
** Outputs:      pid scaled value, duty cycle, 0-100.
*******************************************************************************/
U8  adjust_tec_pwm( S16 error )
{
  static F32  error_sum = 0;
  static F32  KI_term = 0;
  static F32  KP_KI = 0;
         F32  KP_term;
         F32  pid_pwm;
         F32  pgain;
         F32  igain;

//  error = error / 10;  // correct for the x10 value

  /* If error is positive, (sensor below sp), use heating pgain, igain terms.
  ** If error is negative, (sensor above sp), use cooling pgain, igain terms. */
//  if ( error > 0 )
//  {
//    pgain = get_pid_value( PGAIN_HEAT );
//    igain = get_pid_value( IGAIN_HEAT );
//  }
//  else
//  {
//    pgain = get_pid_value( PGAIN_COOL );
//    igain = get_pid_value( IGAIN_COOL );
//  }
//
  if ( error == RESET_ERROR_SUM )
  {
    error_sum = 0.0;
    KI_term = 0.0;
    KP_KI = 0.0;
  }

  // REDO THIS WITH *REAL* NUMBERS!


         //  KP_KI   = fabs(( KP_term + KI_term ) / 10.0f );  // remember, d term is 0

  if ( KP_KI > 0.1 )
  {
    ctrl_mode_set( HEAT_MODE );
    tec_ctrl( HEAT );
    pgain = get_pid_value( PGAIN_HEAT );
    igain = get_pid_value( IGAIN_HEAT );

  }
  else if ( KP_KI < -0.1 )
  {
    ctrl_mode_set( COOL_MODE );
    tec_ctrl( COOL );
    pgain = get_pid_value( PGAIN_COOL );
    igain = get_pid_value( IGAIN_COOL );
  }
  else
  {
    /* Must go thru deadband (TEC off) before switching from heat to cool, or
    ** vice-versa. */
    ctrl_mode_set( DEADBAND_MODE );
    tec_ctrl( NO_HEAT_NO_COOL );
    pgain = 0.5;    // just for the deadband...
    igain = 0.05;   // just for the deadband...
  }

  if ( error != RESET_ERROR_SUM )
  {
    /* Note: |error| should be <= 10 (due to max proportional band), so Pgain
    ** should probably be 10 or less, to keep max KP_KI <= 100. */
    KP_term = pgain * error;
    KI_term = KI_term + ( igain * error * 0.01f );  // (loop time 10mSec)
    /* Limit check on accumulated errors. */
    KI_term = limit_check_real( KI_term, ITERM_MAX, ITERM_MIN );
    KP_KI = ( KP_term + KI_term ) / 10.0f;  // remember, d term is 0
  }

  /* The PWM duty cycle is based on the KP_KI value. The duty cycle is from 0
  ** to 100 - need the abs of KP_KI. */
  if ( KP_KI < 0 )
  {
    pid_pwm = fabs( KP_KI );
  }
  else
  {
    pid_pwm = KP_KI;
  }
  /* Now bounds check the result. */
  pid_pwm = limit_check_real( pid_pwm, PID_OUT_MAX, PID_OUT_MIN );

  return  (U8)pid_pwm;

}  // end adjust_tec_pwm()

/*******************************************************************************
** Function:     pid_value_init
** Description:  Initialize the PID value struct with the saved data.
**               NOTE - this function assumes that the EE memory has valid data
**               for the PID floating point values.  If not valid, then load
**               the default value.  Floats are stored little-endian in the EE
**               for consistancy - the STM32F0 internal memory is little-endian.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  pid_value_init( void )
{
  U8   fp_bytes[4];  // floating point byte array
  F32  val;

  /* Load the P GAIN value for cooling. */
  fp_bytes[0] = (U8)get_ee_parameter( EE_PGAIN_COOL,     EE_DATA_8 );
  fp_bytes[1] = (U8)get_ee_parameter( EE_PGAIN_COOL + 1, EE_DATA_8 );
  fp_bytes[2] = (U8)get_ee_parameter( EE_PGAIN_COOL + 2, EE_DATA_8 );
  fp_bytes[3] = (U8)get_ee_parameter( EE_PGAIN_COOL + 3, EE_DATA_8 );

  if ( check_valid_float_bytes( fp_bytes ) == YES )
  {
    val = IEEE_754_bytes_to_float( fp_bytes );
  }
  else
  {
    val = PGAIN_COOL_ISC_DEFAULT;
  }
  set_pid_value( PGAIN_COOL, val );

  /* Load the I GAIN value for cooling. */
  fp_bytes[0] = (U8)get_ee_parameter( EE_IGAIN_COOL,     EE_DATA_8 );
  fp_bytes[1] = (U8)get_ee_parameter( EE_IGAIN_COOL + 1, EE_DATA_8 );
  fp_bytes[2] = (U8)get_ee_parameter( EE_IGAIN_COOL + 2, EE_DATA_8 );
  fp_bytes[3] = (U8)get_ee_parameter( EE_IGAIN_COOL + 3, EE_DATA_8 );

  if ( check_valid_float_bytes( fp_bytes ) == YES )
  {
    val = IEEE_754_bytes_to_float( fp_bytes );
  }
  else
  {
    val = IGAIN_COOL_ISC_DEFAULT;
  }
  set_pid_value( IGAIN_COOL, val );

  /* Load the D GAIN value for cooling. */
  set_pid_value( DGAIN_COOL, 0.0 );  // not using D gain for now

  /* Load the P GAIN value for heating. */
  fp_bytes[0] = (U8)get_ee_parameter( EE_PGAIN_HEAT,     EE_DATA_8 );
  fp_bytes[1] = (U8)get_ee_parameter( EE_PGAIN_HEAT + 1, EE_DATA_8 );
  fp_bytes[2] = (U8)get_ee_parameter( EE_PGAIN_HEAT + 2, EE_DATA_8 );
  fp_bytes[3] = (U8)get_ee_parameter( EE_PGAIN_HEAT + 3, EE_DATA_8 );

  if ( check_valid_float_bytes( fp_bytes ) == YES )
  {
    val = IEEE_754_bytes_to_float( fp_bytes );
  }
  else
  {
    val = PGAIN_HEAT_ISC_DEFAULT;
  }
  set_pid_value( PGAIN_HEAT, val );

  /* Load the I GAIN value for heating. */
  fp_bytes[0] = (U8)get_ee_parameter( EE_IGAIN_HEAT,     EE_DATA_8 );
  fp_bytes[1] = (U8)get_ee_parameter( EE_IGAIN_HEAT + 1, EE_DATA_8 );
  fp_bytes[2] = (U8)get_ee_parameter( EE_IGAIN_HEAT + 2, EE_DATA_8 );
  fp_bytes[3] = (U8)get_ee_parameter( EE_IGAIN_HEAT + 3, EE_DATA_8 );

  if ( check_valid_float_bytes( fp_bytes ) == YES )
  {
    val = IEEE_754_bytes_to_float( fp_bytes );
  }
  else
  {
    val = IGAIN_HEAT_ISC_DEFAULT;
  }
  set_pid_value( IGAIN_HEAT, val );

  /* Load the D GAIN value for heating. */
  set_pid_value( DGAIN_HEAT, 0.0 );  // not using D gain for now

  set_tec_duty_cycle( 0 );           // TEC duty/pwm drive = 0 initially

}  // end pid_value_init()

/*******************************************************************************
** Function:     get_pid_value
** Description:  Returns the current value from the PID values struct.
** Inputs:       pid_value_id_t - identifier for the PID struct value.
** Outputs:      pid_values_t - F32 value.
*******************************************************************************/
F32  get_pid_value( pid_value_id_t id )
{
  F32 rtn_val;

  switch ( id )
  {
    case PGAIN_COOL:   rtn_val = pid.p_gain_cool;   break;
    case IGAIN_COOL:   rtn_val = pid.i_gain_cool;   break;
    case DGAIN_COOL:   rtn_val = pid.d_gain_cool;   break;
    case PGAIN_HEAT:   rtn_val = pid.p_gain_heat;   break;
    case IGAIN_HEAT:   rtn_val = pid.i_gain_heat;   break;
    case DGAIN_HEAT:   rtn_val = pid.d_gain_heat;   break;
    default:           rtn_val = 0.0;               break;
  }  // end switch

  return  rtn_val;

}  // end get_pid_value()

/*******************************************************************************
** Function:     set_pid_value
** Description:  Sets the PID value for the specific struct item.
** Inputs:       pid_value_id_t - identifier for the PID struct value, and
**               pid_values_t - F32 value.
** Outputs:      .
*******************************************************************************/
void  set_pid_value( pid_value_id_t id, F32 val )
{
  switch ( id )
  {
    case PGAIN_COOL:   pid.p_gain_cool = val;   break;
    case IGAIN_COOL:   pid.i_gain_cool = val;   break;
    case DGAIN_COOL:   pid.d_gain_cool = val;   break;
    case PGAIN_HEAT:   pid.p_gain_heat = val;   break;
    case IGAIN_HEAT:   pid.i_gain_heat = val;   break;
    case DGAIN_HEAT:   pid.d_gain_heat = val;   break;
    default:                                    break;
  }  // end switch

}  // end set_pid_value()

/*******************************************************************************
** Function:     pid_calc_proportional
** Description:  Outside the proportional band, the TEC PWM is set to 100%.
**               Within the prop band limits, the normal (PI) control is used.
** Inputs:       S16 - setpoint, S16 - temperature, heat_cool_t - heat/cool.
** Outputs:      U8  - NO-not using prop control, YES-need normal PI control.
*******************************************************************************/
U8  pid_calc_proportional( S16 setpoint, S16 sensor )
{
  U8   propband;
  U8   prop_operation;

  /* Setpoint and sensor are x10, so make the prop band value x10. */
  propband = get_proportinal_band_value( ) * 10;

  if ( sensor > ( setpoint + propband ))
  {
    set_tec_duty_cycle( 100 );  // full cooling above the proportional band
    ctrl_mode_set( COOL_MODE );
    tec_ctrl( COOL );
    prop_operation = YES;
  }
  else if ( sensor < ( setpoint - propband ))
  {
    set_tec_duty_cycle( 100 );  // full heating below the proportional band
    ctrl_mode_set( HEAT_MODE );
    tec_ctrl( HEAT );
    prop_operation = YES;
  }
  else
  {
    prop_operation = NO;  // not outside prop band, so use PID control...
  }

  return  prop_operation;

}  // end pid_calc_proportional()

/*******************************************************************************
** Function:     fan_start_stop
** Description:  Low level control (start and stop) for the fan PWM output.
** Inputs:       U8 - START_FAN, STOP_FAN,
** Outputs:      .
*******************************************************************************/
void  fan_start_stop( U8 fan_on_off, U32 channel )
{

  if ( fan_on_off == FAN_START )
  {
    /* Start the fan on the selected channel. */
    if ( HAL_TIM_PWM_Start( &htim1, channel ) != HAL_OK )
    {
      Error_Handler();
    }
  }
  else
  {
    /* Stop the fan on the selected channel. */
    if ( HAL_TIM_PWM_Stop( &htim1, channel ) != HAL_OK )
    {
      Error_Handler();
    }
  }

}  // end fan_start_stop()

/*******************************************************************************
** Function:     set_TEC_pwm_value
** Description:  Sets the PWM drive (duty cycle, 0-100) value for the TEC
**               driver output.
** Inputs:       U8 - 0-100 (duty cycle).
** Outputs:      .
*******************************************************************************/
void  set_TEC_pwm_value( U8 pwm_drive )
{
  pid.pwm_val = pwm_drive;
}  // end set_TEC_pwm_value()

/*******************************************************************************
** Function:     get_TEC_pwm_value
** Description:  Gets the PWM drive (duty cycle, 0-100) value for the TEC
**               driver output.
** Inputs:       .
** Outputs:      U8 - 0-100 (duty cycle).
*******************************************************************************/
U8  get_TEC_pwm_value( void )
{
  return  pid.pwm_val;
}  // end get_TEC_pwm_value()

/*******************************************************************************
** Function:     set_proportinal_band_value
** Description:  Sets the PI controller proportional band value, which is the
**               diff between SPH and SPL.  Outside this band, the TEC PWM acts
**               like feed-forward.  Inside the band is normal PID control.
**               Max 10 degrees, and 0 (SPH=SPL) means disable prop band.
** Inputs:       S16 values for SPH and SPL (both are x10).
** Outputs:      .
*******************************************************************************/
void  set_proportinal_band_value( S16 SPH, S16 SPL )
{

  U16 pbv = abs( SPH - SPL ) / 10;

  if ( pbv > 10 )
  {
    pbv = 10;  // upper limit is 10 degree prop band
  }
  pid.prop_band = (U8)pbv;

}  // end set_proportinal_band_value()

/*******************************************************************************
** Function:     get_proportinal_band_value
** Description:  Gets the PI controller proportional band value, which is the
**               diff between SPH and SPL.
** Inputs:       .
** Outputs:      U8 - 0-10.
*******************************************************************************/
U8  get_proportinal_band_value( void )
{
  return  pid.prop_band;
}  // end get_proportinal_band_value()

/*******************************************************************************
** Function:     get_fan_tach
** Description:  Gets the fan tachometer value in RPM.  Since the fan tach
**               interrupt routine holds the last RPM value, even after the fan
**               has stopped, we can check the one-shot fan interrupt timer to
**               see if we need to clear the old, stale RPM values.
** Inputs:       U8 - fan number (1-4).
** Outputs:      U16 - RPM value.
*******************************************************************************/
U16  get_fan_tach( U8 fan )
{
  U16 rpm;

  if ( fan == 1 )
  {
    if ( task_timer_done_check( FAN1_TACH_IC_INTR ))
    {
      fan_tach[0].rpm_tach = 0;  // no tach interrupts lately, so report RPM=0
    }
    rpm = fan_tach[0].rpm_tach;
  }
  else if ( fan == 2 )
  {
    if ( task_timer_done_check( FAN2_TACH_IC_INTR ))
    {
      fan_tach[1].rpm_tach = 0;  // no tach interrupts lately, so report RPM=0
    }
    rpm = fan_tach[1].rpm_tach;
  }
  else
  {
    rpm = 0;  // only 2 fans for now...
  }
  return  rpm;

}  // end get_fan_tach()

/*******************************************************************************
** Function:     check_valid_float_bytes
** Description:  Check the 4 unsigned data bytes from EE memory to make sure
**               they will convert to a valid IEEE-754 floating point value.
**               A more comprehensive test would be better, but for now check
**               the most likely cause; initialized EEPROM PID values.
** Inputs:       U8 - input byte array with the numeric float representation.
** Outputs:      BOOL - YES (valid number) or NO (not valid).
*******************************************************************************/
BOOL  check_valid_float_bytes( U8 * fb )
{
  BOOL  valid = YES;  // assume valid to start off

  /* If all bytes are 0xFF, then we have a non-valid float number.  Most likely
  ** because the EEPROM was not initialized.  And yes, there are other
  ** combinations of invalid bytes, but for now... */
  if ( fb[0] == 0xFF && fb[1] == 0xFF && fb[2] == 0xFF && fb[3] == 0xFF )
  {
    valid = NO;
  }

  return  valid;

}  // end check_valid_float_bytes()

/*******************************************************************************
** Function:     MX_TIM1_Init
** Description:  Initialize the timer used for the fans - PWM drive output.
**               Up to 4 fans can be used on the 221-0144 hardware.
**               See pwm.h for table of fan numbers to board ref. des.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void MX_TIM1_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = preScale24KHz;  // recommended fan pwm frequency
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = PERIOD_VALUE;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* We will preset a duty cycle here, but normally, this is set in the
  ** fan_ctrl function.  Note that the FAN3 and FAN4 may be used as an external
  ** LED control output, and the duty cycle will affect brightness. */
  set_fan_duty_cycle( FAN1_CH, 50 );  // outside fan (J15) hot side
  set_fan_duty_cycle( FAN3_CH, 50 );  // external LED for Sonendo
  set_fan_duty_cycle( FAN4_CH, 50 );  // external LED for Sonendo
  set_fan_duty_cycle( FAN2_CH, 50 );  // inside fan (J18) cold side

  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;  // this should be OK for fans...
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim1);

}  // end MX_TIM1_Init()

/*******************************************************************************
** Function:     MX_TIM2_Init
** Description:  Initialize the timer used for the TEC - PWM drive output.
**               This is the only device using this timer instance.
**               TIM_CHANNEL_3 is used for PWM generation.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void MX_TIM2_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = preScale5_6KHz;  // TEC PWM freq (for now...)
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 665;                // period value
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* This is the TEC PWM drive, Port B, pin 10 (schematic name: TEC_PWM). */
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = (uint32_t)( 665 * 1.0 );  // start with 100% duty cycle
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim2);

}  // end MX_TIM2_Init()

/*******************************************************************************
** Function:     MX_TIM3_Init
** Description:  Initialize the timer used for the fan tachometer input.
**               There are up to 4 fans available on the 221-0144 board.
**               NOTE: the prescaler value was chosen to give us the proper
**               clock frequency to measure 25Hz to 250Hz signals, which will
**               translate to 750 to 7500 RPM.  This value allows us to use the
**               clock value to directly calculate the RPM value in the
**               interrupt callback function.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
static void MX_TIM3_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 29;  // see note in description...
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 0xFFFF;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* Start the Input Capture in interrupt mode.  (Outside fan for ISC). */
  if(HAL_TIM_IC_Start_IT(&htim3, FAN1_CH) != HAL_OK)
  {
    Error_Handler();  // Starting Error
  }

  /* Start the Input Capture in interrupt mode.  (Inside fan for ISC). */
  if(HAL_TIM_IC_Start_IT(&htim3, FAN2_CH) != HAL_OK)
  {
    Error_Handler();  // Starting Error
  }

}  // end MX_TIM3_Init()


/*******************************************************************************
** Function:     HAL_TIM_IC_CaptureCallback
** Description:  Conversion complete callback in non blocking mode.
**               The fans we use give 2 pulses per revolution, so the basic
**               formula is to multiply Hz (cycles per second) value by 30 to
**               get RPM (revs per minute).
**               NOTE: We need the fan tach task timer, because once the
**               interrupts stop, we're stuck with the old value of .rpm_tach.
**               If no interrupts have been detected in over 1 second, we will
**               consider the fans stopped, and then we can manually reset the
**               .rpm_tach values.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void HAL_TIM_IC_CaptureCallback( TIM_HandleTypeDef *htim )
{

  if ( htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1 )  // fan 1 channel
  {
    /* NOTE: structure index for fan 1 is 0. */
    if ( fan_tach[0].capture_idx == 0 )
    {
      /* Get the 1st Input Capture value */
      fan_tach[0].in_capture1 = HAL_TIM_ReadCapturedValue( htim, FAN1_CH );
      fan_tach[0].capture_idx = 1;
    }
    else if ( fan_tach[0].capture_idx == 1 )
    {
      /* Get the 2nd Input Capture value */
      fan_tach[0].in_capture2 = HAL_TIM_ReadCapturedValue( htim, FAN1_CH );

      /* Capture computation */
      if ( fan_tach[0].in_capture2 > fan_tach[0].in_capture1 )
      {
        fan_tach[0].diff_capture = ( fan_tach[0].in_capture2 - fan_tach[0].in_capture1 );
      }
      else if ( fan_tach[0].in_capture2 < fan_tach[0].in_capture1 )
      {
        /* 0xFFFF is max TIM1_CCRx value */
        fan_tach[0].diff_capture = (( 0xFFFF - fan_tach[0].in_capture1 ) + fan_tach[0].in_capture2 ) + 1;
      }
      else
      {
        /* Capture values are equal; reached the limit of frequency measures */
        Error_Handler();
      }
      /* RPM computation: based on prescaler value and clock APB1Clk. */
      fan_tach[0].rpm_tach = HAL_RCC_GetPCLK1Freq() / fan_tach[0].diff_capture;
      fan_tach[0].capture_idx = 0;
    }
    task_timer_start( FAN1_TACH_IC_INTR, 1000, ONE_SHOT );  // see note in description...
  }

  if ( htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4 )  // fan 2 channel - remember re-ordering!
  {
    /* NOTE: structure index for fan 2 is 1. */
    if ( fan_tach[1].capture_idx == 0 )
    {
      /* Get the 1st Input Capture value */
      fan_tach[1].in_capture1 = HAL_TIM_ReadCapturedValue( htim, FAN2_CH );
      fan_tach[1].capture_idx = 1;
    }
    else if ( fan_tach[1].capture_idx == 1 )
    {
      /* Get the 2nd Input Capture value */
      fan_tach[1].in_capture2 = HAL_TIM_ReadCapturedValue( htim, FAN2_CH );

      /* Capture computation */
      if ( fan_tach[1].in_capture2 > fan_tach[1].in_capture1 )
      {
        fan_tach[1].diff_capture = ( fan_tach[1].in_capture2 - fan_tach[1].in_capture1 );
      }
      else if ( fan_tach[1].in_capture2 < fan_tach[1].in_capture1 )
      {
        /* 0xFFFF is max TIM1_CCRx value */
        fan_tach[1].diff_capture = (( 0xFFFF - fan_tach[1].in_capture1 ) + fan_tach[1].in_capture2 ) + 1;
      }
      else
      {
        /* Capture values are equal; reached the limit of frequency measures */
        Error_Handler();
      }
      /* RPM computation: based on prescaler value and clock APB1Clk. */
      fan_tach[1].rpm_tach = HAL_RCC_GetPCLK1Freq() / fan_tach[1].diff_capture;
      fan_tach[1].capture_idx = 0;
    }
    task_timer_start( FAN2_TACH_IC_INTR, 1000, ONE_SHOT );  // see note in description
  }
}  // end HAL_TIM_IC_CaptureCallback()

/* pwm.c **************************************************************** EOF */
