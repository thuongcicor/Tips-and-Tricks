/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    initial_tasks.c
**
** Description: This module initializes the major operational tasks and sets up
**              the peripherals, (LCD module, fans, thermistors, audio beeper
***             eeprom, LEDs, pushbuttons, USART and TECs.  Since the timing is
**              somewhat slow for some of these devices, this init_active time
**              can be 5 to 10 seconds (including splash-screen on time).  Also,
**              the TECs should not be started until at least 5 seconds after
**              power-up due to the soft-start circuitry.
**
** Version/Author/Date/Description:
** 1   DMA   02/20/2017  Began coding.
** 2   DMA   12/21/2018  Added new GPIO init for RS-232 pins.
** 3   DMA   03/17/2019  Split up the init_tasks function, so that the splash
**                       screen could be called in MANUAL mode after PWR_PB.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "serial_comm.h"
#include "main.h"
#include "eeprom.h"
#include "config.h"
#include "gpio.h"
#include "lcd.h"
#include "keys.h"
#include "adc.h"
#include "beep.h"
#include "pwm.h"
#include <string.h>
#include "intrinsics.h"  // need for instrinsic __nop function

/*******************************************************************************
** Function:     initial_hardware_and_parms
** Description:  This function handles the major peripheral initializations and
**               the setup of the hardware, and parameters and variables.
**               This function is called once at power-up/reset, and then
**               control reverts back to main. Soft delays can be tolerated in
**               this function.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  initial_hardware_and_parms( void )
{
  U8     om_val;  // operational mode

  /* Reset all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured STM32 peripherals and input/output pins. */
  MX_GPIO_Init();

  /* Initialize the TEC PWM module and logic control. */
  tec_drivers_init( );

  /* Initialize the fan control (4 channels). */
  fan_init( );

  /* Make sure debug output pin starts low - used for scope timing measurements. */
  debug_pin_output( OUTPUT_LOW );

  /* Init the various control and operational mode settings, and read jumper
  ** settings on the 221-0144 board to determine configuration. */
  control_modes_init( );

  /* Make sure all LEDs are off at the start. */
  led_init( );

  /* Pushbutton key values initialize. */
  pb_init( PB_ALL );

  /* Set up the I2C module on the STM32F0 micro, and the address lines. */
  I2C_init( );

  /* Setup the UART comm channel for CLI interface. */
  uart_init( );

  /* Setup the ADC channels for the thermistors and voltage monitors. */
  adc_init( );

  /* Start the LCD initialization process - continues in the while loop. */
  lcd_init( LCD_RESET );

  /* Init the various menu options and mode control parameters. */
//  menu_init( );

  /* Init the various beeper control struct items. */
  beeper_init( );

  /* Load the initial non-volatile (EE) data into the SRAM copy memory. */
  load_initial_ee_data( );

  /* Load the initial totalizer values. */
  totals_init( );

  /* Load the pid cool and heat values, initial TEC PWM drive value. */
  pid_value_init( INIT_PID_VALS );

  /* Load the stored or default setpoint values, both high/low, both C/F. */
  sp_value_init( );

  /* Disable any LED activity until we are ready to start. */
  led_setup( ALL_LEDS, LED_NOTHING, 0, 0, 0 );

  /* Get operating mode; either Manual or Auto start. ISC default is Manual. */
  om_val = (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 );

  /* LCD backlight control - turn on for auto mode, off for manual. */
  if ( om_val == AUTO_MODE )
  {
    lcd_backlight_control( ON );
    ctrl_mode_state( RUN_MODE, SET_DATA );
    /* Sound the beeper, REV_2_HARDWARE only.  OK to leave this for rev. 3,
    ** since this pin will be a no-connect for REV_3_HARDWARE. */
    for ( U8 x = 0; x < 255; x++ )
    {
      HAL_GPIO_TogglePin( BUZZER_FB_GPIO_Port, BUZZER_FB_Pin );
      HAL_Delay( 1 );  // 1 mSec to give approx. 1000Hz beep
    }  // end for
  }
  else
  {
    lcd_backlight_control( OFF );  // in manual mode, so start with LCD off
    ctrl_mode_state( PWR_OFF_MODE, SET_DATA );
    set_manual_ok_to_start_flag( NO );  // not ready for LCD yet...
  }
}  // end initial_hardware_and_parms()

/*******************************************************************************
** Function:     initial_tasks
** Description:  This function handles the major peripheral task init, and
**               gets the main tasks ready for normal operations.
**               Some small soft delays can be tolerated in this function.
** Inputs:       FULL_INIT - perform all actions, full task timing.    // <--- TODO items to add...
**               FAST_INIT - perform all actions, with reduced task times.
**               SPLASH_ONLY - just the copyright and version LCD screens.
** Outputs:      none.
*******************************************************************************/
void  initial_tasks( void )
{
  U8     init_active = TRUE;
  F32    sensor;
  U32    old_tick_cnt;
  U32    new_tick_cnt;
  U32    init_loop_time_ticks = 0;
  U8     om_val;               // operational mode
  U8     led_update_flag = 1;  // quick time loop flag

  init_tasks_t  next_task = INIT_LCD_INIT_TASK;  // initial starting task

  /* Set up the init loop timing values.*/
  old_tick_cnt = HAL_GetTick();
  new_tick_cnt = old_tick_cnt;

  /* The initialization loop.  This allows for various slow init processes
  ** and POST to complete before the main super loop starts. */
  while ( init_active )
  {
    while ( old_tick_cnt == new_tick_cnt )
    {
      new_tick_cnt = HAL_GetTick();
      /*
      ** other quick, non-synchronous code can go here...
      */
      if ( led_update_flag )
      {
        update_led_ctrl_events( );  // perform configured LED actions on periodic basis
        led_update_flag = 0;        // just call once per quick loop time
      }
    }  // end while

    /* At least 1 mSec has elapsed at this point. */
    old_tick_cnt = new_tick_cnt;
    ++init_loop_time_ticks;
    led_update_flag = 1;  // reset flag for next quick loop time

    /* Do one of the tasks listed below.  Cycle thru the list until all tasks
    ** have completed.  Some tasks will complete in a single call, and others
    ** will take multiple passes thru this switch to complete. */
    switch ( next_task )
    {
      case INIT_LCD_INIT_TASK:
        if ( board_cfg_get( ) == SONENDO_CONTROL )
        {
          /* Skip all the LCD functions for Sonendo... */
          next_task = INIT_ADC_CAL_TASK;
        }
        else
        {
          /* Continue with the LCD init process... */
          if ( LCD_DONE == lcd_init( LCD_CONTINUE ) )
          {
            next_task = INIT_LCD_CUSTOM_TASK;
          }
        }
        break;

      case INIT_LCD_CUSTOM_TASK:
        /* After LCD init sequence done, load CGRAM (custom icons and images).
        ** This is a one-pass func call, with some (short) delays. */
        load_custom_lcd_images( LOAD_ALL );
        next_task = INIT_LCD_SPLASH_TASK;
        break;

      case INIT_LCD_SPLASH_TASK:
        /* Skip the splash screen display if in Manual start-up mode. */
        om_val = (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 );
        if ( om_val != MANUAL_MODE )
        {
          splash_screen( SPLASH_FULL );
        }
        next_task = INIT_ADC_CAL_TASK;
        break;

      case INIT_ADC_CAL_TASK:
        adc_cal();                        // do we need the value from this?
        init_loop_time_ticks = 0;         // reset for next task
        next_task = INIT_LED_ONB_RED_TASK;
        break;

      case INIT_LED_ONB_RED_TASK:
        led_setup( ONB_RED, LED_SINGLE, 400, 0, 1 );  // on-board RED, .5 sec
        next_task = INIT_LED_ONB_RED_CONT_TASK;
        break;

      case INIT_LED_ONB_RED_CONT_TASK:
        /* If we are done with the LED task, move on to the next one. */
        if ( LED_OFF == led_status( ONB_RED ))
        {
          next_task = INIT_LED_ONB_WHITE_TASK;
        }
        break;

      case INIT_LED_ONB_WHITE_TASK:
        led_setup( ONB_WHITE, LED_SINGLE, 400, 0, 1 );  // on-board WHITE, .5 sec
        next_task = INIT_LED_ONB_WHITE_CONT_TASK;
        break;

      case INIT_LED_ONB_WHITE_CONT_TASK:
        /* If we are done with the LED task, move on to the next one. */
        if ( LED_OFF == led_status( ONB_WHITE ))
        {
          next_task = INIT_LED_MEMB_RED_TASK;
        }
        break;

      case INIT_LED_MEMB_RED_TASK:
        led_setup( MEMB_RED, LED_SINGLE, 400, 0, 1 );  // membrane RED, .5 sec
        next_task = INIT_LED_MEMB_RED_CONT_TASK;
        break;

      case INIT_LED_MEMB_RED_CONT_TASK:
        /* If we are done with the LED task, move on to the next one. */
        if ( LED_OFF == led_status( MEMB_RED ))
        {
          next_task = INIT_LED_MEMB_BLUE_TASK;
        }
        break;

      case INIT_LED_MEMB_BLUE_TASK:
        led_setup( MEMB_BLUE, LED_SINGLE, 400, 0, 1 );  // membrane BLUE, .5 sec
        next_task = INIT_LED_MEMB_BLUE_CONT_TASK;
        break;

      case INIT_LED_MEMB_BLUE_CONT_TASK:
        /* If we are done with the LED task, move on to the next one. */
        if ( LED_OFF == led_status( MEMB_BLUE ))
        {
          next_task = INIT_LED_MEMB_GREEN_TASK;
        }
        break;

      case INIT_LED_MEMB_GREEN_TASK:
        led_setup( MEMB_GREEN, LED_SINGLE, 400, 0, 1 );  // membrane GREEN, .5 sec
        next_task = INIT_LED_MEMB_GREEN_CONT_TASK;
        break;

      case INIT_LED_MEMB_GREEN_CONT_TASK:
        /* If we are done with the LED task, move on to the next one. */
        if ( LED_OFF == led_status( MEMB_GREEN ))
        {
          next_task = INIT_TASKS_COMPLETE;
        }
        break;

      default:
        /* Use this default case to fill the ADC arrays so they are ready to go
        ** after init tasks completes. */
        update_adc_events( );
        break;

    }  // end switch


    if ( init_loop_time_ticks == 750 )
    {
      audio_pwm_on_off( ON );  // use preprocessor define "REV_3_BOARD" to separate old and new beeper code...
    }
    if ( init_loop_time_ticks == 1000 )
    {
      audio_pwm_on_off( OFF );  // use preprocessor define "REV_3_BOARD" to separate old and new beeper code...
    }

    /* Wait for a few more seconds before ending init tasks. */
    if ( init_loop_time_ticks > 3500 )
    {
      init_active = FALSE;           // done with initialization loop
      init_loop_time_ticks  = 0;     // reset tick count
    }
  }  // end while (init_active)

  /* We should have some good sensor readings by now.
  ** Init the ROC averaging array.                     (NEED TO LOOK AT CURRENT TEMP_UNITS SETTING....*/
  sensor = get_current_temperature( 0, DEGREES_C );
  rate_of_cooling( sensor, SETUP_VAL );

}  // end initial_tasks()

/*******************************************************************************
** Function:     get_stm32_info
** Description:  Returns the various values read from the STM32F0 on-chip
**               status registers.  Refer to the STM32F0 ARM documentation for
**               the specific encoding for the unique chip ID format.
** Inputs:       ID for the specific status register.
** Outputs:      U32 value.
*******************************************************************************/
U32 get_stm32_info( stm32_reg_t reg_id )
{
  U32  rtn_val;

  switch ( reg_id )
  {
    case UID01:          // unique ID for x/y location on manufacture wafer
      rtn_val = *UID1;
      break;

    case UID02:          // unique ID for manufacturing lot num & wafer num
      rtn_val = *UID2;
      break;

    case UID03:          // unique ID for manufacturing wafer number
      rtn_val = *UID3;
      break;

    case FLASH_M:        // on-chip stored value for flash memory size
      rtn_val = *MEM_ID;
      break;

    case DEVICE_ID:      // identifier for the STM32F07x device
      rtn_val = *DEV_ID;
      break;

    case INTVREFCAL:     // internal voltage reference (calibration)
      rtn_val = (U32)*VREFINT_CAL_ADDR;
      break;

    case OPTIONS:        // option bytes (for locking the flash contents)
      rtn_val = *OPTION_BYTES;
      break;

    case INT30T:         // internal temperature reference calibration 30C value
      rtn_val = (U32)*TEMP30_CAL_ADDR;
      break;

    case INT110T:        // internal temperature reference calibration 110C value
      rtn_val = (U32)*TEMP110_CAL_ADDR;
      break;

    default:
      rtn_val = 0;
      break;

  }  // end switch

  return  rtn_val;

}  // end get_stm32_info()

/*******************************************************************************
** Function:     MX_GPIO_Init
** Description:  This section of code comes from the STM32Cube MX tool, and is
**               modified for the specifics of this application.  To aid
**               debugging, the schematic net names are kept for the various
**               I/O pin signals.  This function only inits the digital input
**               and output - the special function I/O is initialized in other
**               setup functions.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
static void MX_GPIO_Init( void )
{
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /* PORT A: Configure all GPIO pin *outputs* on port A. */
  HAL_GPIO_WritePin(GPIOA, LCD_BKLT_EN_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   = LCD_BKLT_EN_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* PORT B: Configure all GPIO pin *outputs* on port B. */
  HAL_GPIO_WritePin(GPIOB, FAN4_BUF_nOE_Pin | FAN3_BUF_nOE_Pin |
                           FAN2_BUF_nOE_Pin | HB_POL_RVRS_Pin  |
                           HB_LOG_nEN_Pin   | HB_LOG_LVL_Pin   |
                           MEM_WP_Pin       | MEM_A0_Pin,      GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   =  FAN4_BUF_nOE_Pin | FAN3_BUF_nOE_Pin |
                           FAN2_BUF_nOE_Pin | HB_POL_RVRS_Pin  |
                           HB_LOG_nEN_Pin   | HB_LOG_LVL_Pin   |
                           MEM_WP_Pin       | MEM_A0_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* PORT C: Configure all GPIO pin *outputs* on port C. */
  HAL_GPIO_WritePin(GPIOC, LED0_CTRL_Pin | LED1_CTRL_Pin | LED2_CTRL_Pin |
                           BUZZER_FB_Pin | LCD_EN_Pin    | RS232_EN_Pin  |
                           LCD_RS_Pin    | LCD_RW_Pin,   GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   =  LED0_CTRL_Pin | LED1_CTRL_Pin | LED2_CTRL_Pin |
                           BUZZER_FB_Pin | LCD_EN_Pin    | RS232_EN_Pin  |
                           LCD_RS_Pin    | LCD_RW_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* PORT C: Configure all GPIO pin *inputs* on port C. */
  GPIO_InitStruct.Pin   = MEMB_PWR_SW_Pin   | MEMB_SET_SW_Pin | RS232_BAD_IN_Pin |
                          MEMB_D_ARR_SW_Pin | MEMB_U_ARR_SW_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* PORT D: Configure all GPIO pin *outputs* on port D. */
  HAL_GPIO_WritePin(GPIOD, LCD_DB0_Pin | LCD_DB1_Pin | LCD_DB2_Pin |
                           LCD_DB3_Pin | LCD_DB4_Pin | LCD_DB5_Pin |
                           LCD_DB6_Pin | LCD_DB7_Pin | DEBUG_OUT_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   =  LCD_DB0_Pin | LCD_DB1_Pin | LCD_DB2_Pin |
                           LCD_DB3_Pin | LCD_DB4_Pin | LCD_DB5_Pin |
                           LCD_DB6_Pin | LCD_DB7_Pin | DEBUG_OUT_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* PORT D: Configure all GPIO pin *inputs* on port D. */
  GPIO_InitStruct.Pin   = CONF_FW_BIT0_Pin | CONF_FW_BIT1_Pin | CONF_FW_BIT2_Pin |
                          CONF_FW_BIT3_Pin | CONF_FW_BIT4_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* PORT E: Configure all GPIO pin *outputs* on port E. */
  HAL_GPIO_WritePin(GPIOE, FAN1_BUF_nOE_Pin | MEM_A1_Pin |
                           MEM_A2_Pin,      GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   = FAN1_BUF_nOE_Pin | MEM_A1_Pin | MEM_A2_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /* PORT F: Configure all GPIO pin *outputs* on port F. */
  HAL_GPIO_WritePin(GPIOF, LED3_CTRL_Pin | LED4_CTRL_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   = LED3_CTRL_Pin | LED4_CTRL_Pin;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

}  // end MX_GPIO_Init()

/* initial_tasks.c ****************************************************** EOF */
