/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    beep.c
**
** Description: This module contains functions associated with the audio
**              (beeper) funcionality.  This electromagnetic buzzer must be
**              driven with a square wave, with 3200Hz typical frequency at
**              50% duty cycle.  The frequency can be varied to produce
**              different tones and pitches, for key presses and alarm/warning
**              indications.
**              NOTE:  The beeper SHOULD be PWM driven, but the output pin for
**              the beeper on PC8 can only use TIM3_CH3.  This timer channel is
**              already used by the fan tach input.  So we must manually cycle
**              the output pin to create the beep.  (Or we can lose the tach
**              for fan 3). OY!
**              UPDATE: As of rev. 3 boards, (12/2018), we have the audio output
**              moved to PB15, and we can use PWM on this pin (TIM15, CH2).
**
** Version/Author/Date/Description:
** 1   DMA   03/12/2018  Began coding.
** 2   DMA   12/21/2018  New code for audio/beeper with PWM.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "main.h"
#include "gpio.h"
#include "beep.h"
#include "lcd.h"
#include "intrinsics.h"  // need for instrinsic __nop function

beeper_t  beeper;          // declare struct for beeper control variables
TIM_HandleTypeDef htim15;  // audio/beeper pwm drive output

/*******************************************************************************
** Function:     beeper_init
** Description:  Initialize the beeper control structure.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void beeper_init( void )
{

  beeper.active = FALSE;
  beeper.type   = NOTHING;  // no type defined yet
  beeper.output = ON;       // flag to control sound output (default ON)
  beeper.timer  = 0;        // counts for on-off timing
  beeper.on_counts = 0;     // counts for beeper on state
  beeper.off_counts = 0;    // counts for beeper off state
  beeper.cycle = 0;         // counts the on-off cycles (sequence)
  beeper.repeat = 0;        // number of times to repeat on-off sequence

  MX_TIM15_Init(  );        // init internal STM32 timer for the beeper

}  // end beeper_init()

/*******************************************************************************
** Function:     beeper_trigger
** Description:  Calls from the pushbutton event code will set the beeper state
**               to "active".  This state flag will be used in the beeper_event
**               function to initiate the audio output.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void beeper_trigger( void )
{
  beeper.active = TRUE;

  task_timer_start( BEEPER, 50, ONE_SHOT );
  audio_pwm_on_off( ON );

}  // end beeper_trigger()

/*******************************************************************************
** Function:     beeper_update
** Description:  Called from the quick loop within the main super loop timer.
**               To achieve the proper beep audio output, we need a square wave
**               output from 1000 to 3200Hz.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void beeper_update( void )
{
  if ( beeper.active == TRUE )
  {
    BEEP_TOGGLE;
  }

}  // end beeper_update()

/*******************************************************************************
** Function:     beeper_control
** Description:  This flag controls the audio beeper output.  It is used to
**               turn the beeper off, (when debugging, for example), or back
**               on, for normal operation.  The default is ON.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  beeper_control( BOOL on_off )
{

  if ( on_off == ON )
  {
    beeper.output = ON;       // flag to control sound output (default ON)
  }
  else
  {
    beeper.output = OFF;      // turn off sound output for debugging
  }

}  // end beeper_control()

/*******************************************************************************
** Function:     update_beeper_events
** Description:  Call this function periodically for audio/beeper timing.
**               For now, this function will control the beeper off time.
**               Once a beep has completed, another beep will not be allowed
**               until the off time count has elapsed.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  update_beeper_events( void )
{

  if ( beeper.off_counts > 0 )
  {
    beeper.off_counts--;
  }

  if ( task_timer_done_check( BEEPER ) )
  {
    audio_pwm_on_off( OFF );
  }

}  // end update_beeper_events()

/*******************************************************************************
** Function:     audio_pwm_on_off
** Description:  Start or stop the timer associated with the audio indicator on
**               PB15 (AUDIO_FB_Pin), which is new as of rev. 3 hardware.
**               Since using breakpoints for debugging can result in a locked-
**               on beeper, we can use the serial command to turn it off.
**               Always defaults to ON, not saved in EEPROM.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  audio_pwm_on_off( U8 on_off )
{

  if ( beeper.output == ON )
  {
    if ( on_off == OFF )
    {
      if ( HAL_TIM_PWM_Stop( &htim15, TIM_CHANNEL_2 ) != HAL_OK )
      {
        Error_Handler();
      }
    }
    else
    {
      if ( HAL_TIM_PWM_Start( &htim15, TIM_CHANNEL_2 ) != HAL_OK )
      {
        Error_Handler();
      }
    }
  }
}  // end audio_pwm_on_off()

/*******************************************************************************
** Function:     MX_TIM15_Init
** Description:  Initialize the timer used for the audio/beeper output.
**               Keep duty around 50%, and vary frequency for different sounds.
**               Typical frequency value is 3200Hz.
**               TIM_CHANNEL_2, PB15 is used for PWM generation.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void MX_TIM15_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 480;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 100;                // period value
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim15) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = (uint32_t)( 50 );  // start with 50% duty cycle
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim15);

}  // end MX_TIM15_Init()

/* beep.c *************************************************************** EOF */
