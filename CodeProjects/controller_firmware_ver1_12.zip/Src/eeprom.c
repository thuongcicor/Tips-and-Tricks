/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    eeprom.c
**
** Description: The EEPROM uses an I2C interface.  This may be a 24C64, 24C256,
**              or any other part in this family (minimum capacity of 4K bytes).
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/18/2019  Mods to the load init ee data function.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "eeprom.h"
#include "adc.h"
#include "pwm.h"
#include "config.h"
#include "versions.h"

I2C_HandleTypeDef  hi2c1;       // struct handle with I2C config info
HAL_StatusTypeDef  I2C_status;  // OK, busy, error or timeout

U8  TX_i2c_buf[32];             // transmit buffer (xmit up to 32 bytes)
U8  RX_i2c_buf[32];             // receive buffer (read up to 32 bytes)

/* This byte array holds a copy of the non-vol config and parameter data.
** See documentation (Excel spreadsheet) for list of all non-vol data items. */
U8  EE_non_vol_data[EE_ADDRESS_LIMIT];

/*******************************************************************************
** Function:     I2C_init
** Description:  Set up the I2C module in the STM32F0 micro.
**               Make sure this function is called after the GPIO init function.
**               There is one EEPROM device on the 221-0144, and all 3 address
**               lines are set low (0), and the WP (write protect) line is low
**               to enable writes.
**               The I2C address is 0xA0 (write) and 0xA1 (read).
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  I2C_init( void )
{

  MX_I2C1_Init();

  /* Set the three address lines low, and set the write protect line low to
  ** enable EEPROM writes. */
  HAL_GPIO_WritePin( MEM_A0_GPIO_Port, MEM_A0_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( MEM_A1_GPIO_Port, MEM_A1_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( MEM_A2_GPIO_Port, MEM_A2_Pin, GPIO_PIN_RESET );
  HAL_GPIO_WritePin( MEM_WP_GPIO_Port, MEM_WP_Pin, GPIO_PIN_RESET );

}  // end I2C_init()

/*******************************************************************************
** Function:     MX_I2C1_Init
** Description:  This section of code comes from the STM32Cube MX tool, and is
**               modified for the specifics of this application.  To aid
**               debugging, the schematic net names are kept for the various
**               I/O pin signals.  This function inits the special functions
**               that control the I2C interface peripheral.  Used for EEPROM.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  MX_I2C1_Init( void )
{

  hi2c1.Instance              = I2C1;
  hi2c1.Init.Timing           = EEPROM_TIMING;
  hi2c1.Init.OwnAddress1      = 0;
  hi2c1.Init.AddressingMode   = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode  = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2      = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode  = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode    = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /* Configure Analogue filter */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /* Configure Digital filter */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}  // end MX_I2C1_Init()

/*******************************************************************************
** Function:     i2c_ee_read
** Description:  Read a block of memory from the external EEPROM.  This is a
**               blocking mode read.  The parameters for the read func:
**               * hi2c1 - pointer to a I2C_HandleTypeDef structure.
**               * EE_ADRS_WR- target device address, 7 bits (shift??)
**               * MemAddress Internal memory address
**               * MemAddSize Size of internal memory address
**               * pData Pointer to data buffer
**               * Size Amount of data to be sent (read)
**               * Timeout duration
** Inputs:       Internal ee memory address, size of data block to read.
** Outputs:      none.
*******************************************************************************/
void  i2c_ee_read( U16 ee_mem, U16 block_size )
{
  /*   add limit checks on the address and size........... */
  I2C_status = HAL_I2C_Mem_Read ( &hi2c1,
                                 (U16)EEPROM_ADRS,
                                 ee_mem,
                                 I2C_MEMADD_SIZE_16BIT,
                                 RX_i2c_buf,  // read data gets loaded here...
                                 block_size,
                                 1000 );
  if ( I2C_status != HAL_OK )
  {
    _NOP( );  // set breakpoint here - for test if this function fails
  }

}  // end i2c_ee_read()

/*******************************************************************************
** Function:     i2c_ee_write
** Description:  Send a block of memory to the external EEPROM.  This is a
**               blocking mode write.  The parameters for the write func:
**               *  hi2c1 - pointer to a I2C_HandleTypeDef structure.
**               *  EE_ADRS_WR- target device address, 7 bits (shift??)
**               *  MemAddress Internal memory address
**               *  MemAddSize Size of internal memory address
**               *  pData Pointer to data buffer
**               *  Size Amount of data to be sent
**               *  Timeout duration
**               Note that this function also copies the data into the EE SRAM
**               array (EE_non_vol_data[]) for each write operation.
** Inputs:       Data to write (8, 16 or 32 bit), eeprom address, data length.
** Outputs:      none.
*******************************************************************************/
void  i2c_ee_write( U32 ee_data, U16 ee_adrs, ee_data_len_t dl )
{
  U16 block_size;

  if ( dl == EE_DATA_8 )
  {
    /* 8-bit data is in the low order byte of the U32 int. */
    TX_i2c_buf[0]            = (U8)( ee_data & 0xFF);
    EE_non_vol_data[ee_adrs] = (U8)( ee_data & 0xFF);
    block_size = 1;
  }
  else if ( dl == EE_DATA_16 )
  {
    /* 16-bit data is in the lower 2 bytes of the U32 int. */
    TX_i2c_buf[0]                = (U8)( ee_data >> 8 ) & 0xFF;
    EE_non_vol_data[ee_adrs]     = (U8)( ee_data >> 8 ) & 0xFF;
    TX_i2c_buf[1]                = (U8)( ee_data & 0xFF);
    EE_non_vol_data[ee_adrs + 1] = (U8)( ee_data & 0xFF);
    block_size = 2;
  }
  else
  {
    /* 32-bit data in EE is in NBO - Network Byte Order, (big-endian).
    ** Note that floats are stored little-endian, in the "set_real_data" func. */
    TX_i2c_buf[0]                = (U8)( ee_data >> 24 ) & 0xFF;
    EE_non_vol_data[ee_adrs]     = (U8)( ee_data >> 24 ) & 0xFF;
    TX_i2c_buf[1]                = (U8)( ee_data >> 16 ) & 0xFF;
    EE_non_vol_data[ee_adrs + 1] = (U8)( ee_data >> 16 ) & 0xFF;
    TX_i2c_buf[2]                = (U8)( ee_data >> 8 ) & 0xFF;
    EE_non_vol_data[ee_adrs + 2] = (U8)( ee_data >> 8 ) & 0xFF;
    TX_i2c_buf[3]                = (U8)( ee_data & 0xFF);
    EE_non_vol_data[ee_adrs + 3] = (U8)( ee_data & 0xFF);
    block_size = 4;
  }

  I2C_status = HAL_I2C_Mem_Write ( &hi2c1,
                                  (U16)EEPROM_ADRS,
                                  ee_adrs,  // start address in eeprom for data
                                  I2C_MEMADD_SIZE_16BIT,
                                  TX_i2c_buf,  // write data block
                                  block_size,
                                  1000 );
  if ( I2C_status != HAL_OK )
  {
    _NOP( );  // set breakpoint here - for test if this function fails
  }
  /* NOTE: This delay was added because we were getting errors if we had two
  ** consecutive ee_writes!  Need to investigate I2C timing issues... */
  HAL_Delay( 3 );

}  // end i2c_ee_write()

/*******************************************************************************
** Function:     get_ee_read_data_str
** Description:  Gets a block of EEPROM data and formats it as a string.
**               The RX_i2C_buf[] will have the contents of the read operation,
**               and will contain up to 32 bytes.
** Inputs:       U8 - starting position in the RX_i2C_buf[].  Will be either
**               0, 8, 16 or 24.
** Outputs:      string formated ee read data (16 bytes).
*******************************************************************************/
char * get_ee_read_data_str( U8 start_pos )
{
  /* Temp string, static for return, with extra positions for formatting spaces. */
  char static str1[16 + 10];
  U8  temp_val;
  U8  x;      // RX buffer offset
  U8  y = 0;  // string position offset

  if ( start_pos > 32 - 1 )
  {
    start_pos = 0;  // limit check
  }
  for ( x = start_pos; x < start_pos + 8; ++x )
  {
    temp_val   = ( RX_i2c_buf[x] >> 4 ) & 0x0F;  // high nibble
    str1[y++]  = hex_ascii( temp_val );
    temp_val   = ( RX_i2c_buf[x] & 0x0F );       // low nibble
    str1[y++]  = hex_ascii( temp_val );
    str1[y++]  = ' ';  // add space for formating, ease of readability
  }  // end for

  str1[y] = NULL;  // terminate string
  return  str1;

}  // end get_ee_read_data_str()
#if 0
/*******************************************************************************
** Function:     get_ee_read_data_u16
** Description:  Gets a block of EEPROM data and formats it as a U16.
**
** Inputs:       .
** Outputs:      none.
*******************************************************************************/
U16  get_ee_read_data_u16( void )
{
  U16 rtn_val;
  U8  temp_val;

  temp_val = ( RX_i2c_buf[0] >> 8 ) & 0xFF;  // high byte
  rtn_val  = temp_val << 8;
  temp_val = ( RX_i2c_buf[1] & 0xFF );       // low byte
  rtn_val  = rtn_val | temp_val;

  return  rtn_val;

}  // end get_ee_read_data_u16()
#endif
/*******************************************************************************
** Function:     load_initial_ee_data
** Description:  If the version code in EE matches the version code in firmware,
**               then EE contents should be valid and up-to-date.  Copy EE to
**               SRAM.  If the versions do not match, load the current firmware
**               default values in EE, and copy into SRAM.
**               Typically, this function is called once from init_tasks().
** Inputs:       .
** Outputs:      none.
*******************************************************************************/
void  load_initial_ee_data( void )
{
  U32 reset_cnt;
  U16 block_start;
  U8  major_num;
  U8  minor_num;
  U8  block_num = 0;  // current number of the 32-byte block of memory

  while ( block_num < EE_MEM_BLOCKS )
  {
    block_start = block_num * 32;    // starting address for the EE memory block
    i2c_ee_read( block_start, 32 );  // read the block of 32 bytes
    HAL_Delay( 1 );

    /* Copy this block of EE data to SRAM. */
    for ( U16 x = block_start; x < block_start + 32; ++x )
    {
      EE_non_vol_data[x] = RX_i2c_buf[x - ( block_num * 32 )];
    }  // end for

    ++block_num;

  }  // end while

  /* Check the first two bytes for the major and minor version numbers.
  ** If the EE version and firmware version compare fails, load defaults. */
  major_num = EE_non_vol_data[0];  // 1st byte - Major firmware version number
  minor_num = EE_non_vol_data[1];  // 2nd byte - Minor firmware version number

  if (( major_num != MAJOR_VER_NUM ) || ( minor_num != MINOR_VER_NUM ))
  {
    /* Versions don't match - update EE version locations and load defaults. */
    i2c_ee_write( (U32)(( MAJOR_VER_NUM << 8 ) | ( MINOR_VER_NUM  )),
                  EE_VER, EE_DATA_16 );
    load_default_values( );
  }

  /* Increase the number of resets count, and save back to EE. */
  reset_cnt = get_ee_parameter( EE_NUM_RESETS, EE_DATA_32 );
  ++reset_cnt;
  i2c_ee_write( reset_cnt, EE_NUM_RESETS, EE_DATA_32 );

}  // end load_initial_ee_data()

/*******************************************************************************
** Function:     get_ee_parameter
** Description:  Returns the memory from the SRAM copy area for the associated
**               EE parameter.
**               NOTE: This is for integer data - float (real) data will use the
**               get/set real data functions.
** Inputs:       EE address (U16), data size (8, 16 or 32 bit data).
** Outputs:      U32 parameter data (8-bit data in LSB).
*******************************************************************************/
U32  get_ee_parameter( U16 ee_parm_adrs, ee_data_len_t dsize )
{
  U32 rtn_val = 0;

  /* Address bounds check. */
  if ( ee_parm_adrs > EE_ADDRESS_LIMIT )
  {
    ee_parm_adrs = 0;
  }

  if ( dsize == EE_DATA_32 )
  {
    rtn_val =  EE_non_vol_data[ee_parm_adrs] << 24;  // high byte
    rtn_val |= EE_non_vol_data[ee_parm_adrs + 1] << 16;
    rtn_val |= EE_non_vol_data[ee_parm_adrs + 2] << 8;
    rtn_val |= EE_non_vol_data[ee_parm_adrs + 3];    // low byte
  }
  else if ( dsize == EE_DATA_16 )
  {
    rtn_val =  EE_non_vol_data[ee_parm_adrs] << 8;  // high byte
    rtn_val |= EE_non_vol_data[ee_parm_adrs + 1];   // low byte
  }
  else
  {
    rtn_val =  EE_non_vol_data[ee_parm_adrs];       // 8-bit data in LSB
  }

  return  rtn_val;

}  // end get_ee_parameter()

/*******************************************************************************
** Function:     load_default_values
** Description:  Function is called from the serial protocol "restore defaults"
**               command, or from load_initial_ee_data when a new firmware
**               version is flashed.  Set proper ISC or Sonendo default values.
**               The main values to update/load/restore are:
**               1. SPH
**               2. SPL
**               3. start mode (auto or manual)
**               4. beta
**               5. t_units (temperature units, C or F)
**               6. PID-cool values, Pgain and Igain.
**               7. PID-heat values, Pgain and Igain.
** Inputs:       .
** Outputs:      none.
*******************************************************************************/
void  load_default_values( void )
{
  U8  ID;

  ID = board_cfg_get( );  // board ID determines which set of defaults to load

  if ( ID == ISC_CONTROL )
  {
    /* Load Pgain, cooling.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( PGAIN_COOL_ISC_DEFAULT, EE_PGAIN_COOL );
    pid_terms( PGAIN_COOL_ISC_DEFAULT, PGAIN_COOL, SET_DATA );

    /* Load Igain, cooling.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( IGAIN_COOL_ISC_DEFAULT, EE_IGAIN_COOL );
    pid_terms( IGAIN_COOL_ISC_DEFAULT, IGAIN_COOL, SET_DATA );

    /* Load Pgain, heating.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( PGAIN_HEAT_ISC_DEFAULT, EE_PGAIN_HEAT );
    pid_terms( PGAIN_HEAT_ISC_DEFAULT, PGAIN_HEAT, SET_DATA );

    /* Load Igain, heating.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( IGAIN_HEAT_ISC_DEFAULT, EE_IGAIN_HEAT );
    pid_terms( IGAIN_HEAT_ISC_DEFAULT, IGAIN_HEAT, SET_DATA );

    /* Load SPH (setpoint high value).  Default is in degrees C. */
    set_real_data( ISC_SPH, EE_SPH );
    set_sp_value( ISC_SPH, SPH_C );  // also sets the degrees F value

    /* Load SPL (setpoint low value).  Default is in degrees C. */
    set_real_data( ISC_SPL, EE_SPL );
    set_sp_value( ISC_SPL, SPL_C );  // also sets the degrees F value

    /* Load start mode, either AUTO or MANUAL.  (ISC is manual mode). */
    i2c_ee_write( MANUAL_MODE, EE_START_MODE, EE_DATA_8 );

    /* Load the thermistor beta value. */
    i2c_ee_write( BETA_DEFAULT, EE_BETA, EE_DATA_16 );

    /* Load temperature units, either C or F.  (ISC is degrees F). */
    i2c_ee_write( ISC_TEMP_UNITS, EE_TEMP_UNITS, EE_DATA_8 );
  }
  else if ( ID == SONENDO_CONTROL )
  {
    /* Load Pgain, cooling.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( PGAIN_COOL_SEN_DEFAULT, EE_PGAIN_COOL );
    pid_terms( PGAIN_COOL_SEN_DEFAULT, PGAIN_COOL, SET_DATA );

    /* Load Igain, cooling.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( IGAIN_COOL_SEN_DEFAULT, EE_IGAIN_COOL );
    pid_terms( IGAIN_COOL_SEN_DEFAULT, IGAIN_COOL, SET_DATA );

    /* Load Pgain, heating.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( PGAIN_HEAT_SEN_DEFAULT, EE_PGAIN_HEAT );
    pid_terms( PGAIN_HEAT_SEN_DEFAULT, PGAIN_HEAT, SET_DATA );

    /* Load Igain, heating.  Save to EE memory, SRAM copy area and pid struct. */
    set_real_data( IGAIN_HEAT_SEN_DEFAULT, EE_IGAIN_HEAT );
    pid_terms( IGAIN_HEAT_SEN_DEFAULT, IGAIN_HEAT, SET_DATA );

    /* Load SPH (setpoint high value).  Default is in degrees C. */
    set_real_data( SONENDO_SETPOINT, EE_SPH );
    set_sp_value( SONENDO_SETPOINT, SPH_C  );  // also sets the degrees F value

    /* Load SPL (setpoint low value).  Default is in degrees C. */
    set_real_data( SONENDO_PROP_BAND, EE_SPL );
    set_sp_value( SONENDO_PROP_BAND, SPL_C );  // also sets the degrees F value

    /* Load start mode, either AUTO or MANUAL. (Sonendo is Auto Mode). */
    i2c_ee_write( AUTO_MODE, EE_START_MODE, EE_DATA_8 );

    /* Load the thermistor beta value. */
    i2c_ee_write( BETA_SONENDO, EE_BETA, EE_DATA_16 );

    /* Load temperature units, either C or F.  (Sonendo is degrees C). */
    i2c_ee_write( SONENDO_TEMP_UNITS, EE_TEMP_UNITS, EE_DATA_8 );
  }
  else
  {
    // TBD - for future board configurations
  }

}  // end load_default_values()

/**
  * @brief  I2C error callbacks.
  * @param  I2cHandle: I2C handle
  * @note   This example shows a simple way to report transfer error, and you can
  *         add your own implementation.
  * @retval None
  */
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c1)
{
  /** Error_Handler() function is called when error occurs.
    * 1- When Slave don't acknowledge it's address, Master restarts communication.
    * 2- When Master don't acknowledge the last data transferred, Slave don't care in this example.
    */
  if (HAL_I2C_GetError(hi2c1) != HAL_I2C_ERROR_AF)
  {
    _NOP( );
  }
}

/* eeprom.c ************************************************************* EOF */
