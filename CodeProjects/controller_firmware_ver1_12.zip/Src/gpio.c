/*******************************************************************************
**
** Project:     Marlow Compact TE Controller (ISC-controller).
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    gpio.c
**
** Description: This module contains functions associated with the gpio pins;
**              however, some gpio functions are handled in other modules, as
**              noted below.  The list of which modules contain the various
**              gpio controls:
**              * LCD module, data output and backlight control - lcd.c
**              * Buttons, membrane pushbuttons - gpio.c
**              * LEDs, on the membrane (221-0145) - gpio.c
**              * LEDs, on-board (221-0144) LEDs - gpio.c
**              * H-bridge logic control - gpio.c
**              * configuration input bits and debug output bit - gpio.c
**              * buzzer/audio output - beep.c
**              * fan pwm enable - pwm.c ??
**              * eeprom address bits - eeprom.c
**              * initialize and setup all gpio pins - gpio.c
**
** Version/Author/Date/Description:
** 1   DMA   01/12/2018  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "gpio.h"
#include "project.h"
#include "config.h"
#include "main.h"
#include "eeprom.h"
#include "lcd.h"
#include "adc.h"
#include "beep.h"
#include "pwm.h"
#include <string.h>
#include "intrinsics.h"  // need for instrinsic __nop function

led_struct_t  leds[NUM_LEDS];  // declare struct(s) for all LED control variables
pb_struct_t   pb;              // declare struct for pushbutton control variables

/*******************************************************************************
** Function:     led_init
** Description:  Controls the various LEDS on the main control board, 221-0144,
**               and the external membrane switch panel, which contains 3 LEDs.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void led_init( void )
{
  /* Start by making sure all LEDs are off on the main controller. */
  LED_R1_OFF;  // on-board RED
  LED_W_OFF;   // on-board WHITE

  /* Include the membrane panel LEDs if the build is for that configuration. */
  if ( NUM_LEDS == 5 )
  {
    LED_G_OFF;   // membrane GREEN - PWR
    LED_B_OFF;   // membrane BLUE - COOL
    LED_R2_OFF;  // membrane RED - HEAT
  }

  /* Loop thru LED list and init each LEDs struct. */
  for ( U8 i = ONB_RED; i < NUM_LEDS; i++ )
  {
    leds[i].mode = LED_OFF;
    leds[i].counts = 0;
    leds[i].init_1st = FALSE;
    leds[i].on_counts = 0;
    leds[i].off_counts = 0;
    leds[i].cycle = 0;
    leds[i].repeat = 0;
  }  // end for

}  // end led_init()

/*******************************************************************************
** Function:     pb_init
** Description:  Set all structure elements for the pushbutton controls.
** Inputs:       U8 - flag for various clear actions.
** Outputs:      .
*******************************************************************************/
void pb_init( U8 action )
{
  if ( action == PB_SET_DONE )
  {
    /* Indicates the pushbutton action has completed, (SET has been pushed
    ** to save the entered value).  Clear the IN_PROCESS flag and key timeout.
    ** Leave the pb.state alone so that the debounce can complete normally. */
    pb.mode[PB_PWR]  = READY;
    pb.mode[PB_SET]  = READY;
    pb.mode[PB_DOWN] = READY;
    pb.mode[PB_UP]   = READY;
  }
  else
  {
    /* Loop thru list and init each pushbutton struct. */
    for ( U8 i = 0; i < NUM_PB; i++ )
    {
      pb.mode[i]  = READY;          // pushbutton starts off in ready mode
      pb.state[i] = NOT_PRESSED;    // assume this for all buttons at init time
      pb.hold[i]  = 0;  // hold time (continuous button press) for repeating key
    }  // end for
  }

  pb_clr_timeout( );  // clear the keypress timeout

}  // end pb_init()

/*******************************************************************************
** Function:     pb_clr_timeout
** Description:  Clears the pushbutton timeout value.  Usually done after the
**               keypress action has completed, and we do not need to wait for
**               a key timeout to tranistion to another mode.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void pb_clr_timeout( void )
{

  pb.key_timeout = 0;  // used as a key entry timeout

}  // end pb_clr_timeout()

/*******************************************************************************
** Function:     led_status
** Description:  Returns the status (ON or OFF) of the LED.  The LED is ON if
**               the current state is BLINKING, even if it's off at the time.
**               Consider this a "LED is in-use" type of query.
** Inputs:       led_id_t - LED ID of interest.
** Outputs:      led_t - LED mode, on or off.
*******************************************************************************/
led_t led_status( led_id_t id )
{
  if (( leds[id].mode == LED_OFF ) || ( leds[id].mode == LED_NOTHING ))
  {
    return  LED_OFF;
  }
  else
  {
    return  LED_ON;
  }

}  // end led_status()

/*******************************************************************************
** Function:     led_setup
** Description:  Set up the LED control.  Parameters set here are used in
**               update_led_ctrl_events() for timing and sequence control.
**               Example 1; on-board red LED on once for 2 seconds:
**                 led_setup(ONB_RED, LED_SINGLE, 2000, 0, 1);
**               Example 2; on for 1 sec, off for 1/2 sec, repeat sequence 3x:
**                 led_setup(MEM_BLUE, LED_BLINK, 1000, 500, 3);
**               Example 3; on-board white LED continuously on:
**                 led_setup(ONB_WHITE, LED_CONTINUOUS, 0, 0, 0);
**               Example 4; turn off all LEDs:
**                 led_setup(ALL_LEDS, LED_ALL_OFF, 0, 0, 0);
**
** Inputs:       (see description above)
**               Note that parameters that are not used are don't care, (use 0).
** Outputs:      -none-
*******************************************************************************/
void  led_setup( led_id_t id, led_t mode, U16 on_time, U16 off_time, U8 repeat )
{

  /* Handle the special case of turning off all LEDS. */
  if ( mode == LED_ALL_OFF )
  {
    led_init();
  }
  else
  {
    leds[id].mode       = mode;
    leds[id].init_1st   = FALSE;   // multiple pass flag - TRUE after 1st time thru
    leds[id].on_counts  = on_time;
    leds[id].off_counts = off_time;
    leds[id].state      = OFF;
    leds[id].repeat     = repeat;  // for blinking, 0xFF means "repeat forever"
  }

}  // end led_setup()

/*******************************************************************************
** Function:     update_led_ctrl_events
** Description:  This function is called from the periodic task timer, every
**               1mSec, and controls the led timing and sequencing.  The
**               previously called led_setup controls which case is executed.
**               For the blinking LED functions, each repeat count equals 1 on
**               cycle + 1 off cycle.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  update_led_ctrl_events( void )
{
  led_id_t  i;  // used to cycle thru LED list

  /* Loop thru LED list and determine action for each LED. */
  for ( i = ONB_RED; i < NUM_LEDS; i++ )
  {
    switch ( leds[i].mode )
    {
      case LED_OFF:
        led_on_off( i, OFF );        // turn off selected LED
        leds[i].state = OFF;
        leds[i].init_1st = FALSE;    // reset for next pass
        leds[i].mode = LED_NOTHING;  // nothing more to do until next led setup
        break;

      case LED_CONTINUOUS:
        led_on_off( i, ON );
        leds[i].state = ON;
        break;

      case LED_SINGLE:
      case LED_BLINK:
        if ( leds[i].init_1st == FALSE )  // 1st time thru...
        {
          led_on_off( i, ON );  // turn on the selected LED
          leds[i].state = ON;
          leds[i].counts = leds[i].on_counts;
          leds[i].init_1st = TRUE;
        }
        else
        {
          if ( leds[i].counts > 0 )
          {
            leds[i].counts--;
          }
          else
          {
            if ( leds[i].state == ON )
            {
              if ( leds[i].mode == LED_SINGLE )
              {
                leds[i].mode = LED_OFF;  // done with single LED flash
              }
              else
              {
                leds[i].counts = leds[i].off_counts;  // pre-load for next off cycle
                leds[i].state = OFF;
                led_on_off( i, OFF );
              }
            }
            else
            {
              leds[i].cycle++;  // on-off cycle count
              if (( leds[i].cycle < leds[i].repeat ) || ( leds[i].repeat == 0xFF ))
              {
                leds[i].counts = leds[i].on_counts;  // pre-load for next on cycle
                leds[i].state = ON;
                led_on_off( i, ON );
              }
              else
              {
                leds[i].mode = LED_OFF;  // done with multiple flashes
              }
            }
          }
        }
        break;

      default:  // default case handles the "nothing" led mode...
      break;

    }  // end switch
  }  // end for

}  // end update_led_ctrl_events()

/*******************************************************************************
** Function:     led_on_off
** Description:  Low level hardware control for the various LEDS - on or off.
**               Note that the Senendo application uses FANS 3 & 4 for the
**               external RED and BLUE LEDs.
** Inputs:       led_id_t id, ON or OFF.
** Outputs:      .
*******************************************************************************/
void led_on_off( led_id_t id, BOOL state )
{

  switch ( id )
  {
    case ONB_RED:  // on-board red
      if ( state == ON )
      {
        LED_R1_ON;
      }
      else
      {
        LED_R1_OFF;
      }
      break;

    case ONB_WHITE:  // on-board white
      if ( state == ON )
      {
        LED_W_ON;
      }
      else
      {
        LED_W_OFF;
      }
      break;

    case MEMB_GREEN:  // membrane panel green
      if ( state == ON )
      {
        LED_G_ON;
      }
      else
      {
        LED_G_OFF;
      }
      break;

    case MEMB_BLUE:  // membrane panel blue (Senendo: fan connect used for LED)
      if ( state == ON )
      {
        if ( board_cfg_get( ) == SENENDO_CONTROL )
        {
          fan_ctrl( FAN4_CH, FAN_SPEED_HIGH );
        }
        else
        {
          LED_B_ON;
        }
      }
      else
      {
        if ( board_cfg_get( ) == SENENDO_CONTROL )
        {
          fan_ctrl( FAN4_CH, FAN_SPEED_OFF );
        }
        else
        {
          LED_B_OFF;
        }
      }
      break;

    case MEMB_RED:  // membrane panel red (Senendo: fan connect used for LED)
      if ( state == ON )
      {
        if ( board_cfg_get( ) == SENENDO_CONTROL )
        {
          fan_ctrl( FAN3_CH, FAN_SPEED_HIGH );
        }
        else
        {
          LED_R2_ON;
        }
      }
      else
      {
        if ( board_cfg_get( ) == SENENDO_CONTROL )
        {
          fan_ctrl( FAN3_CH, FAN_SPEED_OFF );
        }
        else
        {
          LED_R2_OFF;
        }
      }
      break;

    default:
      break;

  }  // end switch

}  // end led_on_off()

/*******************************************************************************
** Function:     update_pb_events
** Description:  This function is called from the periodic task timer, every
**               XXmSec, and sets up the actions to take when a pushbutton is
**               pressed.  Each switch is checked for:
**               1. complete debounce,
**               2. not currently pressed, and
**               3. the switch is active (READY, not disabled or previous
**                  action still in-process).
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  update_pb_events( void )
{

  /* ON/OFF (PWR) keypress. */
  if ( debounce_switch( PB_PWR ) && ( pb.state[PB_PWR] == NOT_PRESSED ))
  {
    /* If keypress action is allowed (lockout time is up), save key info and
    ** perform the PWR key actions. */
    if ( task_timer_done_check( PROCESS_TIME_PWR_KEY ) )
    {
      key_common_actions( PB_PWR );
    }
  }
  else
  {
    if ( !debounce_switch( PB_PWR ) && ( pb.state[PB_PWR] == PRESSED ))
    {
      pb.state[PB_PWR] = NOT_PRESSED;
      /* Key has been released.  Set the action time for the ON/OFF or PWR key.
      ** This acts as a lockout until the next key action is allowed. */
      task_timer_start( PROCESS_TIME_PWR_KEY, 750, ONE_SHOT );
    }
  }

  /* SET keypress. */
  if ( debounce_switch( PB_SET ) && ( pb.state[PB_SET] == NOT_PRESSED ))
  {
    /* If keypress action is allowed (lockout time is up), save key info and
    ** perform the SET key actions. */
    if ( task_timer_done_check( PROCESS_TIME_SET_KEY ) )
    {
      key_common_actions( PB_SET );
    }
  }
  else
  {
    if ( !debounce_switch( PB_SET ) && ( pb.state[PB_SET] == PRESSED ))
    {
      pb.state[PB_SET] = NOT_PRESSED;
      /* Key has been released.  Set the action time for the SET key.
      ** This acts as a lockout until the next key action is allowed. */
      task_timer_start( PROCESS_TIME_SET_KEY, 750, ONE_SHOT );
    }
  }

  /* DOWN keypress. */
  if ( debounce_switch( PB_DOWN ) && ( pb.state[PB_DOWN] == NOT_PRESSED ))
  {
    /* If keypress action is allowed (lockout time is up), save key info and
    ** perform the DOWN key actions. */
    if ( task_timer_done_check( PROCESS_TIME_DOWN_KEY ) )
    {
      key_common_actions( PB_DOWN );
    }
  }
  else
  {
    if ( !debounce_switch( PB_DOWN ) && ( pb.state[PB_DOWN] == PRESSED ))
    {
      pb.state[PB_DOWN] = NOT_PRESSED;
      /* Key has been released.  Set the action time for the DOWN key.
      ** This acts as a lockout until the next key action is allowed. */
      task_timer_start( PROCESS_TIME_DOWN_KEY, 500, ONE_SHOT );
    }
  }

  /* UP keypress. */
  if ( debounce_switch( PB_UP ) && ( pb.state[PB_UP] == NOT_PRESSED ))
  {
    /* If keypress action is allowed (lockout time is up), save key info and
    ** perform the DOWN key actions. */
    if ( task_timer_done_check( PROCESS_TIME_UP_KEY ) )
    {
      key_common_actions( PB_UP );
    }
  }
  else
  {
    if ( !debounce_switch( PB_UP ) && ( pb.state[PB_UP] == PRESSED ))
    {
      pb.state[PB_UP] = NOT_PRESSED;
      /* Key has been released.  Set the action time for the DOWN key.
      ** This acts as a lockout until the next key action is allowed. */
      task_timer_start( PROCESS_TIME_UP_KEY, 500, ONE_SHOT );
    }
  }

  key_timeout_check( );

}  // end update_pb_events()

/*******************************************************************************
** Function:     key_common_actions
** Description:  This function is called after any key is pressed.  The beeper
**               is started, key modes are updated, control/state variables are
**               updated, and the key timeout count is reset.  The specific
**               menu/display action associated with the key is performed.
** Inputs:       U8 - pushbutton key value, 0-3
** Outputs:      none
*******************************************************************************/
void  key_common_actions( U8 key )
{

  if ( key < NUM_PB )  // range check
  {
    pb.state[key]  = PRESSED;
    pb.mode[key]   = IN_PROCESS;
    pb.key_timeout = KEY_TIMEOUT;     // reset the timeout count
    pb.ID          = key;             // save value for keypress ID
    beeper_trigger( );
    menu_process( key );              // menu/display action
  }
}  // end key_common_actions()

/*******************************************************************************
** Function:     get_pushbutton_id
** Description:  Returns the current pushbutton keypress ID.
** Inputs:       -none-
** Outputs:      U8 - key pushbutton ID value
*******************************************************************************/
U8  get_pushbutton_id( void )
{

  return  pb.ID;

}  // end get_pushbutton_id()

/*******************************************************************************
** Function:     get_pushbutton_mode
** Description:  Returns the current pushbutton keypress mode.
** Inputs:       U8 - specific key or all keys
** Outputs:      pb_mode_t (READY, NOT_READY, or IN_PROCESS)
*******************************************************************************/
pb_mode_t  get_pushbutton_mode( U8 key )
{
  pb_mode_t  rtn_val = READY;

  if ( key == PB_ALL )
  {
    /* Loop thru list and check for any pushbuttons that are IN_PROCESS or
    ** NOT_READY. */
    for ( U8 i = 0; i < NUM_PB; i++ )
    {
      if ( pb.mode[i] == IN_PROCESS )
      {
        rtn_val = IN_PROCESS;
      }
      else if ( pb.mode[i] == NOT_READY )
      {
        rtn_val = NOT_READY;
      }
      else
      {
        ;  // nothing here (yet)!
      }
    }  // end for

    return  rtn_val;       // the case for checking all of the pushbuttons
  }
  else
  {
    return  pb.mode[key];  // the case for an individual, specific pushbutton
  }

}  // end get_pushbutton_mode()

/*******************************************************************************
** Function:     key_timeout_check
** Description:  This function checks the key timeout value.  If a timeout is
**               detected, the action taken is defined in the control modes
**               structure.
** Inputs:       .
** Outputs:      none
*******************************************************************************/
void  key_timeout_check( void )
{

  if ( pb.key_timeout > 0 )
  {
    if ( --pb.key_timeout == 0 )
    {
      // goto the mode defined in control_modes struct:   ctrl_modes.tout_level = LEVEL_0;   // level to go to when a timeout occurs
      set_idle_mode( );   // turns scrolling back on (if enabled)
      pb_init( PB_ALL );  // reset pushbutton state/values
      main_temp_display( 0 );
    }
  }

}  // end key_timeout_check()

/*******************************************************************************
** Function:     debounce_switch
** Description:  Debounce pushbutton switches, using a periodic timer to call
**               this function.  Collect from 1 to 8 input switch samples and
**               determine if switch is open or closed (up to 4 switches).
**               0 - PWR_SW, power button
**               1 - SET_SW, set button
**               2 - DOWN_SW, down button
**               3 - UP_SW, up button
**               Debounce on both push and release portions of the actuation.
**               A boolean data type could be used here, but since that takes
**               a byte of memory, might as well use U8 data types.
** Inputs:       U8 - input switch/button ID (0-3).
** Outputs:      U8 - output state of switch (ON or OFF), or ERROR.
*******************************************************************************/
U8 debounce_switch( U8 sw_id )
{
  static U8 sample_total[4]   = {0, 0, 0, 0};  // total accumulated bit samples
  static U8 sample_bitmask[4] = {1, 1, 1, 1};  // initial bit mask values
  static U8 switch_value[4]   = {0, 0, 0, 0};  // initial value - 0 is OFF
         U8 new_sw_value;                      // new input button read value

  if ( sw_id == PB_PWR )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_PWR_SW_GPIO_Port, MEMB_PWR_SW_Pin );
  }
  else if ( sw_id == PB_SET )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_SET_SW_GPIO_Port, MEMB_SET_SW_Pin );
  }
  else if ( sw_id == PB_DOWN )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_D_ARR_SW_GPIO_Port, MEMB_D_ARR_SW_Pin );
  }
  else if ( sw_id == PB_UP )
  {
    new_sw_value = HAL_GPIO_ReadPin( MEMB_U_ARR_SW_GPIO_Port, MEMB_U_ARR_SW_Pin );
  }
  else
  {
    return  SW_ID_ERROR;  // error - max of 4 switches (0-3) allowed
  }

  if ( new_sw_value )
  {
    sample_total[sw_id] |= sample_bitmask[sw_id];   // put 1 in the bit position
  }
  else
  {
    sample_total[sw_id] &= ~sample_bitmask[sw_id];  // put a 0 the position
  }

  if ( sample_bitmask[sw_id] == MAX_MASK_VALUE )
  {
    sample_bitmask[sw_id] = 0x01;  // reset bitmask to first, initial position
  }
  else
  {
    sample_bitmask[sw_id] <<= 1;  // shift bitmask to next position
  }

  /* If all saved samples are 0, then switch is off.
  ** If all saved samples are 1, then switch is on. */
  if ( sample_total[sw_id] == 0x00 )
  {
    switch_value[sw_id] = OFF;
  }
  else if ( sample_total[sw_id] == FULL_ON_VALUE )  // all bits = 1
  {
    switch_value[sw_id] = ON;
  }
  else
  {
    _NOP( );  // switch is bouncing - don't change previous switch result
  }

  return  switch_value[sw_id];

}  // end debounce_switch()

/*******************************************************************************
** Function:     read_board_config_pins
** Description:  Read the parameter config bits on the PCBA.
**               Remember that the 6th pin (formerly CONF_FW_BIT5_Pin) is now
**               a debug output pin (DEBUG_OUT_Pin). This is the pin closest to
**               the J8 reference designator (and the flex connect) on the board
**               silkscreen. The value determines board functionality (run-time
**               configuration).  See config.h for more info.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
U8 read_board_config_pins( void )
{
  U8 config_setting = 0;  // board run-time config setting

  /* The input config pins are pulled-up, so test pins for 0 (GPIO_PIN_RESET)
  ** to indicate a jumper present. */
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT0_GPIO_Port, CONF_FW_BIT0_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 1;  // 00001
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT1_GPIO_Port, CONF_FW_BIT1_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 2;  // 00010
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT2_GPIO_Port, CONF_FW_BIT2_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 4;  // 00100
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT3_GPIO_Port, CONF_FW_BIT3_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 8;  // 01000
  }
  if ( HAL_GPIO_ReadPin( CONF_FW_BIT4_GPIO_Port, CONF_FW_BIT4_Pin ) == GPIO_PIN_RESET )
  {
    config_setting |= 16;  // 10000
  }

  return  config_setting;

}  // end read_board_config_pins()

/* gpio.c *************************************************************** EOF */
