/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    uart.c
**
** Description: This module contains the controls and functions associated with
**              the internal Universal Synchronous/Asynchronous Receiver
**              Transmitters (USART) module.  No external hardware exists for
**              voltage level conversions, i.e., RS-232, RS-485, etc. This
**              serial comm interface is designed for use with a FTDI cable
**              (TTL-232R-3V3),
**              New as of rev. 3 hardware: RS-232 chip included (MAX3221) on-
**              board.  No protocol changes, just enable this part.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/02/2019  Added RS-232 chip enable to init code.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "serial_comm.h"
#include "main.h"
#include "intrinsics.h"  // need for instrinsic __nop function
#include <string.h>

/* Declare the handle for the USART/UART configuration. */
UART_HandleTypeDef huart1;

char  RX_buffer[2];  // holds the received UART chars (from interrupt)

char debug_out_buf[MAX_DEBUG_OUT_BUFFER_SIZE];  // debug output via UART
char debug_in_buf[MAX_DEBUG_IN_BUFFER_SIZE];    // debug input via UART
static U16  out_head;
static U16  out_tail;
static U16  debug_buf_out_ptr;  // tracks loading the output debug buffer
static U16  debug_buf_in_ptr;   // tracks loading the input debug buffer
static U8   msg_complete;       // indicates a complete input message received


/*******************************************************************************
** Function:     uart_init
** Description:  Initialize various variables/functions associated with the
**               UART.  The UART/USART is used for debug I/O with a terminal
**               emulator program on a PC, e.g., TeraTerm or PuTTY.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void uart_init( void )
{
  out_head = 0;
  out_tail = 0;
  debug_buf_out_ptr = 0;

  for ( U16 x = 0; x < MAX_DEBUG_OUT_BUFFER_SIZE; x++ )
  {
    debug_out_buf[x] = '\0';  // null fill buffer
  }  // end for

  input_buffer_reset();  // also resets "msg_complete" flag

  /* The following is from the STM32Cube code generator.  For USART1.
  ** The low-level internal USART driver is setup and initialized. */
  huart1.Instance                    = USART1;
  huart1.Init.BaudRate               = 115200;
  huart1.Init.WordLength             = UART_WORDLENGTH_8B;
  huart1.Init.StopBits               = UART_STOPBITS_1;
  huart1.Init.Parity                 = UART_PARITY_NONE;
  huart1.Init.Mode                   = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl              = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling           = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling         = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  HAL_UART_Init(&huart1);

  /* INIT THE RECEIVE INTERRUPT PROCESS...
  ** Set buffer length to 1 to get each character as they arrive in the
  ** callback function.  (Maybe increase buffer len??). */
  if ( HAL_UART_Receive_IT(&huart1, (uint8_t *)RX_buffer, 1 ) != HAL_OK )
  {
    Error_Handler();
  }

  /* Enable the MAX3221 RS-232 chip.  Leave on all the time (for now). */
  RS232_ON;

}  // end uart_init()

/*******************************************************************************
** Function:     input_buffer_reset
** Description:  Null fill the input (receive) buffer.  This is done after each
**               complete message reception (ending with a '\r' and/or '\n').
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void input_buffer_reset( void )
{
  debug_buf_in_ptr = 0;
  msg_complete = NO;  // indicates a complete input message received

  for ( U8 x = 0; x < MAX_DEBUG_IN_BUFFER_SIZE; x++ )
  {
    debug_in_buf[x] = '\0';  // null fill buffer
  }  // end for

}  // end input_buffer_reset()

/*******************************************************************************
** Function:     send_debug
** Description:  Load the output debug buffer and start the transmit process.
** Inputs:       char data string, output print options
** Outputs:      none
*******************************************************************************/
void send_debug( char * d_str, dbug_print_options_t opt )
{
  /* Add the xmit string to the debug print buffer. */
  for ( U8 cnt = 0; cnt < strlen(d_str); cnt++ )
  {
    debug_out_buf[debug_buf_out_ptr] = d_str[cnt];
    debug_buf_out_ptr = inc_circular_buf_ptr( debug_buf_out_ptr, OUT_BUF );
  }  // end for

  /* Add the option character(s) to the end of the print buffer. */
  if ( opt == ADD_CRLF )
  {
    debug_out_buf[debug_buf_out_ptr] = 0x0A;  // lf
    debug_buf_out_ptr = inc_circular_buf_ptr( debug_buf_out_ptr, OUT_BUF );
    debug_out_buf[debug_buf_out_ptr] = 0x0D;  // cr
    debug_buf_out_ptr = inc_circular_buf_ptr( debug_buf_out_ptr, OUT_BUF );
  }
  else if ( opt == ADD_COMMA )
  {
    debug_out_buf[debug_buf_out_ptr] = ',';  // comma character
    debug_buf_out_ptr = inc_circular_buf_ptr( debug_buf_out_ptr, OUT_BUF );
    debug_out_buf[debug_buf_out_ptr] = ' ';  // space after comma
    debug_buf_out_ptr = inc_circular_buf_ptr( debug_buf_out_ptr, OUT_BUF );
  }
  else
  {
    ;  // nothing to add...
  }

  // If the tail = head, then previous messages are done, and this is a new
  // message that needs to be sent.  If the counts are not equal, then the
  // transmit is in progress and the callback function will continue to send
  // the remaining characters.
  if ( out_tail == out_head )
  {
    transmit_character( debug_out_buf[out_head] );  // start xmit
  }

}  // end send_debug()

/*******************************************************************************
** Function:     HAL_UART_TxCpltCallback
** Description:  Transmit transfer is complete callback function.
**               Note - this function replaces the __weak function declaration
**               in the STM32 included HAL function library.
**               We get here after the transmit is complete (interrupt).
** Inputs:       uart handle
** Outputs:      none
*******************************************************************************/
void HAL_UART_TxCpltCallback( UART_HandleTypeDef *huart )
{
  // This is the only place to increment the tail count.
  out_tail = inc_circular_buf_ptr( out_tail, OUT_BUF );

  // If the tail != debug buffer pointer, then there are still characters
  // waiting to print.
  if ( out_tail != debug_buf_out_ptr )
  {
    transmit_character( debug_out_buf[out_head] );
  }

}  // end HAL_UART_TxCpltCallback()

/*******************************************************************************
** Function:     transmit_character
** Description:  Send the character out via UART transmit.  Interrupts enabled.
**               The *CallBack function is called after the transmit is
**               complete.
** Inputs:       char
** Outputs:      none
*******************************************************************************/
void transmit_character( U8 x_char )
{
  U8 xmit_str[2];

  // Load character in the string, even though we only need the one characater.
  xmit_str[0] = x_char;
  xmit_str[1] = '\0';  // terminate string

  HAL_UART_Transmit_IT( &huart1, (U8 *)xmit_str, 1 );

  // This is the only place to increment the head count.
  out_head = inc_circular_buf_ptr( out_head, OUT_BUF );

}  // end transmit_character()

/*******************************************************************************
** Function:     inc_circular_buf_ptr
** Description:  Increment the buffer pointer and wrap around if necessary.
** Inputs:       U16 buffer pointer value, input or output buffer flag
** Outputs:      U16 new buffer pointer value
*******************************************************************************/
U16  inc_circular_buf_ptr( U16 buffer_ptr, circ_buf_t which_buf )
{
  U16 val;
  U16 buf_size;

  val = buffer_ptr + 1;

  if ( which_buf == IN_BUF )
  {
    buf_size = MAX_DEBUG_IN_BUFFER_SIZE;
  }
  else
  {
    buf_size = MAX_DEBUG_OUT_BUFFER_SIZE;
  }

  // Wrap if needed.
  if ( val >= buf_size )
  {
    val = 0;
  }
  return val;

}  // end inc_circular_buf_ptr()

/*******************************************************************************
** Function:     HAL_UART_RxCpltCallback
** Description:  Receive character is complete - callback function.
**               Note - this function replaces the __weak function declaration
**               in the STM32 included HAL function library.
**               We get here after receiving a character (interrupt).  Set the
**               message complete flag if the line terminator received.
** Inputs:       uart handle
** Outputs:      none
*******************************************************************************/
void HAL_UART_RxCpltCallback( UART_HandleTypeDef *huart )
{
  // Character received is in buf position [0].
  debug_in_buf[debug_buf_in_ptr] = RX_buffer[0];

  if (( debug_in_buf[debug_buf_in_ptr] == '\r' )  ||
      ( debug_in_buf[debug_buf_in_ptr] == '\n' ))
  {
    msg_complete = YES;  // complete input message received
  }

  /* Reset the receiver interrupt (for a single character). */
  if ( HAL_UART_Receive_IT(&huart1, (uint8_t *)RX_buffer, 1 ) != HAL_OK )
  {
    _NOP( );  // (placeholder for error handler)
  }

  /* Should never wrap the input buffer pointer - as soon as we get a '\r' we
  ** will process the input and reset the pointer.  But if some fool keeps
  ** rapidly pounding on the keyboard, we are covered! */
  debug_buf_in_ptr = inc_circular_buf_ptr( debug_buf_in_ptr, IN_BUF );

}  // end HAL_UART_RxCpltCallback()

/*******************************************************************************
** Function:     check_message_received
** Description:  Return the flag to indicate if the input serial command
**               message has been received.
** Inputs:       none
** Outputs:      YES = message received,
**               NO = message not received or not complete
*******************************************************************************/
U8 check_message_received( void )
{
  return  msg_complete;
}  // end check_message_received()

/* uart.c *************************************************************** EOF */
