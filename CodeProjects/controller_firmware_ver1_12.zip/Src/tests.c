/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    tests.c
**
** Description: This module contains the factory tests and end-of-line (EOL)
**              tests to validate unit functionality.  Specifically for the
**              ISC unit, with membrane panel and LCD.
**
** Version/Author/Date/Description:
** 1   DMA   08/23/2018  Began coding.
** 2   DMA   01/30/2019  Added test for thermistor sensor at start of tests.
**                       Also, modified the test parameters for when heating
**                       starts and ends.  (See doc for full description).
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "lcd.h"
#include "config.h"
#include "eeprom.h"
#include "beep.h"
#include "keys.h"
#include "pwm.h"
#include "adc.h"
#include "intrinsics.h"  // need for instrinsic __nop function
#include <string.h>
#include <stdio.h>       // need for sprintf()

/* Test-related LCD screen displays.  */
const char  test_mode1[]       = "TEST MODE...";
const char  test_cool_1[]      = "cooling...";
const char  test_heat_1[]      = "heating...";
const char  test_cool_2[]      = "cool end  ";
const char  test_heat_2[]      = "heat end  ";
const char  test_fans[]        = "fans...";
const char  test_leds[]        = "LEDs...";
const char  test_pass[]        = "PASS";
const char  test_fail_fan1[]   = "FAIL: fan1 ";
const char  test_fail_fan2[]   = "FAIL: fan2 ";
const char  test_fail_cool[]   = "FAIL: cool ";
const char  test_fail_heat[]   = "FAIL: heat ";
const char  test_fail_sensor[] = "FAIL: t1: ";

/*******************************************************************************
** Function:     test_mode_event_control
** Description:  Control the various factory tests needed to verify the unit
**               functionality.  This function is called on a periodic basis if
**               we are in the test mode.
**               Key combination (ON/OFF & SET) initiates the test mode.
**               NOTE: This is the ISC test mode, and the test expects to see
**               the membrane panel, two fans, and at least a 2 degree change
**               during the heat and cool phase.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  test_mode_event_control( void )
{
  static  U16  sequence = 0;     // sequence count for test phase
  static  U8   test_result = 0;  // 0=success, non-zero=fail
  static  U8   repeats = 0;      // number of checks for a temperature diff
  static  char lcd_line[16];
  static  F32  t_val_start;
  static  F32  t_val_end;
  static  F32  test_start_temp;
  static  U8   passfail = PASS;  // for final result of test
  lcd_t   display_status;         // don't need static here
  U16     fan_tach;               // temp value, don't need static
  char    str2[8];

  /* Start by making sure all previously set states, pushbutton values, modes,
  ** LCD backlight and flags have been reset to init conditons. */
  if ( sequence == 0 )
  {
    //  scrolling_set( NO );      // disable scrolling screen
    lcd_backlight_control( ON );

    setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module

    /* Display top line message:  TEST MODE... */
    strcpy( lcd_line, test_mode1 );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE1 );
    }
    while ( display_status == LCD_NOT_DONE );

    /* Display bottom line message:  LEDS... */
    strcpy( lcd_line, test_leds );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE2 );
    }
    while ( display_status == LCD_NOT_DONE );

  }
  /* Start the LED on/off sequence... */
  if ( sequence == 1000 )
  {
    led_on_off( MEMB_GREEN, ON );
  }
  if ( sequence == 1500 )
  {
    led_on_off( MEMB_BLUE, ON );
  }
  if ( sequence == 2000 )
  {
    led_on_off( MEMB_RED, ON );
  }
  if ( sequence == 2500 )
  {
    led_on_off( ONB_RED, ON );
  }
  if ( sequence == 3000 )
  {
    led_on_off( ONB_WHITE, ON );
  }
  if ( sequence == 4500 )
  {
    led_on_off( MEMB_GREEN, OFF );
  }
  if ( sequence == 4750 )
  {
    led_on_off( MEMB_BLUE, OFF );
  }
  if ( sequence == 5000 )
  {
    led_on_off( MEMB_RED, OFF );
  }
  if ( sequence == 5250 )
  {
    led_on_off( ONB_RED, OFF );
  }
  if ( sequence == 5500 )
  {
    led_on_off( ONB_WHITE, OFF );
  }
  /* Check for thermistor (sensor) error.  Should already be in error mode if
  ** the sensor is unplugged or damaged. */
  if ( sequence == 6123 )
  {
    t_val_start = get_current_temperature( 0, DEGREES_C );
    if (( ctrl_mode_state( NONE, GET_DATA ) == ERROR_MODE ) ||
        ( t_val_start < -40.0f )) //LOWER_TEMP_LIMIT??
    {
      strcpy( lcd_line, test_fail_sensor );
      sprintf( str2, "%3.1f", t_val_start );
      strcat( lcd_line, str2 );
      do
      {
        display_status = send_lcd_message( lcd_line, LCD_LINE2 );
      }
      while ( display_status == LCD_NOT_DONE );
      passfail = FAIL;
      sequence = 60000;  // might as well end the test sequence
    }
  }

  if ( sequence == /* TEST_PHASE_2 */ 7000 )
  {
    /* Display bottom line message:  fans... */
    strcpy( lcd_line, test_fans );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE2 );
    }
    while ( display_status == LCD_NOT_DONE );
  }

  if ( sequence == 7500 )
  {
    fan_ctrl( FAN1_CH, FAN_SPEED_HIGH );
  }
  if ( sequence == 8500 )
  {
    fan_ctrl( FAN2_CH, FAN_SPEED_HIGH );
  }

  /* After about 9~10 seconds, if the fan speed is too low, it's a FAIL. */
  if ( sequence == 17000 )
  {
    fan_tach = get_fan_tach( 1 );
    if ( fan_tach < 1600 )
    {
      test_result = 1;  // fan 1 fail - display tach value
      strcpy( lcd_line, test_fail_fan1 );
      strcat( lcd_line, s16_to_string( fan_tach, NO_SPACE_OR_0 ));
    }
  }
  if ( sequence == 18750 )
  {
    fan_tach = get_fan_tach( 2 );
    if ( fan_tach < 1600 )
    {
      test_result = 2;  // fan 2 fail - display tach value
      strcpy( lcd_line, test_fail_fan2 );
      strcat( lcd_line, s16_to_string( fan_tach, NO_SPACE_OR_0 ));
    }
  }
  if ( sequence == 19000 )
  {
    if ( test_result > 0 )
    {
      do
      {
        display_status = send_lcd_message( lcd_line, LCD_LINE2 );
      }
      while ( display_status == LCD_NOT_DONE );
      passfail = FAIL;
      sequence = 60000;  // might as well end the test sequence
    }
  }

  if ( sequence == /* TEST_PHASE_3 (starting the cool phase */ 19550 )
  {
    /* Display bottom line message, "cooling...", and add temperature value.
    ** Also, the temperature now is the test starting temp - use this for the
    ** ending temperature requirement after heating. */
    strcpy( lcd_line, test_cool_1 );
    t_val_start = get_current_temperature( 0, DEGREES_C );
    test_start_temp = t_val_start;
    display_msg_and_temp( lcd_line, t_val_start );

    /* Fans are already on high - start the tec. */
    set_tec_duty_cycle( 100 );
    tec_ctrl( COOL );
  }

  if ( sequence == 30000 )
  {
    /* Check to see if we have achieved at least 2 degrees of cooling yet. */
    t_val_end = get_current_temperature( 0, DEGREES_C );
    if (( t_val_start - t_val_end ) <= 2.0f )
    {
      /* Not there yet; check if we've repeated this phase too many times, which
      ** would mean FAIL.  12 * 10Sec = 120Sec max allowed time.
      ** Else display current temp, reset sequence and keep cycling... */
      if ( ++repeats > 12 )
      {
        strcpy( lcd_line, test_fail_cool );
        display_msg_and_temp( lcd_line, 9999.9f );  // no temperature display
        passfail = FAIL;
        sequence = 60000;  //  proceed to the end of the test sequence...
      }
      else
      {
        sequence = 20000;  // put count back to give 10 secs till next check...
        display_msg_and_temp( lcd_line, t_val_end );
      }
    }
    else
    {
      /* We're at the end of the cool phase.  The cooling passes if we're here.
      ** Display bottom line message:  cool end */
      strcpy( lcd_line, test_cool_2 );
      t_val_end = get_current_temperature( 0, DEGREES_C );
      display_msg_and_temp( lcd_line, t_val_end );
      repeats = 0;
      tec_ctrl( NO_HEAT_NO_COOL );
    }
  }

  /* Just need about a 1/2 second before starting the heat test... */
  if ( sequence == /* TEST_PHASE_5 (start the heat phase) */ 30500 )
  {
    /* Display bottom line message, "heating...", and add temperature value. */
    strcpy( lcd_line, test_heat_1 );
    t_val_start = get_current_temperature( 0, DEGREES_C );
    display_msg_and_temp( lcd_line, t_val_start );

    /* Fans are already on high - start the tec. */
    set_tec_duty_cycle( 100 );
    tec_ctrl( HEAT );
  }

  if ( sequence == 41000 )
  {
    /* To sucessfully complete the heating test, we must exceed the original
    ** test start temperature by 1 degree.  */
    t_val_end = get_current_temperature( 0, DEGREES_C );
    if ( t_val_end < ( test_start_temp + 1.0f ))
    {
      /* Not there yet; check if we've repeated this phase too many times, which
      ** would mean FAIL.  10 * 10Sec = 100Sec max allowed time.
      ** Else display current temp, reset sequence and keep cycling... */
      if ( ++repeats > 10 )
      {
        strcpy( lcd_line, test_fail_heat );
        display_msg_and_temp( lcd_line, 9999.9f );  // no temperature display
        passfail = FAIL;
        sequence = 60000;  //  proceed to the end of the test sequence...
      }
      else
      {
        sequence = 31000;  // put count back to give 10 secs till next check...
        display_msg_and_temp( lcd_line, t_val_end );
      }
    }
    else
    {
      /* We're at the end of the heat phase.  Heating passes if we're here.
      ** Display bottom line message:  heat end */
      strcpy( lcd_line, test_heat_2 );
      t_val_end = get_current_temperature( 0, DEGREES_C );
      display_msg_and_temp( lcd_line, t_val_end );
      repeats = 0;
      tec_ctrl( NO_HEAT_NO_COOL );
    }
  }

  if ( sequence == /* TEST_PHASE_5 */ 44000 )
  {
    setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module

    /* If we made it to this point, we passed. Display the PASS text. */
    strcpy( lcd_line, test_pass );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE2 );
    }
    while ( display_status == LCD_NOT_DONE );
  }

  /* Leave the fans on for a short while during the time between test PASS and
  ** test end to cool down the TEC module after heating. */
  if ( sequence++ > 50000 )
  {
    tec_ctrl( NO_HEAT_NO_COOL );
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
    sequence = 65500;

    if ( passfail )
    {
      ctrl_mode_state( TEST_MODE_FAIL, SET_DATA );
    }
    else
    {
      ctrl_mode_state( TEST_MODE_PASS, SET_DATA );
    }
  }

}  // end test_mode_event_control()

/*******************************************************************************
** Function:     display_msg_and_temp
** Description:  Display the bottom line message and add the current
**               temperature (degrees C) to the display.  If temperature is >
**               1000 (C or F), then don't display it!  (We can use this as a
**               flag to only display the message part, not the temp part).
** Inputs:       Message string for display, temperature value.
** Outputs:      .
*******************************************************************************/
void  display_msg_and_temp( char * s, F32 t )
{
  lcd_t display_status;
  char lcd[16];

  /* Display bottom line message. */
  strcpy( lcd, s );
  do
  {
    display_status = send_lcd_message( lcd, LCD_LINE2 );
  }
  while ( display_status == LCD_NOT_DONE );

  if ( t < 1000.0f )
  {
    /* Add temperature to display. */
    sprintf( lcd, "%7.2f", t );
    setup_LCD( LCD_MOVETO, 0x4B );    // start position (12) for t-digits
    LCD_Write( LCD_DATA, lcd[2] );   // MSD  position for 2-digit temp in C
    LCD_Write( LCD_DATA, lcd[3] );
    LCD_Write( LCD_DATA, lcd[4] );
    LCD_Write( LCD_DATA, lcd[5] );
  }

}  // end display_msg_and_temp()

/* tests.c ************************************************************** EOF */
