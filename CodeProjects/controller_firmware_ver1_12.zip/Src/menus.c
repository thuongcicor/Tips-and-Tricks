/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    menus.c
**
** Description: This module contains the menus and user selections that are
**              displayed on the LCD module.
**
** Version/Author/Date/Description:
** 1   DMA   04/13/2018  Began coding.
** 2   DMA   02/11/2019  Made changes for temperature values to eliminate the
**                       cumbersome x10 integer conversions.
** 3   DMA   03/11/2019  Bug fix going MANUAL-OFF to MANUAL-ON and vice-versa.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "lcd.h"
#include "config.h"
#include "eeprom.h"
#include "beep.h"
#include "keys.h"
#include "pwm.h"
#include "adc.h"
#include "intrinsics.h"  // need for instrinsic __nop function
#include <string.h>
#include <stdio.h>       // need for sprintf()

U8   tu_val;       // copy of the temperature units - 0=C, 1=F
U8   om_val;       // copy of the operating mode units, 0=auto, 1=user start
static  menu_adjust_vars_t  menu_vals;

/* Double stroke number goes in pos[5] in the level 1 "MENU  :" text. */
const char  level1_text[] = "MENU  :";       // top line menu for all level 1's
const char  level1_M1[]   = "SPH now: ";     // current SPH value added in func
const char  level2_M1[]   = "SPH Adjust:";
const char  level1_M2[]   = "SPL now: ";     // current SPL value added in func
const char  level2_M2[]   = "SPL Adjust:";
const char  level1_M3[]   = "Temp units: ";  // 'C' or 'F' added in func
const char  level2_M3[]   = "Temp unit edit";
const char  level1_M4[]   = "Op Mode: ";     // "Auto" or "Manual" added in func
const char  level2_M4[]   = "Op Mode edit:";
//const char  level1_M4a[]  = "[SET] to Start";
//const char  level1_M4b[]  = "[SET] to Stop";
const char  saved_msg[]   = "Value saved...";
const char  start_msg1[]  = " Press [SET]";
const char  start_msg2[]  = " to start.";

/* This table defines the current mode/state, the 4 pushbutton key inputs, and
** the specific command to execute.  The next state is determined in the command
** function.  Keep the pushbutton inputs in this order (within the block of 4),
** so that the menu_process function can find the proper function call. */
const menu_struct_t  menu_state_table[] =
{
  // State             input     menu command function
  // (.st_now)         (.pb_in)  (.function pointer)
  { NORM_OP_SCREEN,    PB_PWR,   menu_cmd_pwr_button },
  { NORM_OP_SCREEN,    PB_SET,   menu_cmd_start_auto },
  { NORM_OP_SCREEN,    PB_DOWN,  level_1_menu_1 },
  { NORM_OP_SCREEN,    PB_UP,    level_1_menu_1 },
  /* Press [SET] to start - manual mode display message. */
  { SET_TO_START,      PB_PWR,   menu_cmd_null },
  { SET_TO_START,      PB_SET,   menu_cmd_start_auto },
  { SET_TO_START,      PB_DOWN,  menu_cmd_null },
  { SET_TO_START,      PB_UP,    menu_cmd_null },
  /* MENU_1, level 1 - Setpoint Upper main display.  SET move to menu 1, level 2. */
  { MENU_1,            PB_PWR,   menu_cmd_go_back },
  { MENU_1,            PB_SET,   level_2_menu_1 },
  { MENU_1,            PB_DOWN,  level_1_menu_2 },
  { MENU_1,            PB_UP,    level_1_menu_4 },
  /* MENU_1, level 2 - Setpoint Upper adjust and save.  SET saves the adjusted value. */
  { MENU_21,           PB_PWR,   menu_cmd_go_back },
  { MENU_21,           PB_SET,   menu_cmd_save_temperature },
  { MENU_21,           PB_DOWN,  menu_cmd_adjust_temperature },
  { MENU_21,           PB_UP,    menu_cmd_adjust_temperature },
  /* MENU_2, level 1 - Setpoint Lower main display. */
  { MENU_2,            PB_PWR,   menu_cmd_go_back },
  { MENU_2,            PB_SET,   level_2_menu_2 },
  { MENU_2,            PB_DOWN,  level_1_menu_3 },
  { MENU_2,            PB_UP,    level_1_menu_1 },
  /* MENU_2, level 2 - Setpoint Lower adjust and save.  SET saves the adjusted value. */
  { MENU_22,           PB_PWR,   menu_cmd_go_back },
  { MENU_22,           PB_SET,   menu_cmd_save_temperature },
  { MENU_22,           PB_DOWN,  menu_cmd_adjust_temperature },
  { MENU_22,           PB_UP,    menu_cmd_adjust_temperature },
  /* MENU_3, level 1 - Temperature units, C or F, main display. */
  { MENU_3,            PB_PWR,   menu_cmd_go_back },
  { MENU_3,            PB_SET,   level_2_menu_3 },
  { MENU_3,            PB_DOWN,  level_1_menu_4 },
  { MENU_3,            PB_UP,    level_1_menu_2 },
  /* MENU_3, level 2 - Temperature units adjust and save.  SET saves the adjusted value. */
  { MENU_23,           PB_PWR,   menu_cmd_go_back },
  { MENU_23,           PB_SET,   menu_cmd_save_t_units },
  { MENU_23,           PB_DOWN,  menu_cmd_adjust_t_units },
  { MENU_23,           PB_UP,    menu_cmd_adjust_t_units },
  /* MENU_4, level 1 - Operating Mode, Auto or Manual, main display. */
  { MENU_4,            PB_PWR,   menu_cmd_go_back },
  { MENU_4,            PB_SET,   level_2_menu_4 },
  { MENU_4,            PB_DOWN,  level_1_menu_1 },
  { MENU_4,            PB_UP,    level_1_menu_3 },
  /* MENU_4, level 2 - Operating Mode adjust and save.  SET saves the adjusted value. */
  { MENU_24,           PB_PWR,   menu_cmd_go_back },
  { MENU_24,           PB_SET,   menu_cmd_save_om_units },
  { MENU_24,           PB_DOWN,  menu_cmd_adjust_om_units },
  { MENU_24,           PB_UP,    menu_cmd_adjust_om_units },
  /* This last section above, "MENU_24", does not get the function on PB_PWR
  ** correct!  Don't know why!!  See fix in "menu_cmd_null".  DMA - could be the post-increment!! for menu_ptr!! */

  { LAST_MENU_ITEM,    0,        menu_cmd_null }  // always the last item
};

/*******************************************************************************
** Function:     menu_process
** Description:  Called whenever a pushbutton is pressed.  Traverse thru the
**               menu/state list to find the current state and determine the
**               action to perform.
** Inputs:       U8 pushbutton id
** Outputs:
*******************************************************************************/
void  menu_process( U8 pb )
{
  menu_states_t  state;   // current menu state to look for in table
  menu_states_t  item;    // menu state values as we traverse the table
  U8   pb_key;            // pb value as we traverse the table items
  U8   menu_ptr = 0;

  state  = menu_mode_state( MENU_NONE, GET_DATA );  // current menu mode/state
  item   = menu_state_table[menu_ptr].st_now;       // state item from table
  pb_key = menu_state_table[menu_ptr].pb_in;        // pushbutton item from table

  while ( item != LAST_MENU_ITEM )
  {
    if (( item == state ) && ( pb == pb_key ))
    {
      /* We have a match for the state and keypress input.  Use the function
      ** pointer from the table to determine the command function call. */
      menu_state_table[menu_ptr].menu_fptr( );
      break;
    }
    else
    {
      item = menu_state_table[menu_ptr++].st_now;  // next table entry for state
      pb_key = menu_state_table[menu_ptr].pb_in;   // next table entry for pb
    }
  }  // end while

}  // end menu_process()

/*******************************************************************************
** Function:     level_1_menu_1
** Description:  Display: "MENU: 1 / SPH is now XX"
**               Add the bold, double stroke number for the menu number.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_1_menu_1( void )
{
  char lcd_line[16];
  U8    temp_adj;
  U8    tu;

  display_top_menu_line( 1 );

  menu_values_manager( LOAD_SPH_VALUE );  // load SPH value for adjusting

  /* Get the temperature units we need for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
  if ( tu == DEGREES_F )
  {
    temp_adj = menu_vals.spF;  // use the degrees F value
  }
  else
  {
    temp_adj = menu_vals.spC;  // use the degrees C value
  }

  /* Now create the 2nd line (bottom) for the menu display item. */
  strcpy( lcd_line, level1_M1 );  // set 2nd line of display with sph value
  strcat( lcd_line, s16_to_string( temp_adj, NO_SPACE_OR_0 ));
  if ( tu == DEGREES_F )
  {
    strcat( lcd_line, " F" );
  }
  else
  {
    strcat( lcd_line, " C" );
  }
  display_bottom_menu_line( lcd_line );

  menu_mode_state( MENU_1, SET_DATA );
  scrolling_set( NO );      // disable scrolling screen

}  // end level_1_menu_1()

/*******************************************************************************
** Function:     level_1_menu_2
** Description:  Display: "MENU: 2 / SPL is now XX"
**               Add the bold, double stroke number for the menu number.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_1_menu_2( void )
{
  char lcd_line[16];
  U8    temp_adj;
  U8    tu;

  display_top_menu_line( 2 );

  menu_values_manager( LOAD_SPL_VALUE );  // load SPL value for adjusting

  /* Get the temperature units we need for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
  if ( tu == DEGREES_F )
  {
    temp_adj = menu_vals.spF;  // use the degrees F value
  }
  else
  {
    temp_adj = menu_vals.spC;  // use the degrees C value
  }

  /* Now create the 2nd line (bottom) for the menu display item. */
  strcpy( lcd_line, level1_M2 );  // set 2nd line of display with spl value
  strcat( lcd_line, s16_to_string( temp_adj, NO_SPACE_OR_0 ));
  if ( tu == DEGREES_F )
  {
    strcat( lcd_line, " F" );
  }
  else
  {
    strcat( lcd_line, " C" );
  }
  display_bottom_menu_line( lcd_line );

  menu_mode_state( MENU_2, SET_DATA );
  scrolling_set( NO );      // disable scrolling screen

}  // end level_1_menu_2()

/*******************************************************************************
** Function:     level_1_menu_3
** Description:  Display "  MENU: 3" on the top line, and add the bold, double
**               stroke number for the menu number.  Also add the menu 3
**               display text and values for the bottom line.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_1_menu_3( void )
{
  char lcd_line[16];

  display_top_menu_line( 3 );

  /* Now create the 2nd line (bottom) for the menu display item. */
  strcpy( lcd_line, level1_M3 );  // set 2nd line of display
  tu_val = (U8)get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );  // copy of temp units
  if ( tu_val == DEGREES_F )
  {
    strcat( lcd_line, "F" );
  }
  else
  {
    strcat( lcd_line, "C" );
  }
  display_bottom_menu_line( lcd_line );

  menu_mode_state( MENU_3, SET_DATA );
  scrolling_set( NO );          // disable scrolling screen

}  // end level_1_menu_3()

/*******************************************************************************
** Function:     level_1_menu_4
** Description:  Display "  MENU: 4" on the top line, and add the bold, double
**               stroke number for the menu number.  Also add the menu 4
**               display text and values for the bottom line.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_1_menu_4( void )
{
  char lcd_line[16];

  display_top_menu_line( 4 );

  /* Now create the 2nd line (bottom) for the menu display item. */
  strcpy( lcd_line, level1_M4 );  // set 2nd line of display
  om_val = (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 );  // copy of operating mode

  if ( om_val )
  {
    strcat( lcd_line, " MANUAL" );
  }
  else
  {
    strcat( lcd_line, " AUTO  " );
  }
  display_bottom_menu_line( lcd_line );

  menu_mode_state( MENU_4, SET_DATA );
  scrolling_set( NO );          // disable scrolling screen

}  // end level_1_menu_4()

/*******************************************************************************
** Function:     level_2_menu_1
** Description:  Display " SPH ADJUST " on the top line, and add the temperature
**               units on this line.  The bottom line will contain the display
**               value text that is adjusted up or down.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_2_menu_1( void )
{
  lcd_t display_status;
  char lcd_line[16];
  U8    temp_adj;
  U8    tu;

  menu_mode_state( MENU_21, SET_DATA );

  strcpy( lcd_line, level2_M1 );
  lcd_line[12] = degree_symbol;

  /* Get the temperature units we need for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
  if ( tu == DEGREES_F )
  {
    lcd_line[13] = 'F';
    temp_adj = menu_vals.spF;  // use the degrees F value
  }
  else
  {
    lcd_line[13] = 'C';
    temp_adj = menu_vals.spC;  // use the degrees C value
  }
  lcd_line[14] = NULL;

  setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

  /* Create 2nd line (bottom) for the setpoint adjust value. */
  strcpy( lcd_line, "  " );  // pos. 0 & 1 blank, temperature in pos. 2 & 3
  strcat( lcd_line, s16_to_string( temp_adj, NO_SPACE_OR_0 ));
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE2 );
  }
  while ( display_status == LCD_NOT_DONE );

}  // end level_2_menu_1()

/*******************************************************************************
** Function:     level_2_menu_2
** Description:  Display " SPL ADJUST " on the top line, and add the temperature
**               units on this line.  The bottom line will contain the display
**               value text that is adjusted up or down.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_2_menu_2( void )
{
  lcd_t display_status;
  char lcd_line[16];
  U8    temp_adj;
  U8    tu;

  menu_mode_state( MENU_22, SET_DATA );

  strcpy( lcd_line, level2_M2 );
  lcd_line[12] = degree_symbol;

  /* Get the temperature units we need for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );
  if ( tu == DEGREES_F )
  {
    lcd_line[13] = 'F';
    temp_adj = menu_vals.spF;  // use the degrees F value
  }
  else
  {
    lcd_line[13] = 'C';
    temp_adj = menu_vals.spC;  // use the degrees C value
  }
  lcd_line[14] = NULL;

  setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

  /* Create 2nd line (bottom) for the setpoint adjust value. */
  strcpy( lcd_line, "  " );  // pos. 0 & 1 blank, temperature in pos. 2 & 3
  strcat( lcd_line, s16_to_string( temp_adj, NO_SPACE_OR_0 ));
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE2 );
  }
  while ( display_status == LCD_NOT_DONE );

}  // end level_2_menu_2()

/*******************************************************************************
** Function:     level_2_menu_3
** Description:  Display " TEMP UNITS: " on the top line.  The bottom line will
**               will display either the 'C' or 'F', and UP/DOWN will toggle
**               between these two values.  Use the previously loaded tu_val
**               to determine temperature units.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_2_menu_3( void )
{
  lcd_t display_status;
  char lcd_line[16];

  menu_mode_state( MENU_23, SET_DATA );

  strcpy( lcd_line, level2_M3 );
  setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

  /* Create 2nd line (bottom) - Get copy of EE value for temp units, and
  ** assign the proper ascii char for display. */
  strcpy( lcd_line, "  " );  // pos. 0 & 1 blank, temperature unit in pos. 2, 3
  lcd_line[2] = degree_symbol;
  lcd_line[3] = tu_val ? 'F' : 'C';
  lcd_line[4] = NULL;
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE2 );
  }
  while ( display_status == LCD_NOT_DONE );

}  // end level_2_menu_3()

/*******************************************************************************
** Function:     level_2_menu_4
** Description:  Display " Op Mode: " on the top line.  The bottom line will
**               will display either "Auto" or "Manual", and UP/DOWN will
**               toggle between these two values.  Use the previously loaded
**               om_val to determine the selected operating mode.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  level_2_menu_4( void )
{
  lcd_t display_status;
  char lcd_line[16];

  menu_mode_state( MENU_24, SET_DATA );

  strcpy( lcd_line, level2_M4 );
  setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

  if ( om_val )
  {
    strcpy( lcd_line, "  MANUAL" );
  }
  else
  {
    strcpy( lcd_line, "  AUTO  " );
  }
  display_bottom_menu_line( lcd_line );

}  // end level_2_menu_4()

/*******************************************************************************
** Function:     display_top_menu_line
** Description:  This function creates the top display line  "  MENU: x",
**               where 'x' is the bold, double stroke menu number.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  display_top_menu_line( U8 num )
{
  lcd_t display_status;
  char lcd_line[16];

  if ( num > 9 )
  {
    num = 0;  // limit check - this is essentially an error condition
  }
  load_double_stroke_number( num );  // creates the bold number

  strcpy( lcd_line, level1_text );
  lcd_line[5] = LOAD_CGRAM_5;      // put created bold number in pos[5]

  setup_LCD( LCD_CLEAR, 0 );       // reset and clear LCD module
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

}  // end display_top_menu_line()

/*******************************************************************************
** Function:     display_bottom_menu_line
** Description:  Displays the data on the 2nd (bottom) line of the LCD.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  display_bottom_menu_line( char * str )
{
  lcd_t display_status;

  clear_line( 2 );

  do
  {
    display_status = send_lcd_message( str, LCD_LINE2 );
  }
  while ( display_status == LCD_NOT_DONE );

}  // end display_bottom_menu_line()

/*******************************************************************************
** Function:     display_value_saved_msg
** Description:  After the SET key is pressed on a level 2 menu, the specific
**               parameter value is saved, and the value saved message is
**               displayed for a short time.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void  display_value_saved_msg( void )
{
  lcd_t display_status;
  char lcd_line[16];

  setup_LCD( LCD_CLEAR, 0 );      // reset and clear LCD module
  strcpy( lcd_line, saved_msg );
  do
  {
    display_status = send_lcd_message( lcd_line, LCD_LINE1 );
  }
  while ( display_status == LCD_NOT_DONE );

  /* Set the flag and timer to allow the "VALUE SAVED..." message to display
  ** for the designated time. */
  display_busy_set( YES );
  task_timer_start( LCD_BUSY, 2200, ONE_SHOT );


  /* If we just saved the om value for manual start-up mode, turn off display,
  ** backlight, tec, leds and fans.
  ** Go to idle mode and wait for PWR button press... */
  // < insert code here... >

//    main_temp_display( 0 );   <--- NEED TO ADD A "RESET DISPLAY" FUNCTION AFTER TESTS IN ISC OPERATION MODE

}  // end display_value_saved_msg()

/*******************************************************************************
** Function:     menu_cmd_adjust_temperature
** Description:  Increment or decrement the setpoint value.  Based on MENU_21
**               (for SPH) or MENU_22 (for SPL), and on the UP/DOWN pushbutton.
**               Only the UP/DOWN pb keys should get us here.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_adjust_temperature( void )
{
  char           * t_str;
  U16            adjust_val;
  U8             pushbutton;
  U8             tu;
  U8             t_upper;   // temperature value, upper limit
  U8             t_lower;   // temperature value, lower limit
  menu_states_t  m_state;   // current menu mode/state

  m_state = menu_mode_state( MENU_NONE, GET_DATA );
  pushbutton = get_pushbutton_id( );  // get pushbutton ID value
  /* Get the temperature units we need for the display (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

  if ( m_state == MENU_21 )
  {
    if ( tu == DEGREES_F )
    {
      t_upper = ISC_SPH_UPPER_TEMP_LIMIT_F;  // highest value for SPH (F)
      t_lower = ISC_SPH_LOWER_TEMP_LIMIT_F;  // lowest value for SPH (F)
    }
    else
    {
      t_upper = ISC_SPH_UPPER_TEMP_LIMIT_C;  // highest value for SPH (C)
      t_lower = ISC_SPH_LOWER_TEMP_LIMIT_C;  // lowest value for SPH (C)
    }
  }
  else
  {
    if ( tu == DEGREES_F )
    {
      t_upper = ISC_SPL_UPPER_TEMP_LIMIT_F;  // highest value for SPL (F)
      t_lower = ISC_SPL_LOWER_TEMP_LIMIT_F;  // lowest value for SPL (F)
    }
    else
    {
      t_upper = ISC_SPL_UPPER_TEMP_LIMIT_C;  // highest value for SPL (C)
      t_lower = ISC_SPL_LOWER_TEMP_LIMIT_C;  // lowest value for SPL (C)
    }
  }

  if ( pushbutton == PB_DOWN )
  {
    /* Decrement adjust value and check lower limit. */
    if ( tu == DEGREES_F )
    {
      if ( --menu_vals.spF < t_lower )
      {
        menu_vals.spF = t_lower;
      }
      adjust_val = menu_vals.spF;
    }
    else
    {
      if ( --menu_vals.spC < t_lower )
      {
        menu_vals.spC = t_lower;
      }
      adjust_val = menu_vals.spC;
    }
  }
  else
  {
    /* Increment adjust value and check upper limit. */
    if ( tu == DEGREES_F )
    {
      if ( ++menu_vals.spF > t_upper )
      {
        menu_vals.spF = t_upper;
      }
      adjust_val = menu_vals.spF;
    }
    else
    {
      if ( ++menu_vals.spC > t_upper )
      {
        menu_vals.spC = t_upper;
      }
      adjust_val = menu_vals.spC;
    }
  }

  /* Convert the temperature value to BCD and display it. */
  setup_LCD( LCD_MOVETO, 0x42 );  // start position for t-digits
  t_str = hex_2_bcd( adjust_val );

  /* Send the adjust digits to the display.  The hex_2_bcd function never
  ** returns more than 5 digits). */
  U8 num = 0;
  while ( num < 5 )
  {
    if ( t_str[num] != ' ' )
    {
      LCD_Write( LCD_DATA, t_str[num] );  // display digit if not blank
    }
    num++;
  }  // end while

  /* In the case where we go from a 3 digit value back to a 2 digit value, we
  ** need to clear the last digit position - i.e., going from 100 to 99. */
  LCD_Write( LCD_DATA, ' ' );

}  // end menu_cmd_adjust_temperature()

/*******************************************************************************
** Function:     menu_cmd_adjust_t_units
** Description:  Toggle between the two temperature unit values, C or F.
**               Only the UP/DOWN pb keys should get us here.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_adjust_t_units( void )
{

  /* Toggle from current temp unit value to other temp unit value, using the
  ** previously loaded tu_val.  Range of values for tu_val: 0=C, 1=F. */
  tu_val = ( tu_val ) ? 0 : 1;

  /* Display the F or C value. */
  setup_LCD( LCD_MOVETO, 0x42 );  // display start position for t_unit value
  LCD_Write( LCD_DATA, degree_symbol );
  LCD_Write( LCD_DATA, tu_val ? 'F' : 'C' );

}  // end menu_cmd_adjust_t_units()

/*******************************************************************************
** Function:     menu_cmd_adjust_om_units
** Description:  Toggle between the two operating mode unit values, auto or
**               manual.  Only the UP/DOWN pb keys should get us here.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_adjust_om_units( void )
{
  char lcd_line[16];

  /* Don't care what the pushbutton was - we are going to toggle from current
  ** operating mode to the other operating mode units regardless.
  ** Use previously load om_val.
  ** Range of values for om_val: 0=auto start, 1=user start (manual). */
  om_val = ( om_val ) ? 0 : 1;

  /* Now create the 2nd line (bottom) for the menu display item. */
  if ( om_val )
  {
    strcpy( lcd_line, "  MANUAL" );
  }
  else
  {
    strcpy( lcd_line, "  AUTO  " );
  }
  display_bottom_menu_line( lcd_line );

}  // end menu_cmd_adjust_om_units()

/*******************************************************************************
** Function:     menu_cmd_save_temperature
** Description:  Store the new setpoint value.  Based on MENU_21 (for SPH) or
**               MENU_22 (for SPL).  Remember - save temps in DEGREES_C.
**               Only the SET pb key should get us here.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_save_temperature( void )
{
  menu_states_t  m_state;
  U8             tu;

  m_state = menu_mode_state( MENU_NONE, GET_DATA );

  /* Get the temperature units that we have been working with (1=F, 0=C). */
  tu = get_ee_parameter( EE_TEMP_UNITS, EE_DATA_8 );

  /* We're done with the temperature adjustment. Update the other temperature
  ** value, to keep both in-sync. */
  if ( tu == DEGREES_F )
  {
    /* Degrees F was adjusted, so update degree C value, for SPH or SPL. */
    if ( m_state == MENU_21 )
    {
      menu_values_manager( SAVE_DEGREE_C_VALUE_SPH );
    }
    else
    {
      menu_values_manager( SAVE_DEGREE_C_VALUE_SPL );
    }
  }
  else
  {
    /* Degrees C was adjusted, so update degree F value, for SPH or SPL. */
    if ( m_state == MENU_21 )
    {
      menu_values_manager( SAVE_DEGREE_F_VALUE_SPH );
    }
    else
    {
      menu_values_manager( SAVE_DEGREE_F_VALUE_SPL );
    }
  }

  /* Now go back to previous mode.........do two beeps to indicate a completed action */
  set_idle_mode( );
  beeper_trigger( );
  pb_init( PB_SET_DONE );  // action completed - reset key action values
  display_value_saved_msg( );
  ctrl_mode_state( RUN_MODE, SET_DATA );  // combine this in the set_idle_mode() - but for now, leave here...

}  // end menu_cmd_save_temperature()

/*******************************************************************************
** Function:     menu_cmd_save_t_units
** Description:  Store the new temperature units value.
**               Values for temp units: 0 = degrees C, 1 = degrees F.
**               Only the SET pb key should get us here, from Menu_23.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_save_t_units( void )
{

  /* Store temperature units value, which is either 0 or 1. */
  i2c_ee_write( tu_val, EE_TEMP_UNITS, EE_DATA_8 );

  /* Now go back to previous mode............. do two beeps to indicate a completed action */
  set_idle_mode( );
  beeper_trigger( );
  pb_init( PB_SET_DONE );  // action completed - reset key action values
  display_value_saved_msg( );
  ctrl_mode_state( RUN_MODE, SET_DATA );  // combine this in the set_idle_mode() - but for now, leave here...

}  // end menu_cmd_save_t_units()

/*******************************************************************************
** Function:     menu_cmd_save_om_units
** Description:  Store the new operating mode units value.
**               Values for operating mode units: 0 = auto start, 1 = manual start.
**               Only the SET pb key should get us here, from Menu_24.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_save_om_units( void )
{

  /* Store operating mode units value, which is either 0 or 1. */
  i2c_ee_write( om_val, EE_START_MODE, EE_DATA_8 );

  /* Now go back to previous mode............. do two beeps to indicate a completed action */
  set_idle_mode( );
  beeper_trigger( );
  pb_init( PB_SET_DONE );  // action completed - reset key action values
  display_value_saved_msg( );
  ctrl_mode_state( RUN_MODE, SET_DATA );  // combine this in the set_idle_mode() - but for now, leave here...

}  // end menu_cmd_save_om_units()

/*******************************************************************************
** Function:     menu_values_manager
** Description:  Manages and updates various values used in the menuing control.
**               Also updates temperature values (in both C and F), used in the
**               setpoint adjustment function.
** Inputs:       menu_adj_cmnds_t - various menu adjustment commands
** Outputs:      none
*******************************************************************************/
void  menu_values_manager( menu_adj_cmnds_t action )
{
  F32 fx;

  if ( action == LOAD_SPH_VALUE )
  {
    /* Get rounded (whole number) temperature copy for adjusting. */
    menu_vals.spC = (U16)round_float( get_sp_value( SPH_C ), 0 );
    menu_vals.spF = (U16)round_float( get_sp_value( SPH_F ), 0 );
  }
  if ( action == LOAD_SPL_VALUE )
  {
    /* Get rounded (whole number) temperature copy for adjusting. */
    menu_vals.spC = (U16)round_float( get_sp_value( SPL_C ), 0 );
    menu_vals.spF = (U16)round_float( get_sp_value( SPL_F ), 0 );
  }
  /* For the SAVE_DEGREE_xx functions, the user has adjusted the C or F values
  ** for either the SPH or SPL.  Update/save both degree C and degree F values
  ** so that they remain in-sync.  The menu_vals.xxx item is no longer needed
  ** after saving the EE and SP data. */
  if ( action == SAVE_DEGREE_C_VALUE_SPH )
  {
    fx = temperature_convert( (F32)menu_vals.spF, F_to_C );
    set_real_data( fx, EE_SPH );
    set_sp_value( fx, SPH_C );
  }
  if ( action == SAVE_DEGREE_C_VALUE_SPL )
  {
    fx = temperature_convert( (F32)menu_vals.spF, F_to_C );
    set_real_data( fx, EE_SPL );
    set_sp_value( fx, SPL_C );
  }
  if ( action == SAVE_DEGREE_F_VALUE_SPH )
  {
    fx = temperature_convert( (F32)menu_vals.spC, C_to_F );
    set_real_data( fx, EE_SPH );
    set_sp_value( fx, SPH_C );
  }
  if ( action == SAVE_DEGREE_F_VALUE_SPL )
  {
    fx = temperature_convert( (F32)menu_vals.spC, C_to_F );
    set_real_data( fx, EE_SPL );
    set_sp_value( fx, SPL_C );
  }

}  // end menu_values_manager()

/*******************************************************************************
** Function:     menu_cmd_pwr_button
** Description:  PWR/ON/OFF button will togggle the unit between PWR_OFF_MODE
**               and normal RUN_MODE.  The unit inits to RUN_MODE when the Auto
**               start mode is set, and the unit inits to PWR_OFF_MODE when the
**               Manual start mode is set.  Display the copyright and version
**               info on power-on (fast mode).
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_pwr_button( void )
{
  lcd_t display_status;
  char lcd_line[16];

  /* If in the factory test mode, this will reset things to normal operation. */
  if (( ctrl_mode_state( NONE, GET_DATA ) == PWR_OFF_MODE )      ||
      ( ctrl_mode_state( NONE, GET_DATA ) == TEST_MODE_ACTIVE )  ||
      ( ctrl_mode_state( NONE, GET_DATA ) == TEST_MODE_PASS )    ||
      ( ctrl_mode_state( NONE, GET_DATA ) == TEST_MODE_FAIL ))
  {
    lcd_backlight_control( ON );
    set_manual_entry_keys( MANUAL_SET_KEY_ALLOWED );
//    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
//    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
//    tec_ctrl( NO_HEAT_NO_COOL );
    led_on_off( MEMB_GREEN, ON );
//    setup_LCD( LCD_CLEAR, 0 );
    menu_mode_state( NORM_OP_SCREEN, SET_DATA );

    ctrl_mode_state( INIT_MODE, SET_DATA );

    if ((U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == MANUAL_MODE )
    {
      /* We are in Manual start mode, first display the copyright and version.
      ** Then display "Press [SET] to start" on the top line of the LCD. */
      splash_screen( SPLASH_FAST );
      setup_LCD( LCD_CLEAR, 0 );
      strcpy( lcd_line, start_msg1 );
      do
      {
        display_status = send_lcd_message( lcd_line, LCD_LINE1 );
      }
      while ( display_status == LCD_NOT_DONE );

      /* Display the bottom line for the user. */
      strcpy( lcd_line, start_msg2 );
      do
      {
        display_status = send_lcd_message( lcd_line, LCD_LINE2 );
      }
      while ( display_status == LCD_NOT_DONE );

      menu_mode_state( SET_TO_START, SET_DATA );
    }
    else
    {
      /* We are in Auto start mode, so get going! */
      menu_cmd_start_auto( );
    }
  }
  else
  {
    lcd_backlight_control( OFF );
    set_manual_entry_keys( MANUAL_NO_KEYS_ALLOWED );
    led_on_off( MEMB_GREEN, OFF );
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
    tec_ctrl( NO_HEAT_NO_COOL );
    setup_LCD( LCD_CLEAR, 0 );
    set_manual_ok_to_start_flag( NO );
    menu_mode_state( NORM_OP_SCREEN, SET_DATA );  // initial menu/screen mode
    ctrl_mode_state( PWR_OFF_MODE, SET_DATA );
  }

  // THIS SECTION IS FOR THE MANUAL START MODE...NEED TO FIX TO INCLUDE "PWR_OFF_MODE"...
#if 0
  if ( get_manual_entry_keys( ) == MANUAL_ALL_KEYS_ALLOWED )
  {
    /* The PWR ON/OFF button has been pressed and all keys were active in
    ** Manual start-up mode. Now go back to power-down conditions. */
    lcd_backlight_control( OFF );
    set_manual_entry_keys( MANUAL_NO_KEYS_ALLOWED );
    led_on_off( MEMB_GREEN, OFF );
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
    tec_ctrl( NO_HEAT_NO_COOL );  // sets PWM value = 0
    setup_LCD( LCD_CLEAR, 0 );
    set_manual_ok_to_start_flag( NO );
    menu_mode_state( NORM_OP_SCREEN, SET_DATA );  // initial menu/screen mode
    ctrl_mode_state( PWR_OFF_MODE, SET_DATA );
  }
  else
  {
    /* This is the first PWR ON/OFF button press in manual start-up mode. */
    lcd_backlight_control( ON );
    set_manual_entry_keys( MANUAL_NO_KEYS_ALLOWED??? );
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
    fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
    tec_ctrl( NO_HEAT_NO_COOL );  // sets PWM value = 0
    led_on_off( MEMB_GREEN, ON );
    setup_LCD( LCD_CLEAR, 0 );

    /* Display "Press [SET] to start".  First output the top line. */
    strcpy( lcd_line, start_msg1 );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE1 );
    }
    while ( display_status == LCD_NOT_DONE );

    /* Display the bottom line for the user. */
    strcpy( lcd_line, start_msg2 );
    do
    {
      display_status = send_lcd_message( lcd_line, LCD_LINE2 );
    }
    while ( display_status == LCD_NOT_DONE );
  }
#endif

}  // end menu_cmd_pwr_button()

/*******************************************************************************
** Function:     menu_cmd_start_auto
** Description:  The user has pressed the SET button to intiate the start from
**               Manual mode to auto start mode.  Or, already in auto mode, and
**               we need to re-display the normal operation screen.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_start_auto( void )
{

  setup_LCD( LCD_CLEAR, 0 );

  /* We need to re-start some processes, and not change the stored start mode.
  ** This is a manual start-up command. We are still in manual mode for the
  ** next reset/power-cycle. */
  //set_manual_entry_keys( ??OFF );
  set_manual_ok_to_start_flag( YES );
  /* Now go back to previous mode.........do two beeps to indicate a completed action */
  set_idle_mode( );
  beeper_trigger( );
  pb_init( PB_SET_DONE );  // action completed - reset key action values

  fan_ctrl( FAN1_CH, FAN_SPEED_OFF );
  fan_ctrl( FAN2_CH, FAN_SPEED_OFF );
  tec_ctrl( NO_HEAT_NO_COOL );  // set PWM value = 0, and turn off the RED or BLUE LED

  /* If we are already in auto start mode, then this is a power button press to
  ** get back to normal display mode. */
  if ( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == AUTO_MODE )
  {
//    menu_mode_set( CTRL_SCREEN );  // MAY NEED "PWR_OFF_MODE" SET /RESET HERE...
  }

}  // end menu_cmd_start_auto()

/*******************************************************************************
** Function:     menu_cmd_go_back
** Description:  The user has pressed the PWR/ON/OFF button - depending on where
**               we are, go back one level or, if in manual mode, go back to
**               initial manual mode settings.  (like an "esc" function).
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_go_back( void )
{
  menu_states_t  m_state;

  m_state = menu_mode_state( MENU_NONE, GET_DATA );

  switch ( m_state )
  {
    case NORM_OP_SCREEN:
    case MENU_1:
    case MENU_2:
    case MENU_3:
    case MENU_4:
      menu_cmd_pwr_button( );
      break;

    case MENU_21:
      level_1_menu_1( );
      break;

    case MENU_22:
      level_1_menu_2( );
      break;

    case MENU_23:
      level_1_menu_3( );
      break;

    case MENU_24:
      level_1_menu_4( );
      break;

    default:
      break;
  }  // end switch

}  // end menu_cmd_go_back()

/*******************************************************************************
** Function:     menu_cmd_null
** Description:  Default function for menu items that do not require any action,
**               or placeholder while functionality is under development.
**               <See note below for possible compiler bug!>
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  menu_cmd_null( void )
{
  menu_states_t  m_state;
  /* Note:  The compiler will *not* call the function correctly for PB_PWR in
  ** MENU_24.  Something to do with the last section of the menu table!!??
  ** Anyway, this fix will be a workaround until I figure it out!
  ** (Could it be the post-increment in menu_process()?? OY!) */
  m_state = menu_mode_state( MENU_NONE, GET_DATA );
  if ( m_state == MENU_24 )
  {
    menu_cmd_go_back( );
  }

}  // end menu_cmd_null()

/* menus.c ************************************************************** EOF */
