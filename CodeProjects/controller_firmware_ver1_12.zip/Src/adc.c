/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    adc.c
**
** Description: This module contains the controls and functions associated with
**              the internal ADC module.  This project currently uses one
**              external thermistor (10K, NTC) to measure the cold-sink
**              temperature.  There is one internal STM32 temperature sensor
**              which uses one channel of the ADC, and one channel that is used
**              to measure the internal STM32 reference voltage.
**
** Version/Author/Date/Description:
** 1   DMA   01/21/2018  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "adc.h"
#include "eeprom.h"
#include <math.h>
//#include <stdlib.h>
#include "intrinsics.h"  // need for instrinsic __nop function

/* Declare the struct handle for low-level ADC config (hadc), and the main
** control structure for all application-related ADC functions. */
ADC_HandleTypeDef  hadc;
static adc_control_t  adc_vals[ADC_TOTAL_CHANNELS];
static U32            adc_channel;

/*******************************************************************************
** Function:     adc_init
** Description:  Configure the internal, 12-bit ADC in the STM32 micro.
**               Set up the structs and variables needed for ADC-related
**               application and control.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  adc_init( void )
{
  U8 i1;
  U8 i2;

  MX_ADC_Init();

  /* Reset the channel number, averages, totals, index value, counts and
  ** sequence for all ADC inputs. */
  for ( i2 = 0; i2 < ADC_TOTAL_CHANNELS; ++i2 )
  {
    for ( i1 = 0; i1 < ADC_ARRAY_TOP; ++i1 )
    {
      adc_vals[i2].ADC_in[i1]  = 0;  // input samples array
    }
    adc_vals[i2].ADC_total     = 0;  // total of all input samples
    adc_vals[i2].ADC_avg       = 0;  // moving time-average of all input samples
    adc_vals[i2].idx           = 0;  // array index value for input samples
    adc_vals[i2].circuit_open  = 0;  // number open-circuit conditions detected
    adc_vals[i2].circuit_short = 0;  // number short-circuit conditions detected
    adc_vals[i2].errors        = ADC_OK;  // start with no errors
    adc_vals[i2].sequence      = ADC_SEQUENCE_CONFIG_CHANNEL;
  }  // end for
  adc_channel = ADC_CHANNEL_0;  // also acts as the adc_vals[x] struct pointer

}  // end adc_init()

/*******************************************************************************
** Function:     update_adc_events
** Description:  Called periodically from the main loop.  Update the sequence
**               and perform the next action for the selected ADC channel.
** Inputs:       none
** Outputs:      none
*******************************************************************************/
void  update_adc_events( void )
{
  U16  count_offset;

  switch ( adc_vals[adc_channel].sequence )
  {
    case ADC_SEQUENCE_CONFIG_CHANNEL:
      adc_config_channel( adc_channel, ON );
      adc_vals[adc_channel].sequence = ADC_SEQUENCE_START;  // next action
      break;

    case ADC_SEQUENCE_START:
      adc_start( );
      adc_vals[adc_channel].sequence = ADC_SEQUENCE_GET_VALUE;  // next action
      break;

    case ADC_SEQUENCE_GET_VALUE:
      /* Get the current ADC count value and update array, then use averages to
      ** calculate the real, floating point C and F temperatures for channels
      ** 0-3.  Channels 4-7 are the voltage monitors. */
      adc_update_averages( );
      if ( adc_channel < ADC_CHANNEL_4 )
      {
        /* Do temperature conversions for these channels. */
        /* Perform this count offset to compensate for some unknown reason?!?!....
        ** VrefInt doesn't account for this!  But this equation seems to get us
        ** closer to the actual temperature value.  Also, the ADC inputs seem
        ** pretty close for the voltage monitor inputs!  Curious...... */
        count_offset = (U16)(( adc_vals[adc_channel].ADC_avg * 1.1f ) - 10.427f );
        adc_vals[adc_channel].temp_C = modified_steinhart_hart( count_offset );
        adc_vals[adc_channel].temp_F = temperature_convert( adc_vals[adc_channel].temp_C, C_to_F );
      }
      adc_vals[adc_channel].sequence = ADC_SEQUENCE_STOP;  // next action
      break;

    case ADC_SEQUENCE_STOP:
      adc_stop( adc_channel );
      adc_vals[adc_channel].sequence = ADC_SEQUENCE_NEXT_CHANNEL;  // next action
      break;

    case ADC_SEQUENCE_NEXT_CHANNEL:
    /* Note: ADC channel numbers are sequential. */
      if ( ++adc_channel >= ADC_TOTAL_CHANNELS )
      {
        adc_channel = ADC_CHANNEL_0;  // reset to first ADC channel
      }
      /* Reset sequence to beginning for next channel. */
      adc_vals[adc_channel].sequence = ADC_SEQUENCE_CONFIG_CHANNEL;
      break;

    default:
      break;

  }  // end switch

}  // end update_adc_events()

/*******************************************************************************
** Function:     adc_cal
** Description:  Starts the internal calibration on the STM32 ADC module.
**               This function is called after init, but before the ADC is
**               started or when the ADC is stopped.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  adc_cal( void )
{
  if (HAL_ADCEx_Calibration_Start(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
}  // end adc_cal()

/*******************************************************************************
** Function:     adc_start
** Description:  Starts the ADC conversion on the preset channel.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void  adc_start( void )
{
  if (HAL_ADC_Start(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
}  // end adc_start()

/*******************************************************************************
** Function:     adc_get_val
** Description:  After conversion is complete, read the ADC count value on
**               the preseleced channel.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
U16  adc_get_val( void )
{
  U16  rtn_val;

  if (HAL_ADC_PollForConversion(&hadc, 10) != HAL_OK)
  {
    Error_Handler();  // end of conversion (EOC) flag not set on time
    rtn_val = 0;      // **use error value here**
  }
  else
  {
    /* ADC conversion is complete - get value and return. */
    rtn_val = HAL_ADC_GetValue(&hadc);
  }
  return  rtn_val;

}  // end adc_get_val()

/*******************************************************************************
** Function:     adc_stop
** Description:  Stops the ADC channel conversion activity, and disables the
**               selected ADC channel.
** Inputs:       ADC channel number (defined in stm32f0xx_hal_adc_ex.h).
** Outputs:      none.
*******************************************************************************/
void  adc_stop( U32 channel )
{

  HAL_ADC_Stop(&hadc);
  adc_config_channel( channel, OFF );

}  // end adc_stop()

/*******************************************************************************
** Function:     update_adc_averages
** Description:  Take current ADC reading, add it to the total and average the
**               counts.  The number of samples in the total ADC counts is
**               always a binary multiple so that averaging is easy and fast
**               for integer values.  The algorithm:
**               1. subtract oldest value from total.
**               2. error check for total < 0 (remember, ADC count value, not temp.)
**               3. load new ADC value into array and add to total.
**               4. update the array index pointer.
**               5. get new average ADC value.
**
** Inputs:       .
** Outputs:
*******************************************************************************/
void  adc_update_averages( void )
{
  U16  ADC_value;

  /* Read ADC converted value from the previously configured channel. */
  ADC_value = adc_get_val( );

  /* Subtract the oldest value from the array, add in the newest value, update
  ** the array index pointer and re-average the array samples. */
  adc_vals[adc_channel].ADC_total -= adc_vals[adc_channel].ADC_in[adc_vals[adc_channel].idx];
  if ( adc_vals[adc_channel].ADC_total < 0 )  // error check
  {
    adc_vals[adc_channel].ADC_total = 0;
  }
  adc_vals[adc_channel].ADC_in[adc_vals[adc_channel].idx] = ADC_value;  // latest sample
  adc_vals[adc_channel].ADC_total += ADC_value;
  if ( ++adc_vals[adc_channel].idx > ADC_ARRAY_TOP )
  {
    adc_vals[adc_channel].idx = 0;
  }
  adc_vals[adc_channel].ADC_avg = adc_vals[adc_channel].ADC_total >> SHIFT_DIVIDE;

}  // end adc_update_averages()

/*******************************************************************************
** Function:     modified_steinhart_hart
** Description:  Basically the same as used in TecTraum and Climatherm projects.
**               The standard/normal Steinhart-Hart equation:
**               1/T = A + B*ln(R) + C(ln(R))^3
**               We've reduced/simplified/modified the equation for our use,
**               ignoring the coefficients A, B and C, and using beta instead:
**               T = beta/(ln(Rtherm/(R0 * e^(-beta1/T1)))), where:
**               1. T1 = 25C = 298.15K.
**               2. beta = 3450 (default). User settable parm.
**               3. R0 = 10000 (resistance at 25C).
**               4. Rtherm = ((Vcc/Vmeasured) - 1) * Rdivider.
**               Further simplifying, we can use the ADC count value and Vref
**               for the ratio of Vcc/Vmeasured, which gives:
**               ((ADC_MAX / ADC_count) - 1) * Rdivider.
**               Also, adjust for op-amp buffer gain value (see code comment).
** Inputs:       U16 moving average ADC count value.
** Outputs:      F32 temperature in degrees C.
*******************************************************************************/
F32  modified_steinhart_hart( U16 adc_count_val )
{
  F32 rtn_val;
  F32 x1;
  F32 x2;
  U16 beta;

  if ( adc_count_val == 0 )
  {
    x1 = 0.000001f;  // avoid the 0 divide in the calculation below
  }
  else
  {
    x1 = (F32)adc_count_val / OP_AMP_GAIN;  // adjust for op-amp circuit gain
    x2 = (( RES_DIVIDE * ((float)MAX_FULL_SCALE - x1 )) / x1 );
  }
  if ( fabs( x2 - RES_DIVIDE ) < 0.000001f )
  {
    x2 = RES_DIVIDE + 0.001f;  // eliminates a 0 from the log func below
  }

  x2 = log( 10000.0f / x2 );   // natural log (ln) function, R0 = 10K @ 25C
  beta = get_ee_parameter( EE_BETA, EE_DATA_16 );  // stored thermistor beta
  x1 = (F32)beta / x2;

  x2 = x1 - T1;

  /* Correct if 0 (or close enough to 0). */
  if ( fabs( x2 ) < 0.000001f )
  {
    x2 = 0.000001f;
  }
  rtn_val = ( x1 * T1 ) / x2;                 // deg K temperature
  rtn_val = rtn_val - KELVIN_CONVERT_FACTOR;  // deg C temperature

  return  rtn_val;

} // end modified_steinhart_hart()

/*******************************************************************************
** Function:     get_current_temperature
** Description:  Return the current temperature value for thermistor x.
** Inputs:       Temp sensor (thermistor) 0-3, and C or F flag.
** Outputs:      F32 value - real temperature in C or F for selected thermistor.
*******************************************************************************/
F32  get_current_temperature( U8 channel, U8 units )
{
  F32  t_val = 999.9f;  // error value if bounds check fails

  if ( channel < 4 )    // bounds check...(should use "assert" here)
  {
    if ( units == DEGREES_C )
    {
      t_val = adc_vals[channel].temp_C;
    }
    else
    {
      t_val = adc_vals[channel].temp_F;
    }
  }
  return  t_val;

}  // end get_current_temperature()

/*******************************************************************************
** Function:     get_current_adc_counts
** Description:  Return the current ADC count average value.  See adc.h for
**               list of channels and descriptions.
** Inputs:       ADC channel number 0-9.  See adc.h for list of the 10 channels.
** Outputs:      U16 value - averaged count for channel x.
*******************************************************************************/
U16  get_current_adc_counts( U8 channel )
{
  U16 avg_val = 0;    // error value is bounds check fails

  if ( channel < ADC_TOTAL_CHANNELS )  // bounds check
  {
    avg_val = adc_vals[channel].ADC_avg;
  }
  return avg_val;

}  // end get_current_adc_counts()

/*******************************************************************************
** Function:     get_stm32_internal_temp
** Description:  The internal temp sensor (channel 16), is used to compute the
**               junction temperature of the STM32 microcontroller.  Since this
**               is specifically for the internal temp, we always use the adc
**               count value for channel 16 to do the computation.
** Inputs:       -none-
** Outputs:      S32 temperature value in degrees C.
*******************************************************************************/
S32  get_stm32_internal_temp( void )
{
  S32 tsensor;  // will contain the temperature in degrees Celsius

  tsensor = (S32)get_current_adc_counts( 8 );  // channel 16 - internal STM32 temp

  /* One formula has the VDD_APPLI/VDD_CALIB factor included, and another does
  ** not.  We'll see if that's needed...   */
//  tsensor = tsensor * VDD_APPLI / VDD_CALIB;
  tsensor = tsensor - (S32) *TEMP30_CAL_ADDR;
  tsensor = tsensor * (S32)( 110 - 30 );
  tsensor = tsensor / (S32)( *TEMP110_CAL_ADDR - *TEMP30_CAL_ADDR );
  tsensor = tsensor + 30;

  return tsensor;

}  // end get_stm32_internal_temp()

/*******************************************************************************
** Function:     adc_config_channel
** Description:  Set up the ADC module in the STM32 micro.
**               Use the channel defines from "stm32f0xx_hal_adc_ex.h".
**               Only config channel when ADC is idle or stopped.
**               Note: All 4 thermistor and 4 voltage monitor channels are
**               continous, starting at 0, ending at 7.  However, when we get
**               to channel = 8, we switch to config the internal tempsensor
**               channel, (which is actually channel #16).  So we need to sub
**               the actual ADC channel number here, as well as for the VrefInt
**               channel (channel #17).
** Inputs:       channel selection - 0 thru 17, enable or disable channel.
** Outputs:      .
*******************************************************************************/
void  adc_config_channel( U32 channel, BOOL enable )
{
  ADC_ChannelConfTypeDef sConfig;

  if ( channel <= ADC_CHANNEL_18 )   // bounds check...
  {
    /* Channel 8 means we need the internal STM32 tempsensor channel. */
    if ( channel == 8 )
    {
      sConfig.Channel = ADC_CHANNEL_TEMPSENSOR;
    }
    /* Channel 9 means we need the internal STM32 voltage reference channel. */
    else if ( channel == 9 )
    {
      sConfig.Channel = ADC_CHANNEL_VREFINT;
    }
    /* Channels 0 thru 7 are used as-is for the internal ADC channel nums. */
    else
    {
      sConfig.Channel = channel;
    }

    if ( ON == enable )
    {
      sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
    }
    else
    {
      sConfig.Rank = ADC_RANK_NONE;
    }
    /* The long conversion time is needed for internal channels (VrefInt and
    ** tempsensor).  But this time should also be OK for the thermistor and
    ** voltage channels. */
    sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
    if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
    {
      _Error_Handler(__FILE__, __LINE__);
    }
  }

}  // end adc_config_channel()

/*******************************************************************************
** Function:     MX_ADC_Init
** Description:  Set up the ADC module in the STM32 micro.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
static void MX_ADC_Init( void )
{

  /* Declare the ADC module instance, and start with a de-init of the module,
  ** in case of a soft-reset/brown-out while the module was previously active. */
  hadc.Instance = ADC1;
  if (HAL_ADC_DeInit(&hadc) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }
  /* Configure the global features of the ADC (Clock, Resolution, Data Alignment
  ** and number of conversion). */
  hadc.Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV4; // ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution            = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode          = DISABLE;  // ADC_SCAN_DIRECTION_FORWARD;  // sequencer disabled, only one channel
  hadc.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait      = DISABLE;
  hadc.Init.LowPowerAutoPowerOff  = DISABLE;
  hadc.Init.ContinuousConvMode    = DISABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv      = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun               = ADC_OVR_DATA_OVERWRITTEN; //ADC_OVR_DATA_PRESERVED;

  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* adc.c **************************************************************** EOF */
