/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    operation.c
**
** Description: This is where the primary TEC heating and cooling operation is
**              handled, as well as control/functions of the various tasks.
**              TEC control and operational control modes (including fans,
**              pwm duty cycle calculations, heat, cool, deadband, etc.).
**              Also, track the various totalizers for power on-time, total
**              TEC on-time, etc.
**
** Version/Author/Date/Description:
** 1   DMA   09/19/2018  Began coding (this module).
** 2   DMA   01/13/2019  Added ROC function and total TEC on time.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "lcd.h"
#include "adc.h"
#include "gpio.h"
#include "pwm.h"
#include "versions.h"
#include "config.h"
#include "eeprom.h"

static  U32  total_power_on_time;
static  U32  total_TEC_on_time;
static  U16  mSec_cnt;

/*******************************************************************************
** Function:     totals_init
** Description:  Initialize the time totalizers.  Reload time related data from
**               the EEPROM, or reset totalizers to 0 (on a "restore" function).
**               Set the initial value for the millisecond counts to 1000, since
**               about a second will pass before we actually start keeping track
**               of the total time elapsed.  Also, add one to the count right at
**               init time to compensate for some of the missed counts due to
**               the 10 minute storage resolution.
** Inputs:
** Outputs:
*******************************************************************************/
void  totals_init( void )
{

  total_power_on_time = get_ee_parameter( EE_TOTAL_TIME, EE_DATA_32 );
  total_power_on_time++;  // compensate (see notes above)
  total_TEC_on_time = get_ee_parameter( EE_TOTAL_TEC, EE_DATA_32 );
  mSec_cnt = 1000;  // see notes above...

}  // end totals_init()

/*******************************************************************************
** Function:     totals_tracker
** Description:  Add to the various time trackers based on the millisecond
**               count value.  The total on-time value is counting minutes.
**               To avoid writing to the EE too often, we are just storing the
**               new totals every X minutes (see code below).  This function
**               should be called on a regular 1 mSec rate, but due to the 10
**               minute store update rate and other programmatic factors, this
**               is just an approximation anyway - hopefully, a close approx!
** Inputs:
** Outputs:
*******************************************************************************/
void  totals_tracker( void )
{
  static  U16  min_cnt = 0;
  static  U32  total_TEC_cnt = 0;
  U32         dummy1;
  heat_cool_t dummy2;
  U8  pwm     = 0;      // used below for TEC pwm duty cycle value

  mSec_cnt++;

  if ( mSec_cnt >= MINUTE_1_CNT )
  {
    ++total_power_on_time;  // total on-time is in minutes...
    ++min_cnt;              // add to minutes count
    mSec_cnt = 0;
  }

  if ( min_cnt > 9 )
  {
    /* 10 minutes has elapsed, Remember, we are saving the accumulated total
    ** to EE every 10 minutes, but the value reflects the total number of
    ** on-time minutes. */
    i2c_ee_write( total_power_on_time, EE_TOTAL_TIME, EE_DATA_32 );
    min_cnt = 0;
  }

  /* If the TEC is on, (duty cycle value > 0), then add to count (in mSecs).
  ** Once we get 5 minutes of TEC count data, update stored EE value. */
  pid_vals( &dummy1, &pwm, &dummy2, GET_PWM_VAL );
  if ( pwm > 0 )
  {
    ++total_TEC_cnt;
    if ( total_TEC_cnt >= MINUTE_5_CNT )
    {
      total_TEC_on_time += 5;  // add the time and save it
      i2c_ee_write( total_TEC_on_time, EE_TOTAL_TEC, EE_DATA_32 );
      total_TEC_cnt = 0;
    }
  }

}  // end totals_tracker()

/*******************************************************************************
** Function:     update_operation_events
** Description:  This function determines operating modes for the TEC and fans.
**               These modes are determined for either Sonendo-type operation
**               (config jumpers=0), or ISC-type operation (config jumpers=1).
**               Also note that all internal calcs for PID and TEC are done in
**               degrees C - the temp units only affect the display and
**               communication in/out values.
** Inputs:       -none-
** Outputs:      -none-
*******************************************************************************/
void  update_operation_events( void )
{
  static U8  pid_update_time = 0;
  F32    sensor_temp;
  F32    sph_temp;
  F32    spl_temp;
  op_ctrl_states_t cms;

  /* Check the conditions that prohibit normal automatic PID and fan control.
  ** The "STOP" mode is sent from the serial command. */
  cms = ctrl_mode_state( NONE, GET_DATA );
  if (( cms == PWR_OFF_MODE ) || ( cms == ERROR_MODE ) || ( cms == STOP_MODE ))
  {
    tec_ctrl( NO_HEAT_NO_COOL );         // sets PWM value = 0
    fan_ctrl( FAN1_CH, FAN_SPEED_OFF );  // outside fan (ISC), only fan (Sonendo)
    if ( board_cfg_get( ) != SONENDO_CONTROL )
    {
      /* ISC power off, error or stop mode - leave inside fan (fan2) at 50%. */
      fan_ctrl( FAN2_CH, FAN_SPEED_LOW );
    }
    return;
  }

  /* If in ISC control, check the auto/manual mode. (Sonendo control is set to
  ** auto mode by default).  ISC - no temperature/sensor display in manual start
  ** mode, or in auto mode after the PWR button is pressed. */
  if (( (U8)get_ee_parameter( EE_START_MODE, EE_DATA_8 ) == MANUAL_MODE ) &&
      ( get_manual_ok_to_start_flag( ) == NO ))
  {
    return;
  }

  /* Temperature comparisons always done in degrees C, regardless of current
  ** temperature units.  Remember, C and F values are always in sync. */
  sph_temp = get_sp_value( SPH_C );
  spl_temp = get_sp_value( SPL_C );
  sensor_temp = get_current_temperature( 0, DEGREES_C );

  /* Call the PID func on a 10mSec frequency.  If we were in STOP mode, and the
  ** command has been sent to return to RUN mode, then reset the PID parameters,
  ** and restart the PI control.  Or comming out of ERROR, into RUN mode.
  ** From deadband, PID control figures out where to go, either HEAT or COOL. */
  if ( pid_update_time++ > 9 )
  {
    if (( ctrl_mode_state( NONE, GET_DATA ) == RUN_MODE )  ||
        ( ctrl_mode_state( NONE, GET_DATA ) == INIT_MODE ))
    {
      ctrl_mode_state( DEADBAND_MODE, SET_DATA );  // OK for Sonendo too
      pid_value_init( RESET_ERROR_SUM );
    }
    pid_update_time = 0;
    pid_calc( sph_temp, spl_temp, sensor_temp );
  }
  rate_of_cooling( sensor_temp, UPDATE_VAL );  // just keep updating roc...

}  // end update_operation_events()

/*******************************************************************************
** Function:     rate_of_cooling
** Description:  Compute the difference in temperature values from one sample
**               to the next.  This will give us a crude estimate on the rate
**               of cooling (or heating), when several samples are taken over a
**               time period.  The sample time for PI(D) calculations is 10mSec,
**               so multiply by 100 to get a degree/sec value.
** Inputs:       F32 - current sensor temp, action to perform
** Outputs:      F32 - value for temperature difference
*******************************************************************************/
F32  rate_of_cooling( F32 sensor_now, action_t act )
{
  static  F32  sensor_previous = 0.0f;    // see notes below...
  static  F32  roc = 0.0f;                // rate of cooling (average value)
  static  F32  roc_samples[10] = {0.0f};  // hold 10 inputs for running average
  static  F32  total_roc = 0.0f;          // total of all input array values
  static  U8   index = 0;                 // array index for averaging
  static  U8   roc_update_time = 99;      // triggers the first reading right away

  if ( act == SETUP_VAL )
  {
    /* This action is called to init the averaging array, so that we start with
    ** a valid temp value, and get to a valid value quicker. */
    for ( index = 0; index < 10; index++ )
    {
      roc_samples[index] = sensor_now;
    }
    index = 0;  // reset the index for the update section...
  }
  else if ( act == UPDATE_VAL )
  {
    /* The first roc calc is garbage, since sensor_previous was init to 0.
    ** Also, any other action other than UPDATE_VAL will just return the
    ** previously calculated roc value. Time/count for a per second value. */
    if ( roc_update_time++ > 100 - 1 )
    {
      /* Subtract oldest value, calculate new value and add it to total. */
      total_roc -= roc_samples[index];
      roc_samples[index] = sensor_now - sensor_previous;
      total_roc += roc_samples[index];
      if ( ++index > 9 )
      {
        index = 0;
      }
      roc = total_roc / 10.0f;  // calc new average ROC

      sensor_previous = sensor_now;
      roc_update_time = 0;
    }
  }
  else
  {
    // no action defined here yet...
  }

  return  roc;

}  // end rate_of_cooling()

/* operation.c ********************************************************** EOF */
