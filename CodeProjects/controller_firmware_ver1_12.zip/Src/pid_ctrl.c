/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    pid_ctrl.c
**
** Description: This module controls the low-level STM32F0 timer modules for
**              TEC PWM output.  These functions directly control the STM32
**              registers and board hardware; logic level drivers for the TEC
**              PWM MOSFETs.
**
** Version/Author/Date/Description:
** 1   DMA   03/06/2018  Began coding.
** 2   DMA   12/20/2018  Created this module to separate the fan and TEC control
**                       code in the original pwm.c module.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#include "stm32f0xx_hal.h"
#include "project.h"
#include "main.h"
#include "pwm.h"
#include "adc.h"
#include "gpio.h"
#include "eeprom.h"
#include "config.h"
#include <math.h>
#include <stdlib.h>

TIM_HandleTypeDef htim2;  // tec pwm drive output

/*******************************************************************************
** PID and setpoint values structs.
*******************************************************************************/
static pid_values_t     pid;
static pid_misc_t       pid_2;
static setpoint_t       sp;

/*******************************************************************************
** Function:     tec_drivers_init
** Description:  Set up the initial conditions for the TEC control outputs and
**               control logic.  Logic enable signal (HB_LOG_nEN_Pin) is no
**               longer used in the H-bridge circuit, so just leave high.
**               The h-bridge direction pin (pol_rvrs - polarity reverse) will
**               switch polarity (high=heat, low=cool).  Refer to the 221-0144
**               schematic for circuit details and the logic truth-table for
**               controlling the h-bridge and preventing shoot-thru or illegal
**               states.  Once the logic is set for the H-bridge, then set the
**               PWM duty cycle value.
** Inputs:
** Outputs:
*******************************************************************************/
void  tec_drivers_init( void )
{
  /* Make sure h-bridge logic circuit starts off disabled, before the TEC PWM
  ** module is initialized. Also, since rev 2.0 hardware, the HB_LOG_nEN_Pin
  ** is no longer used.  Set this output pin high for now. */
  HAL_GPIO_WritePin( HB_LOG_nEN_GPIO_Port,  HB_LOG_nEN_Pin,  GPIO_PIN_SET );

  MX_TIM2_Init();               // TEC pwm STM32 internal module init
  tec_ctrl( NO_HEAT_NO_COOL );  // turn off the PWM output

}  // end tec_drivers_init()

/*******************************************************************************
** Function:     tec_ctrl
** Description:  This function starts or stops the TEC PWM output on channel 3,
**               timer instance 2.  Also sets the logic for heating and cooling.
**               Remember that the logic enable pin output on the STM32F0 is no
**               longer used - see schematic 221-0144 for truth table.
** Inputs:       heat_cool_t - HEAT, COOL or neither (off)
** Outputs:
*******************************************************************************/
void  tec_ctrl( heat_cool_t hc )
{
  static U8    on_now = NO;
          U32  dummy1;
          U8   pwm;
  heat_cool_t  dummy3;

  /* If we are in the error state, make sure TEC is off. */
  if (( hc == NO_HEAT_NO_COOL ) ||
      ( ctrl_mode_state( NONE, GET_DATA ) == ERROR_MODE ))
  {
    /* Stop the TEC PWM on channel 3. */
    if ( HAL_TIM_PWM_Stop( &htim2, TIM_CHANNEL_3 ) != HAL_OK )
    {
      Error_Handler();
    }

    /* Set the h-bridge logic to turn off the TEC drivers.  (The heat/cool
    ** parameter is a don't care here). */
    HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_RESET );
    HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_RESET );

    /* Turn off both the BLUE and RED LEDs.  Don't turn off the RED LED if we
    ** are in an error mode. */
    if ( ctrl_mode_state( NONE, GET_DATA ) != ERROR_MODE )
    {
      led_setup( MEMB_RED, LED_OFF, 0, 0, 0 );
    }
    led_setup( MEMB_BLUE, LED_OFF, 0, 0, 0 );

    pwm = 0;
    pid_vals( &dummy1, &pwm, &dummy3, SET_PWM_VAL );

    on_now = NO;
  }
  else
  {
    if ( on_now == NO )
    {
      on_now = YES;  // must issue NO_HEAT_NO_COOL command to reset this flag
      /* Start the TEC PWM on channel 3. */
      if ( HAL_TIM_PWM_Start( &htim2, TIM_CHANNEL_3 ) != HAL_OK )
      {
        Error_Handler();
      }

      if ( hc == HEAT )
      {
        /* Set MOSFET drive logic for heating. */
        HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_SET );
        HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_SET );
        led_setup( MEMB_RED, LED_CONTINUOUS, 0, 0, 0 );
      }
      else if ( hc == COOL )
      {
        /* Set MOSFET drive logic for cooling. */
        HAL_GPIO_WritePin( HB_POL_RVRS_GPIO_Port, HB_POL_RVRS_Pin, GPIO_PIN_RESET );
        HAL_GPIO_WritePin( HB_LOG_LVL_GPIO_Port,  HB_LOG_LVL_Pin,  GPIO_PIN_SET );
        led_setup( MEMB_BLUE, LED_CONTINUOUS, 0, 0, 0 );
      }
      else
      {
        // no change...
      }
    }
  }
}  // end tec_ctrl()

/*******************************************************************************
** Function:     set_tec_duty_cycle
** Description:  Sets the PWM drive output to a duty cycle value 0 to 100%.
** Inputs:       pwm drive value, 0-100, (U8).
** Outputs:
*******************************************************************************/
void  set_tec_duty_cycle( U8 pwm_drive )
{
  U32  tec_duty_pulse_value;
  U32  dummy1;
  U8   pwm;
  heat_cool_t  dummy3;
  TIM_OC_InitTypeDef sConfigOC;

  /* If the PWM is already set to the value we want, we can skip this. */
  pid_vals( &dummy1, &pwm, &dummy3, GET_PWM_VAL );
  if ( pwm_drive != pwm )
  {
    tec_ctrl( NO_HEAT_NO_COOL );  // set TEC drive OFF before changing duty cycle

    pwm = pwm_drive;
    pid_vals( &dummy1, &pwm, &dummy3, SET_PWM_VAL );

    /* Limit check is done in the "scale_value" function. */
    tec_duty_pulse_value = (U32)scale_value( pwm_drive );

    /* The TEC PWM drive, Port B, pin 10 (schematic name: TEC_PWM).  Configured
    ** on timer2, TIM_CHANNEL_3.  Only need to modify .pulse for duty cycle -
    ** leave other items in the sConfigOC struct at default values. */
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = tec_duty_pulse_value;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;

    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
    {
      _Error_Handler(__FILE__, __LINE__);
    }
      /* Now reset the TEC control mode after the duty cycle update. */
    if ( ctrl_mode_state( NONE, GET_DATA ) == COOL_MODE )
    {
      tec_ctrl( COOL );
    }
    else if ( ctrl_mode_state( NONE, GET_DATA ) == HEAT_MODE )
    {
      tec_ctrl( HEAT );
    }
    else
    {
      // TEC is already off, leave it off
    }

  }
}  // end set_tec_duty_cycle()

/*******************************************************************************
** Function:     pid_calc
** Description:  This function must be called on a regular, periodic basis to
**               elliminate the need for d/dt calculations.  Also, for this
**               system, we have no D gain term, so assume D gain term = 0.
** Inputs:       F32 - sph, spl and sensor temperature.
** Outputs:      .
*******************************************************************************/
void  pid_calc( F32 sph, F32 spl, F32 sensor )
{
  U8   pid_out;

  if ( board_cfg_get( ) == SONENDO_CONTROL )
  {
    /* Sonendo PID control is the traditional single-setpoint, maintain
    ** temperature type of control.  Positive error in cooling region, negative
    ** error in heating region. */
    pid_out = adjust_tec_pwm( sensor - sph );  // error term
    set_tec_duty_cycle( pid_out );
    fan_sonendo_ctrl( pid_out );
  }
  else
  {
    /* ISC PID control uses the upper/lower setpoints and deadband. */
    pid_out = deadband_mode( sph, spl, sensor );
    set_tec_duty_cycle( pid_out );
    fan_isc_ctrl( sph, spl, sensor );
  }

}  // end pid_calc()

/*******************************************************************************
** Function:     adjust_tec_pwm
** Description:  Calculate the PWM output based on the error value.
**               Remember, positive error in cool mode, negative error in heat
**               mode. The first section of this function determines the mode,
**               (heat or cool).  Then if in the proportional band, (ouside the
**               SPL value), just use the Kp gain and error for the output.
**               Don't add to Ki in this region.  For single setpoint apps,
**               i.e., Sonendo, SPH is setpoint, SPL is prop band value. Inside
**               of the prop band limits, calculate the PI value normally and
**               normalize this value to 0-100 for duty cycle to the TEC.
** Inputs:       F32 error term.
** Outputs:      pid scaled value, duty cycle, 0-100.
*******************************************************************************/
U8  adjust_tec_pwm( F32 error )
{
  static F32  Pgain = 0.0f;      // value set after the first time thru...
  static F32  Igain = 0.0f;      // value set after the first time thru...
  F32  ftemp_Kp;
  F32  ftemp_Ki;
  F32  ftemp_KpKi;
  F32  spl;                      // spl is used for proportional band here
  U32  dummy1;
  U8   dummy2;
  U8   pid_pwm;
  heat_cool_t  hc;

  ftemp_Ki = pid_terms( 0, KI_VAL, GET_DATA );  // recall previous values...
  ftemp_KpKi = pid_terms( 0, KPKI_VAL, GET_DATA );

  /* Set the initial heat/cool mode.  Should always be in either heat or cool
  ** after this, unless reset or serial command to stop. */
  pid_vals( &dummy1, &dummy2, &hc, GET_HC_MODE );
  if ( hc == NO_HEAT_NO_COOL )
  {
    if ( error > 0.0f )
    {
      hc = COOL;  // first time setting to start PID process
      pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
      ctrl_mode_state( COOL_MODE, SET_DATA );
      tec_ctrl( COOL );
      Pgain = pid_terms( 0, PGAIN_COOL, GET_DATA );
      Igain = pid_terms( 0, IGAIN_COOL, GET_DATA );
    }
    else if ( error < 0.0f )
    {
      hc = HEAT;  // first time setting to start PID process
      pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
      ctrl_mode_state( HEAT_MODE, SET_DATA );
      tec_ctrl( HEAT );
      Pgain = pid_terms( 0, PGAIN_HEAT, GET_DATA );
      Igain = pid_terms( 0, IGAIN_HEAT, GET_DATA );
    }
    else
    {
      // don't change modes till we get off dead center...
    }
  }
  else
  {
    if ( hc == HEAT )
    {
      /* If we were heating, and the KI term goes slightly positive, it's now
      ** time to transition to cooling. */
      if ( ftemp_Ki > 0.01f )
      {
        ctrl_mode_state( COOL_MODE, SET_DATA );
        tec_ctrl( COOL );
        hc = COOL;
        pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
        Pgain = pid_terms( 0, PGAIN_COOL, GET_DATA );
        Igain = pid_terms( 0, IGAIN_COOL, GET_DATA );
        ftemp_Ki = 0.0f;
      }
    }
    else if ( hc == COOL )
    {
      /* If we were cooling, and the KI term goes slightly negative, it's now
      ** time to transition to heating. */
      if ( ftemp_Ki < -0.01f )
      {
        ctrl_mode_state( HEAT_MODE, SET_DATA );
        tec_ctrl( HEAT );
        hc = HEAT;
        pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
        Pgain = pid_terms( 0, PGAIN_HEAT, GET_DATA );
        Igain = pid_terms( 0, IGAIN_HEAT, GET_DATA );
        ftemp_Ki = 0.0f;
      }
    }
    else
    {
      // shouldn't get here...
    }
  }
  /* The main PI calculations. Limit check the KI term. */
  ftemp_Kp  = Pgain * error;
  ftemp_Ki += ( Igain * error * 0.01f );  // loop time 10mSec
  ftemp_Ki  = limit_check( ftemp_Ki, ITERM_MAX, ITERM_MIN );

  /* If still far away from setpoint, modify the KI term so that we don't
  ** saturate too early; otherwise, the integrator won't unwind quickly enough
  ** to prevent large over/undershoot for fast slope (or large KP term)
  ** temperature changes.  Tried not to get too clever with various term
  ** manipulations here, since there's *always* a corner case!
  ** Thermodynamics is a cruel mistress!
  ** First, get SPL value for the prop band.  0.0 disables the prop band. */
  spl = get_sp_value( SPL_C );
  if (( fabs( spl ) > FLOAT_EPSILON ) && ( fabs( error ) > spl ))
  {
    ftemp_Ki = ftemp_Ki * 0.033f;  // value determined by M. Hodge calculations
  }

  /* Calc the PID value (remember that D term = 0).
  ** Use absolute value and bounds check the result. */
  ftemp_KpKi = fabs( ftemp_Kp + ftemp_Ki );
  pid_pwm = (U8)limit_check( ftemp_KpKi, PID_OUT_MAX, PID_OUT_MIN );

  /* Save the terms for next time. Note: the Kp term is re-calc'd every time. */
  pid_terms( ftemp_Ki, KI_VAL, SET_DATA );
  pid_terms( ftemp_KpKi, KPKI_VAL, SET_DATA );

  /* See description for this function.  Protects from the dreaded corner cases
  ** that we tried to avoid! Contributing factors include; prop band and Kp, Ki
  ** tuning not right for the load, large deltas from ambient resulting in fast
  ** slopes (ROC) and Ki unwind problems, etc. */
  if ( tec_pwm_runaway_check( error ) == YES )
  {
    pid_pwm = 0;
  }

  return  pid_pwm;

}  // end adjust_tec_pwm()

/*******************************************************************************
** Function:     tec_pwm_runaway_check
** Description:  In certain cases, a change in setpoint can cause a quick temp
**               change on the output, and the new setpoint value is exceeded
**               before the Ki term gets a chance to "unwind".  This can cause
**               a large over/undershoot, and in some cases, the PI algorithm
**               gets confused and runs-away, uncontrolled.  The PI gain values
**               and proportional band can contribute to this condition.  And if
**               the current temp and new setpoint are far from ambient, the Ki
**               is large, gets reset to 0 (on new setpoint), and the thermal
**               momentum carries the ouput past the new setpoint, without ever
**               unwinding the Ki term.
**               If we are still X degrees away from setpoint, and still in the
**               wrong heat/cool mode, stop the TEC and reset the PI controller.
** Inputs:       F32 error term.
** Outputs:      U8 YES (had to reset and stop TEC), or NO (no action taken).
*******************************************************************************/
U8  tec_pwm_runaway_check( F32 error_temp )
{
  U32 dummy1;
  U8  dummy2;
  U8  rtn_val = NO;
  heat_cool_t hc;

  /* Remember:  +error in the cooling range, -error in the heating range.
  ** If heating and +4.5 degrees away from setpoint, then stop and reset.
  ** We should be cooling!  *OR*  If cooling and -4.5 degrees away from
  ** setpoint, then stop and reset.  We should be heating!  In other words,
  ** if you've overshot by this much and still in the wrong mode, stop and
  ** turn around! */
  pid_vals( &dummy1, &dummy2, &hc, GET_HC_MODE );
  if ((( hc == HEAT ) && ( error_temp > 4.5f ))  ||
      (( hc == COOL ) && ( error_temp < -4.5f )))
  {
    pid_value_init( RESET_ERROR_SUM );  // this will also stop the TEC
    rtn_val = YES;
  }

  return  rtn_val;

}  // end tec_pwm_runaway_check()

/*******************************************************************************
** Function:     deadband_mode
** Description:  Unit starts out in DEADBAND_MODE for ISC operation, or two
**               setpoint operational mode. From here, the function determines
**               if we need to HEAT, COOL, or stay in DEADBAND_MODE.  The
**               deadband is the temperature region between the high (SPH) and
**               low (SPL) setpoints.  There is no proportional band. The TEC
**               is turned on after crossing the high or low setpoint threshold.
**               Remember - can't move back into the deadband from heat or cool
**               until the Ki term is unwound. This is checked in the
**               adjust_tec_pwm_deadband_mode() func.
** Inputs:       F32 sph and spl.
** Outputs:      pid scaled value, duty cycle, 0-100.
*******************************************************************************/
U8  deadband_mode( F32 sph, F32 spl, F32 sensor )
{
  F32  sph_temp;
  F32  spl_temp;
  F32  sensor_temp;
  F32  error_term;
  op_ctrl_states_t  opm;
  U8   rtn_val = 0;
  U32  dummy1;
  U8   dummy2;
  heat_cool_t hc;

  sph_temp = get_sp_value( SPH_C );
  spl_temp = get_sp_value( SPL_C );

  sensor_temp = get_current_temperature( 0, DEGREES_C );

  opm = ctrl_mode_state( NONE, GET_DATA );

  pid_vals( &dummy1, &dummy2, &hc, GET_HC_MODE );

  if (( sensor_temp > sph_temp ) && ( opm == DEADBAND_MODE ))
  {
    /* We've moved from the deadband to the upper, cooling region. */
    error_term = sensor_temp - sph_temp;  // + err in cool region
    ctrl_mode_state( COOL_MODE, SET_DATA );
    pid_value_init( RESET_ERROR_SUM );
    tec_ctrl( COOL );
    hc = COOL;
    pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
  }
  else if (( sensor_temp < spl_temp ) && ( opm == DEADBAND_MODE ))
  {
    /* We've moved from the deadband to the lower, heating region. */
    error_term = sensor_temp - spl_temp;  // - err in heat region
    ctrl_mode_state( HEAT_MODE, SET_DATA );
    pid_value_init( RESET_ERROR_SUM );
    tec_ctrl( HEAT );
    hc = HEAT;
    pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
  }
  else if (( opm != DEADBAND_MODE ) && ( hc == COOL ))
  {
    error_term = sensor_temp - sph_temp;  // + err in cool region
    rtn_val = adjust_tec_pwm_deadband_mode( error_term );
  }
  else if (( opm != DEADBAND_MODE ) && ( hc == HEAT ))
  {
    error_term = sensor_temp - spl_temp;  // - err in heat region
    rtn_val = adjust_tec_pwm_deadband_mode( error_term );
  }
  else if (( opm != DEADBAND_MODE ) && ( hc == NO_HEAT_NO_COOL ))
  {
    /* Shouldn't happen in normal operation, but may have gotten here due to SP
    ** change via comm, so make sure PID parms are in-sync. */
    ctrl_mode_state( DEADBAND_MODE, SET_DATA );
    rtn_val = adjust_tec_pwm_deadband_mode( 0.0f );
  }
  else
  {
    // leave rtn_val = 0 here...
  }

  return  rtn_val;

}  // end deadband_mode()

/*******************************************************************************
** Function:     adjust_tec_pwm_deadband_mode
** Description:  Calculate the PWM output based on the error value, and upper &
**               lower setpoints.  This method includes a deadband between the
**               high and low setpoints.  There is no proportional band.
**               Shut TEC off after Ki has unwound - this indicates we have
**               crossed the high or low setpoint threshold, and are in the
**               deadband zone.  The TEC is turned on after crossing the high
**               or low setpoint threshold from the deadband.
** Inputs:       F32 error term.
** Outputs:      pid scaled value, duty cycle, 0-100.
*******************************************************************************/
U8  adjust_tec_pwm_deadband_mode( F32 error )
{
  F32  Pgain = 0.0f;  // Pgain and Igain set to proper values below...
  F32  Igain = 0.0f;
  F32  ftemp_Kp;
  F32  ftemp_Ki;
  F32  ftemp_KpKi;
  U32  dummy1;
  U8   dummy2;
  U8   pid_pwm;
  heat_cool_t  hc;

  ftemp_Ki = pid_terms( 0, KI_VAL, GET_DATA );  // recall previous values...
  ftemp_KpKi = pid_terms( 0, KPKI_VAL, GET_DATA );

  pid_vals( &dummy1, &dummy2, &hc, GET_HC_MODE );
  if ( hc == HEAT )
  {
   /* Load the heating PID gain terms. */
    Pgain = pid_terms( 0, PGAIN_HEAT, GET_DATA );
    Igain = pid_terms( 0, IGAIN_HEAT, GET_DATA );
  }
  else if ( hc == COOL )
  {
    /* Load the cooling PID gain terms. */
    Pgain = pid_terms( 0, PGAIN_COOL, GET_DATA );
    Igain = pid_terms( 0, IGAIN_COOL, GET_DATA );
  }

  /* The main PI calculations. Limit check the KI term. */
  ftemp_Kp  = Pgain * error;
  ftemp_Ki += ( Igain * error * 0.01f );  // loop time 10mSec
  ftemp_Ki  = limit_check( ftemp_Ki, ITERM_MAX, ITERM_MIN );

  /* Calc the PID value (remember that D term = 0).
  ** Use absolute value and bounds check the result. */
  ftemp_KpKi = fabs( ftemp_Kp + ftemp_Ki );
  pid_pwm = (U8)limit_check( ftemp_KpKi, PID_OUT_MAX, PID_OUT_MIN );

  /* Save the terms for next time. Note: the Kp term is re-calc'd every time. */
  pid_terms( ftemp_Ki, KI_VAL, SET_DATA );
  pid_terms( ftemp_KpKi, KPKI_VAL, SET_DATA );

  /* If the KI term goes slightly negative in the cooling region, or it goes
  ** slightly positive in the heating region, it's now time to transition back
  ** to deadband. */
  if ((( ftemp_Ki > 0.1f ) && ( hc == HEAT ))   ||
      (( ftemp_Ki < -0.1f ) && ( hc == COOL )))
  {
    hc = NO_HEAT_NO_COOL;
    pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
    ctrl_mode_state( DEADBAND_MODE, SET_DATA );
    pid_pwm = 0;
  }

  return  pid_pwm;

}  // end adjust_tec_pwm_deadband_mode()

/*******************************************************************************
** Function:     pid_value_init
** Description:  Initialize the PID value struct with the saved data.
**               NOTE - this function assumes that the EE memory has valid data
**               for the PID floating point values.  If not valid, then load
**               the default value.  Floats are stored little-endian in the EE
**               for consistancy - the STM32F0 internal memory is little-endian.
** Inputs:       U8 - action, reset pid calc values, or init pid parms.
** Outputs:      .
*******************************************************************************/
void  pid_value_init( U8 x )
{
  F32  val;
  F32  dval;  // default value
  U32  dummy1;
  U8   dummy2;
  heat_cool_t hc;

  /* Reset the accumulated error terms and mode in the PID calculations. */
  if (( x == RESET_ERROR_SUM ) || ( x == INIT_PID_VALS ))
  {
    pid_terms( 0.0f, KI_VAL, SET_DATA );
    pid_terms( 0.0f, KPKI_VAL, SET_DATA );
    hc = NO_HEAT_NO_COOL;
    pid_vals( &dummy1, &dummy2, &hc, SET_HC_MODE );
  }

  /* Init the PID gain values for both cool and heat. */
  if ( x == INIT_PID_VALS )
  {
    /* Load the P GAIN value for cooling. */
    dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ?
      PGAIN_COOL_SEN_DEFAULT : PGAIN_COOL_ISC_DEFAULT;
    val = get_real_data( EE_PGAIN_COOL, dval );
    pid_terms( val, PGAIN_COOL, SET_DATA );

    /* Load the I GAIN value for cooling. */
    dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ?
      IGAIN_COOL_SEN_DEFAULT : IGAIN_COOL_ISC_DEFAULT;
    val = get_real_data( EE_IGAIN_COOL, dval );
    pid_terms( val, IGAIN_COOL, SET_DATA );

    /* Load the D GAIN value for cooling. */
    pid_terms( 0.0f, DGAIN_COOL, SET_DATA );  // D gain = 0 for now

    /* Load the P GAIN value for heating. */
    dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ?
      PGAIN_HEAT_SEN_DEFAULT : PGAIN_HEAT_ISC_DEFAULT;
    val = get_real_data( EE_PGAIN_HEAT, dval );
    pid_terms( val, PGAIN_HEAT, SET_DATA );

    /* Load the I GAIN value for heating. */
    dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ?
      IGAIN_HEAT_SEN_DEFAULT : IGAIN_HEAT_ISC_DEFAULT;
    val = get_real_data( EE_IGAIN_HEAT, dval );
    pid_terms( val, IGAIN_HEAT, SET_DATA );

    /* Load the D GAIN value for heating. */
    pid_terms( 0.0f, DGAIN_HEAT, SET_DATA );  // D gain = 0 for now
  }

  set_tec_duty_cycle( 0 );           // TEC duty/pwm drive = 0 initially

}  // end pid_value_init()

/*******************************************************************************
** Function:     pid_terms
** Description:  Returns the current value from the PID values struct.
** Description:  Gets or sets the PID struct terms (P gain, I gain and
**               accumlated sums for both heat and cool). A GET doesn't use the
**               real value sent with the function paramters, and just returns
**               the current value. For SET, the PID value is updated, and the
**               function returns 0.
** Inputs:       real data value, pid_value_id_t, get_set_access_t
** Outputs:      pid_values_t - F32 value.
*******************************************************************************/
F32  pid_terms( F32 val, pid_value_id_t id, get_set_access_t gs )
{
  F32 rtn_val = 0;

  if ( gs == SET_DATA )
  {
    switch ( id )
    {
      case PGAIN_COOL:   pid.p_gain_cool = val;   break;
      case IGAIN_COOL:   pid.i_gain_cool = val;   break;
      case DGAIN_COOL:   pid.d_gain_cool = val;   break;
      case PGAIN_HEAT:   pid.p_gain_heat = val;   break;
      case IGAIN_HEAT:   pid.i_gain_heat = val;   break;
      case DGAIN_HEAT:   pid.d_gain_heat = val;   break;
      case KI_VAL:       pid.KI_term     = val;   break;
      case KPKI_VAL:     pid.KP_KI       = val;   break;
      default:                                    break;
    }  // end switch
  }
  else if ( gs == GET_DATA )
  {
    switch ( id )
    {
      case PGAIN_COOL:   rtn_val = pid.p_gain_cool;   break;
      case IGAIN_COOL:   rtn_val = pid.i_gain_cool;   break;
      case DGAIN_COOL:   rtn_val = pid.d_gain_cool;   break;
      case PGAIN_HEAT:   rtn_val = pid.p_gain_heat;   break;
      case IGAIN_HEAT:   rtn_val = pid.i_gain_heat;   break;
      case DGAIN_HEAT:   rtn_val = pid.d_gain_heat;   break;
      case KI_VAL:       rtn_val = pid.KI_term;       break;
      case KPKI_VAL:     rtn_val = pid.KP_KI;         break;
      default:           rtn_val = 0.0f;              break;
    }  // end switch
  }
  else
  {
  }

  return  rtn_val;

}  // end pid_terms()

/*******************************************************************************
** Function:     sp_value_init
** Description:  Initialize the setpoint value struct with the saved data.
**               NOTE - this function assumes that the EE memory has valid data
**               for the floating point values.  If data not valid, then load
**               the default value.  Floats are stored little-endian in the EE
**               for consistancy - the STM32F0 internal memory is little-endian.
** Inputs:       .
** Outputs:      .
*******************************************************************************/
void    sp_value_init( void )
{
  F32  dval;  // holds default value

  /* Load the setpoint high value. */
  dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ? SONENDO_SETPOINT : ISC_SPH;
  set_sp_value( get_real_data( EE_SPH, dval ), SPH_C );  // sets both C and F

  /* Load the setpoint low value.
  ** For Sonendo, the low setpoint is used for the proportional band. */
  dval = ( board_cfg_get( ) == SONENDO_CONTROL ) ? SONENDO_PROP_BAND : ISC_SPL;
  set_sp_value( get_real_data( EE_SPL, dval ), SPL_C );  // sets both C and F

}  // end sp_value_init()

/*******************************************************************************
** Function:     set_sp_value
** Description:  Sets the value for high or low setpoint. To keep everything in
**               sync, always update the F value along with the C value, and
**               vice-versa.
**               SPECIAL NOTE: If in Sonendo mode, the SPL value is the
**               proportional band, and *not* an absolute temperature value.
**               Therefor, we need to multiply by 5/9 to go from F to C, and
**               multiply by 9/5 to go from C to F.
**               JUST THIS RATIO, ONLY FOR SPL,AND ONLY IN SONENDO MODE.
** Inputs:       sp_id_t - setpoint struct identifier, F32 - temperature value.
** Outputs:      .
*******************************************************************************/
void  set_sp_value( F32 val, sp_id_t id )
{
  switch ( id )
  {
    case SPH_C:
      sp.high_c = val;
      sp.high_f = temperature_convert( sp.high_c, C_to_F );  // degrees F
      break;

    case SPH_F:
      sp.high_f = val;
      sp.high_c = temperature_convert( sp.high_f, F_to_C );  // degrees C
      break;

    case SPL_C:
      sp.low_c = val;
      if ( board_cfg_get( ) == SONENDO_CONTROL )
      {
        sp.low_f = sp.low_c * ( 9.0f / 5.0f );  // see notes above... (C to F)
      }
      else
      {
        sp.low_f = temperature_convert( sp.low_c, C_to_F );  // degrees F
      }
      break;

    case SPL_F:
      sp.low_f = val;
      if ( board_cfg_get( ) == SONENDO_CONTROL )
      {
        sp.low_c = sp.low_f * ( 5.0f / 9.0f );  // see notes above... (F to C)
      }
      else
      {
        sp.low_c = temperature_convert( sp.low_f, F_to_C );  // degrees C
      }
      break;

    default:
      break;

  }  // end switch

}  // end set_sp_value()

/*******************************************************************************
** Function:     get_sp_value
** Description:  Returns the current value from the setpoint values struct.
** Inputs:       sp_id_t - setpoint struct identifier.
** Outputs:      F32 - setpoint value.
*******************************************************************************/
F32  get_sp_value( sp_id_t id )
{
  F32 rtn_val;

  switch ( id )
  {
    case SPH_C:   rtn_val = sp.high_c;   break;
    case SPH_F:   rtn_val = sp.high_f;   break;
    case SPL_C:   rtn_val = sp.low_c;    break;
    case SPL_F:   rtn_val = sp.low_f;    break;
    default:      rtn_val = 0.0f;        break;
  }  // end switch

  return  rtn_val;

}  // end get_sp_value()

/*******************************************************************************
** Function:     pid_vals
** Description:  Gets or sets the following data associated with PID functions:
**               1. timer counts, used to limit transitions from heat/cool.
**               2. pwm, used to control TEC duty cycle (0-100).
**               3. heat/cool mode, controls TEC heating, cooling or none.
** Inputs:       Can be any of the above, (using pointers).
** Outputs:      Depends on ID value.
*******************************************************************************/
void  pid_vals( U32 *t_cnt, U8 *pwm, heat_cool_t *hc, pid_misc_id_t id )
{

  switch ( id )
  {
    case GET_PID_TIMER:  *t_cnt = pid_2.timer_cnt;  break;
    case GET_HC_MODE:    *hc    = pid_2.in_mode;    break;
    case GET_PWM_VAL:    *pwm   = pid_2.pwm_val;    break;
    case SET_PID_TIMER:  pid_2.timer_cnt = *t_cnt;  break;
    case SET_HC_MODE:    pid_2.in_mode   = *hc;     break;
    case SET_PWM_VAL:    pid_2.pwm_val   = *pwm;    break;
    default:                                        break;
  }  // end switch

}  // end pid_vals()

/*******************************************************************************
** Function:     get_real_data
** Description:  Gets the data bytes from EE memory and converts to a F32 value,
**               using the IEEE-754 standard bytes-to-float conversion.
**               If the EE contains invalid data bytes, then the default value
**               is returned.
** Inputs:       U16 - ee storage location, F32 - default value.
** Outputs:      F32 - real data.
*******************************************************************************/
F32  get_real_data( U16 ee_parm_adrs, F32 default_val )
{
  U8   fp_bytes[4];  // floating point data byte array
  F32  rtn_val;

  /* Get the 4 bytes that make up the IEEE-754 floating point value. */
  fp_bytes[0] = (U8)get_ee_parameter( ee_parm_adrs,     EE_DATA_8 );
  fp_bytes[1] = (U8)get_ee_parameter( ee_parm_adrs + 1, EE_DATA_8 );
  fp_bytes[2] = (U8)get_ee_parameter( ee_parm_adrs + 2, EE_DATA_8 );
  fp_bytes[3] = (U8)get_ee_parameter( ee_parm_adrs + 3, EE_DATA_8 );

  rtn_val = IEEE_754_bytes_to_float( fp_bytes );
  /* Check that the conversion did not produce a NaN value. */
  if ( isnan( rtn_val ))
  {
    rtn_val = default_val;  // use the default value if float is NaN
  }

  return  rtn_val;

}  // end get_real_data()

/*******************************************************************************
** Function:     set_real_data
** Description:  Sets the data bytes from EE memory and converts to a F32 value,
**               using the IEEE-754 standard bytes-to-float conversion.
**               If the EE contains invalid data bytes, then the default value
**               is returned.
** Inputs:       F32 - real value to save in EEPROM, U16 - EE address.
** Outputs:      .
*******************************************************************************/
void  set_real_data( F32 real_val, U16 ee_address )
{
  U8  * fp_bytes;  // pointer to array for return data, holds 4 fp data bytes

  fp_bytes = IEEE_754_float_to_bytes( real_val );
  i2c_ee_write( (U32)( fp_bytes[0] ), ee_address,     EE_DATA_8 );
  i2c_ee_write( (U32)( fp_bytes[1] ), ee_address + 1, EE_DATA_8 );
  i2c_ee_write( (U32)( fp_bytes[2] ), ee_address + 2, EE_DATA_8 );
  i2c_ee_write( (U32)( fp_bytes[3] ), ee_address + 3, EE_DATA_8 );

}  // end set_real_data()

/*******************************************************************************
** Function:     MX_TIM2_Init
** Description:  Initialize the timer used for the TEC - PWM drive output.
**               This is the only device using this timer instance.
**               TIM_CHANNEL_3 is used for PWM generation.
** Inputs:       none.
** Outputs:      none.
*******************************************************************************/
void MX_TIM2_Init( void )
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = preScale5_6KHz;  // TEC PWM freq (for now...)
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 665;                // period value
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  /* This is the TEC PWM drive, Port B, pin 10 (schematic name: TEC_PWM). */
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = (uint32_t)( 665 * 1.0 );  // start with 100% duty cycle
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim2);

}  // end MX_TIM2_Init()

/* pid_ctrl.c *********************************************************** EOF */
