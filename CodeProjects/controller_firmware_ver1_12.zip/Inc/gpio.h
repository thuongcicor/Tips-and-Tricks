/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    gpio.h
**
** Description: Contain all gpio pin defines and a list of all pins associated
**              with each port on the micro.  Note that the schematic node names
**              are used for the gpio defines.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   12/20/2018  Added defines for rev. 3 hardware - includes new audio
**           beeper pin, and new RS-232 chip pins.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef _gpio_h_
#define _gpio_h_

/* Values used for array offsets, (LED struct and ID values). */
typedef enum led_defines_for_all_known_leds_to_date
{
  ONB_RED,     // (LED3_CTRL_Pin) - on-board RED
  ONB_WHITE,   // (LED4_CTRL_Pin) - on-board WHITE
  MEMB_GREEN,  // (LED2_CTRL_Pin) - membrane switch panel GREEN (PWR)
  MEMB_BLUE,   // (LED1_CTRL_Pin) - membrane switch panel BLUE (COOL)
  MEMB_RED,    // (LED0_CTRL_Pin) - membrane switch panel RED (HEAT)
  ALL_LEDS     // used in control functions for operations on all LEDs
}  led_id_t;

/* The build configuration will define the number of LEDs used. */
#ifdef  BOARD_221_0144_ONLY
#define  NUM_LEDS  2    // select if only the on-board LEDs are used
#else
#define  NUM_LEDS  5    // select if all LEDs are used (membrane + on-board)
#endif

/* LED define shortcuts for easier programming. */
#define  LED_R1_ON    (HAL_GPIO_WritePin( LED3_CTRL_GPIO_Port, LED3_CTRL_Pin, GPIO_PIN_SET ))
#define  LED_R1_OFF   (HAL_GPIO_WritePin( LED3_CTRL_GPIO_Port, LED3_CTRL_Pin, GPIO_PIN_RESET ))
#define  LED_W_ON     (HAL_GPIO_WritePin( LED4_CTRL_GPIO_Port, LED4_CTRL_Pin, GPIO_PIN_SET ))
#define  LED_W_OFF    (HAL_GPIO_WritePin( LED4_CTRL_GPIO_Port, LED4_CTRL_Pin, GPIO_PIN_RESET ))
#define  LED_G_ON     (HAL_GPIO_WritePin( LED2_CTRL_GPIO_Port, LED2_CTRL_Pin, GPIO_PIN_SET ))
#define  LED_G_OFF    (HAL_GPIO_WritePin( LED2_CTRL_GPIO_Port, LED2_CTRL_Pin, GPIO_PIN_RESET ))
#define  LED_B_ON     (HAL_GPIO_WritePin( LED1_CTRL_GPIO_Port, LED1_CTRL_Pin, GPIO_PIN_SET ))
#define  LED_B_OFF    (HAL_GPIO_WritePin( LED1_CTRL_GPIO_Port, LED1_CTRL_Pin, GPIO_PIN_RESET ))
#define  LED_R2_ON    (HAL_GPIO_WritePin( LED0_CTRL_GPIO_Port, LED0_CTRL_Pin, GPIO_PIN_SET ))
#define  LED_R2_OFF   (HAL_GPIO_WritePin( LED0_CTRL_GPIO_Port, LED0_CTRL_Pin, GPIO_PIN_RESET ))

/*
** For reference - list of all STM32F071xx pins associated with PORT A:
**
PA0  pin 23	input, analog, thermistor 0
PA1  pin 24	input, analog, thermistor 1
PA2  pin 25	input, analog, thermistor 2
PA3  pin 26	input, analog, thermistor 3
PA4  pin 29	input, analog, 24VDC monitor
PA5  pin 30	input, analog, 12VDC monitor
PA6  pin 31	input, analog, 3.3VDC monitor
PA7  pin 32	input, analog, 3.0VDC monitor
PA8  pin 67	not used
PA9  pin 68	alternate function, USART1_TX
PA10 pin 69	alternate function, USART1_RX
PA11 pin 70	not used
PA12 pin 71	not used
PA13 pin 72	alternate function, SWDIO (JTAG)
PA14 pin 76	alternate function, SWCLK (JTAG)
PA15 pin 77	output, digital, LCD backlight control
**
** Defines for all GPIO pins used on Port A:
*/
#define ADC_THM0_Pin            GPIO_PIN_0
#define ADC_THM0_GPIO_Port      GPIOA
#define ADC_THM1_Pin            GPIO_PIN_1
#define ADC_THM1_GPIO_Port      GPIOA
#define ADC_THM2_Pin            GPIO_PIN_2
#define ADC_THM2_GPIO_Port      GPIOA
#define ADC_THM3_Pin            GPIO_PIN_3
#define ADC_THM3_GPIO_Port      GPIOA
#define ADC_IN0_Pin             GPIO_PIN_4
#define ADC_IN0_GPIO_Port       GPIOA
#define ADC_IN1_Pin             GPIO_PIN_5
#define ADC_IN1_GPIO_Port       GPIOA
#define ADC_IN2_Pin             GPIO_PIN_6
#define ADC_IN2_GPIO_Port       GPIOA
#define ADC_IN3_Pin             GPIO_PIN_7
#define ADC_IN3_GPIO_Port       GPIOA
#define USART1_TXD_Pin          GPIO_PIN_9
#define USART1_TXD_GPIO_Port    GPIOA
#define USART1_RXD_Pin          GPIO_PIN_10
#define USART1_RXD_GPIO_Port    GPIOA
#define TMS_SWDIO_Pin           GPIO_PIN_13
#define TMS_SWDIO_GPIO_Port     GPIOA
#define TCK_SWCLK_Pin           GPIO_PIN_14
#define TCK_SWCLK_GPIO_Port     GPIOA
#define LCD_BKLT_EN_Pin         GPIO_PIN_15
#define LCD_BKLT_EN_GPIO_Port   GPIOA

/*
** For reference - list of all STM32F071xx pins associated with PORT B:
**
PB0  pin 35	output, digital, (PP), fan4 enable (low)
PB1  pin 36	output, digital, (PP), fan3 enable (low)
PB2  pin 37	output, digital, (PP), fan2 enable (low)
PB3  pin 89	not used
PB4  pin 90	not used
PB5  pin 91	not used
PB6  pin 92	alternate function, I2C1_SCL (EEPROM)
PB7  pin 93	alternate function, I2C1_SDA (EEPROM)
PB8  pin 95	output, digital, (PP), EEPROM WP signal
PB9  pin 96	output, digital, (PP), EEPROM A0 signal
PB10 pin 47	output, alternate function, TIM2_CH3 (TEC PWM)
PB11 pin 48	not used
PB12 pin 51	output, digital, (PP), HB logic (see chart on schematic)
PB13 pin 52	output, digital, (PP), HB logic (Not used as of board rev 2.0)
PB14 pin 53	output, digital, (PP), HB logic (see chart on schematic)
PB15 pin 54	not used on rev. 2 boards. On rev. 3 boards...
                ...output, alternate function, TIM15_CH2 (for audio/buzzer)
**
** Defines for all GPIO pins used on Port B:
*/
#define FAN4_BUF_nOE_Pin        GPIO_PIN_0
#define FAN4_BUF_nOE_GPIO_Port  GPIOB
#define FAN3_BUF_nOE_Pin        GPIO_PIN_1
#define FAN3_BUF_nOE_GPIO_Port  GPIOB
#define FAN2_BUF_nOE_Pin        GPIO_PIN_2
#define FAN2_BUF_nOE_GPIO_Port  GPIOB
#define MEM_SCL_Pin             GPIO_PIN_6
#define MEM_SCL_GPIO_Port       GPIOB
#define MEM_SDA_Pin             GPIO_PIN_7
#define MEM_SDA_GPIO_Port       GPIOB
#define MEM_WP_Pin              GPIO_PIN_8
#define MEM_WP_GPIO_Port        GPIOB
#define MEM_A0_Pin              GPIO_PIN_9
#define MEM_A0_GPIO_Port        GPIOB
#define TEC_PWM_Pin             GPIO_PIN_10
#define TEC_PWM_GPIO_Port       GPIOB
#define HB_POL_RVRS_Pin         GPIO_PIN_12
#define HB_POL_RVRS_GPIO_Port   GPIOB
#define HB_LOG_nEN_Pin          GPIO_PIN_13  // no longer used as of rev 2 hardware
#define HB_LOG_nEN_GPIO_Port    GPIOB
#define HB_LOG_LVL_Pin          GPIO_PIN_14
#define HB_LOG_LVL_GPIO_Port    GPIOB
#define AUDIO_FB_Pin            GPIO_PIN_15  // new as of rev 3 hardware
#define AUDIO_FB_GPIO_Port      GPIOB

/*
** For reference - list of all STM32F071xx pins associated with PORT C:
**
PC0  pin 15	input, digital, membrane power switch
PC1  pin 16	input, digital, membrane set switch
PC2  pin 17	input, digital, membrane down switch
PC3  pin 18	input, digital, membrane up switch
PC4  pin 33	not used
PC5  pin 34	not used
PC6  pin 63	not used on rev. 2 boards.  On rev. 3 boards...
                ...output, digital, (PP), RS232 enable (active low)
PC7  pin 64	not used on rev. 2 boards.  On rev. 3 boards...
                ...input, digital, (PP), RS232 invalid signal
PC8  pin 65	output, digital, (PP), buzzer/audio (on rev. 2 boards)...
                ...not used on rev. 3 boards.
PC9  pin 66	not used
PC10 pin 78	output, digital, (PP), LCD data enable
PC11 pin 79	output, digital, (PP), LCD RS
PC12 pin 80	output, digital, (PP), LCD RW
PC13 pin 7	output, digital, (PP), LED0 (red - heat)
PC14 pin 8	output, digital, (PP), LED1 (blue - cool)
PC15 pin 9	output, digital, (PP), LED2 (green - power on)
**
** Defines for all GPIO pins used on Port C:
*/
#define MEMB_PWR_SW_Pin         GPIO_PIN_0
#define MEMB_PWR_SW_GPIO_Port   GPIOC
#define MEMB_SET_SW_Pin         GPIO_PIN_1
#define MEMB_SET_SW_GPIO_Port   GPIOC
#define MEMB_D_ARR_SW_Pin       GPIO_PIN_2
#define MEMB_D_ARR_SW_GPIO_Port GPIOC
#define MEMB_U_ARR_SW_Pin       GPIO_PIN_3
#define MEMB_U_ARR_SW_GPIO_Port GPIOC
#define RS232_EN_Pin            GPIO_PIN_6  // new as of rev. 3 hardware
#define RS232_EN_GPIO_Port      GPIOC
#define RS232_BAD_IN_Pin        GPIO_PIN_7  // new as of rev. 3 hardware
#define RS232_BAD_IN_GPIO_Port  GPIOC
#define BUZZER_FB_Pin           GPIO_PIN_8
#define BUZZER_FB_GPIO_Port     GPIOC
#define LCD_EN_Pin              GPIO_PIN_10
#define LCD_EN_GPIO_Port        GPIOC
#define LCD_RS_Pin              GPIO_PIN_11
#define LCD_RS_GPIO_Port        GPIOC
#define LCD_RW_Pin              GPIO_PIN_12
#define LCD_RW_GPIO_Port        GPIOC
#define LED0_CTRL_Pin           GPIO_PIN_13
#define LED0_CTRL_GPIO_Port     GPIOC
#define LED1_CTRL_Pin           GPIO_PIN_14
#define LED1_CTRL_GPIO_Port     GPIOC
#define LED2_CTRL_Pin           GPIO_PIN_15
#define LED2_CTRL_GPIO_Port     GPIOC

/*
** For reference - list of all STM32F071xx pins associated with PORT D:
**
PD0  pin 81	output, digital, (PP), LCD DB0
PD1  pin 82	output, digital, (PP), LCD DB1
PD2  pin 83	output, digital, (PP), LCD DB2
PD3  pin 84	output, digital, (PP), LCD DB3
PD4  pin 85	output, digital, (PP), LCD DB4
PD5  pin 86	output, digital, (PP), LCD DB5
PD6  pin 87	output, digital, (PP), LCD DB6
PD7  pin 88	output, digital, (PP), LCD DB7
PD8  pin 55	input, digital, config bit 0
PD9  pin 56	input, digital, config bit 1
PD10 pin 57	input, digital, config bit 2
PD11 pin 58	input, digital, config bit 3
PD12 pin 59	input, digital, config bit 4
PD13 pin 60	output, digital, (debug - was previously input config bit 5)
PD14 pin 61	not used
PD15 pin 62	not used
**
** Defines for all GPIO pins used on Port D:
*/
#define LCD_DB0_Pin             GPIO_PIN_0
#define LCD_DB0_GPIO_Port       GPIOD
#define LCD_DB1_Pin             GPIO_PIN_1
#define LCD_DB1_GPIO_Port       GPIOD
#define LCD_DB2_Pin             GPIO_PIN_2
#define LCD_DB2_GPIO_Port       GPIOD
#define LCD_DB3_Pin             GPIO_PIN_3
#define LCD_DB3_GPIO_Port       GPIOD
#define LCD_DB4_Pin             GPIO_PIN_4
#define LCD_DB4_GPIO_Port       GPIOD
#define LCD_DB5_Pin             GPIO_PIN_5
#define LCD_DB5_GPIO_Port       GPIOD
#define LCD_DB6_Pin             GPIO_PIN_6
#define LCD_DB6_GPIO_Port       GPIOD
#define LCD_DB7_Pin             GPIO_PIN_7
#define LCD_DB7_GPIO_Port       GPIOD
#define CONF_FW_BIT0_Pin        GPIO_PIN_8
#define CONF_FW_BIT0_GPIO_Port  GPIOD
#define CONF_FW_BIT1_Pin        GPIO_PIN_9
#define CONF_FW_BIT1_GPIO_Port  GPIOD
#define CONF_FW_BIT2_Pin        GPIO_PIN_10
#define CONF_FW_BIT2_GPIO_Port  GPIOD
#define CONF_FW_BIT3_Pin        GPIO_PIN_11
#define CONF_FW_BIT3_GPIO_Port  GPIOD
#define CONF_FW_BIT4_Pin        GPIO_PIN_12
#define CONF_FW_BIT4_GPIO_Port  GPIOD
#define CONF_FW_BIT5_Pin        GPIO_PIN_13  // no longer used as config bit input
#define CONF_FW_BIT5_GPIO_Port  GPIOD
#define DEBUG_OUT_Pin           GPIO_PIN_13  // (alternate I/O function for PD13)
#define DEBUG_OUT_GPIO_Port     GPIOD

/*
** For reference - list of all STM32F071xx pins associated with PORT E:
** NOTE:  Re-ordering of fan numbers for intallation and ease of connector ID.
**        However, the original schematic names are still as-is.
**
PE0  pin 97	output, digital, (PP), EEPROM A1 signal
PE1  pin 98	output, digital, (PP), EEPROM A2 signal
PE2  pin 1	not used
PE3  pin 2	input, alternate function, TIM3_CH1, fan1 tach
PE4  pin 3	input, alternate function, TIM3_CH2, fan3 tach
PE5  pin 4	input, alternate function, TIM3_CH3, fan4 tach
PE6  pin 5	input, alternate function, TIM3_CH4, fan2 tach
PE7  pin 38	output, digital, (PP), fan1 enable (low)
PE8  pin 39	not used
PE9  pin 40	output, alternate function, TIM1_CH1, fan1 pwm
PE10 pin 41	not used
PE11 pin 42	output, alternate function, TIM1_CH2, fan3 pwm
PE12 pin 43	not used
PE13 pin 44	output, alternate function, TIM1_CH3, fan4 pwm
PE14 pin 45	output, alternate function, TIM1_CH4, fan2 pwm
PE15 pin 46	not used
**
** Defines for all GPIO pins used on Port E:
*/
#define MEM_A1_Pin              GPIO_PIN_0
#define MEM_A1_GPIO_Port        GPIOE
#define MEM_A2_Pin              GPIO_PIN_1
#define MEM_A2_GPIO_Port        GPIOE
#define FAN1_TACH_Pin           GPIO_PIN_3
#define FAN1_TACH_GPIO_Port     GPIOE
#define FAN2_TACH_Pin           GPIO_PIN_4
#define FAN2_TACH_GPIO_Port     GPIOE
#define FAN3_TACH_Pin           GPIO_PIN_5
#define FAN3_TACH_GPIO_Port     GPIOE
#define FAN4_TACH_Pin           GPIO_PIN_6
#define FAN4_TACH_GPIO_Port     GPIOE
#define FAN1_BUF_nOE_Pin        GPIO_PIN_7
#define FAN1_BUF_nOE_GPIO_Port  GPIOE
#define FAN1_PWM_Pin            GPIO_PIN_9
#define FAN1_PWM_GPIO_Port      GPIOE
#define FAN2_PWM_Pin            GPIO_PIN_11
#define FAN2_PWM_GPIO_Port      GPIOE
#define FAN3_PWM_Pin            GPIO_PIN_13
#define FAN3_PWM_GPIO_Port      GPIOE
#define FAN4_PWM_Pin            GPIO_PIN_14
#define FAN4_PWM_GPIO_Port      GPIOE

/*
** For reference - list of all STM32F071xx pins associated with PORT F:
**
PF0  pin 12	default function, osc input
PF1  pin 13	default function, osc output
PF2  pin 19	not used
PF3  pin 22	not used
PF6  pin 73	not used
PF9  pin 10	output, digital, (PP), LED on-board red indicator
PF10 pin 11	output, digital, (PP), LED on-board white indicator
**
** Defines for all GPIO pins used on Port F:
*/
#define LED3_CTRL_Pin           GPIO_PIN_9
#define LED3_CTRL_GPIO_Port     GPIOF
#define LED4_CTRL_Pin           GPIO_PIN_10
#define LED4_CTRL_GPIO_Port     GPIOF

/* NOTE: Function prototypes for gpio.c are in the project.h module. */

#endif /* _gpio_h_ */

/* gpio.h *************************************************************** EOF */
