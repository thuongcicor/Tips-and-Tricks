/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    beep.h
**
** Description: Defines and related audio/beeper information.
**
** Version/Author/Date/Description:
** 1   DMA   03/07/2018  Began coding.
** 2   DMA   02/17/2019  Added defines for rev. 3 hardware, which uses the new
**                       PWM-driven audio indicator.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef beep_h_
#define beep_h_

/* Audio/beeper define shortcuts.  Note that there is really no "on" or "off"
** state for the beeper. It must be driven with a square wave (adjustable
** frequency) to produce sound.  However, all the control commands are defined
** here for completeness.  Used on rev. 2 hardware. */
#define  BEEP_TOGGLE  (HAL_GPIO_TogglePin( BUZZER_FB_GPIO_Port, BUZZER_FB_Pin ))
#define  BEEP_ON      (HAL_GPIO_WritePin( BUZZER_FB_GPIO_Port, BUZZER_FB_Pin, GPIO_PIN_SET ))
#define  BEEP_OFF     (HAL_GPIO_WritePin( BUZZER_FB_GPIO_Port, BUZZER_FB_Pin, GPIO_PIN_RESET ))

#define  BEEP_PB_TIME  100   // time in mSec (pushbutton beep/click time)

typedef enum beeper_types_modes
{
  STOP_BEEP,    // stop beeper/horn (turn off)
  SINGLE,       // single beep for duration (on_time)
  CONTINUOUS,   // continuous beep
  MULTIPLE,     // multiple beeps with on_time, off_time and repeat sequence
  NOTHING       // do nothing - no count updates or state changes
}  beep_t;

typedef struct beeper_control_variables
{
  beep_t  type;         // beeper types or modes
  U8      active;       // trigger to indicate ready to start beeps
  U8      output;       // flag to control sound output (on/off for debug)
  U16     timer;        // keeps track of counts for on-off timing
  U16     on_counts;    // timing counts for beeper on state
  U16     off_counts;   // timing counts for beeper off state
  U8      cycle;        // counts the on-off cycles (sequence)
  U8      repeat;       // number of times to repeat on-off sequence
}  beeper_t;

/*******************************************************************************
** function prototypes - beep.c
*******************************************************************************/
void  beeper_init( void );
void  beeper_update( void );
void  beeper_trigger( void );
void  update_beeper_events( void );
void  beeper_control( BOOL onoff );
void  MX_TIM15_Init( void );  // audio/beeper pwm
void  audio_pwm_on_off( U8 on_off );

/* Needed to eliminate warning for timer init functions, even though function
** is in xx_hal_msp.c. TODO: re-visit this issue! */
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

#endif /* beep_h_ */

/* beep.h *************************************************************** EOF */
