/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    serial_comm.h
**
** Description: This file contains defines and assignments specifically for the
**              Message Decoder Processor (MDP) section.
**
** Version/Author/Date/Description:
** 1   DMA   03/07/2018  Began coding.
** 2   DMA   01/02/2019  Added defines for RS-232 chip control.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef serial_comm_h_
#define serial_comm_h_

/* Make sure MAX_DEBUG_OUT_BUFFER_SIZE is adjusted as new entries are added to
** the CLI menu in serial_commands.c. */
#define  MAX_DEBUG_OUT_BUFFER_SIZE  1023U  // size of debug output uart buffer
#define  MAX_DEBUG_IN_BUFFER_SIZE   24U    // size of debug input uart buffer
#define  MAX_DEBUG_IN_PARM1_SIZE    8U     // size of debug input for parameter 1
#define  MAX_DEBUG_IN_PARM2_SIZE    8U     // size of debug input for parameter 2
#define  MAX_MENU_STRING_LENGTH     44U    // max string length for each menu entry

/* RS-232 chip (MAX3221) enable control.  New as of revision 3 hardware. This
** code is backwards compatable, since earlier rev boards have nothing connected
** to this pin.  Schematic node/signal is "nRS232_nEN"; input is active low. */
#define  RS232_ON     (HAL_GPIO_WritePin( RS232_EN_GPIO_Port, RS232_EN_Pin, GPIO_PIN_RESET ))
#define  RS232_OFF    (HAL_GPIO_WritePin( RS232_EN_GPIO_Port, RS232_EN_Pin, GPIO_PIN_SET ))

#if 0
#define  TRANSMIT         1  // mdp is in transmit mode
#define  RECEIVE          2  // mdp is in receive mode
#define  TRANSMIT_DONE    3  // mdp has sent the last character of current msg
#define  MDP_IDLE         4  // mdp is off-line

/* MDP command list defines */
#define  GET              1  // indicates command is 'get' (read only)
#define  SET              2  // cmnd is 'set' (write only - may not have data)
#define  GET_SET          3  // indicates command is read and/or write
#define  PASSWORD         0xABBA  // double duty - it's the password and it's
                                  // used to indentify the factory mode command
#define  INT1             1  // integer value, 1 word, 16 bits
#define  INT2             2  // long integer value, 2 words, 32 bits
#define  ASCII            3  // ascii string data
#define  ARRAY            4  // array of ints, fixed at 16 words/ints
#define  END_OF_LIST      0xDEAD  // marks the end of the command list
#define  PARAM            0xFFFE  // indicates the 1st parameter is the address
#define  NONE             0xFFFF  // indicates no eeprom or sram storage

/*
** Serial Data MDP Protocol Definitions:
** +-------+--------+-------+------+--------+-----------+-------+------+
** | Start | Source | Dest. | Msg  | Num of |           | Check | End  |
** | Char  |  Addr. | Addr. | Cmnd | Bytes  | Data      | Sum   | Char |
** +-------+--------+-------+------+--------+-----------+-------+------+
**  STX(1)  SA(2)    DA(2)   MC(2)  NB(2)    DATA(0-255) CS(2)   ETX(1)
**  |       |        |       |      |        |           |       |
**  |       |        |       |      |        |           |       buffer[NB + 11]
**  |       |        |       |      |        |           buffer[NB + 9]
**  |       |        |       |      |        buffer[9], length is NB
**  |       |        |       |      buffer[7]
**  |       |        |       buffer[5]
**  |       |        buffer[3]
**  |       buffer[1]
**  buffer[0]
**
** The position in the serial data buffer is shown for each item in the MDP
** protocol as it is received.  This of course assumes the MDP message was
** correctly transmitted by the host and correctly received.  Because the
** data can vary from 0 to 255 bytes, the max buffer size for the mdp incoming
** data should be 267 bytes.  In this application, the maximum received amount
** of data is a 50 byte ASCII message (DeviceNet [30-1-10]).  The maximum
** for a transmit message is 250 bytes (transient analyzer data).  This makes
** the max buffer size equal to 250 + 12 (protocol overhead) = 262.
*/
#define  MAX_BUF_SIZE     262

#define  STX              2       // start of text character, mdp protocol
#define  ETX              3       // end of text character, mdp protocol

/*  ETX_flag values */
#define  MSG_NOT_READY    0       // incoming mdp message not ready to process
#define  MSG_READY        1       // mdp message is received and ready
#define  PARSE_CMND       2       // get command byte from mdp message
#define  MEMORY_REQ       3       // write data to EEPROM
#define  MSG_SEND         5       // send mdp response back to host

/*  Protocol Message Values  */
#define  MDP_OK           0       // mdp received message is error-free
#define  STX_ERROR        1       // start of message character missing
#define  PROTOCOL_ERROR   2       // invalid or out of range data found
#define  CMND_LEN_ERROR   3       // not enough characters in protocol header
#define  WRITE_EE         21      //
#define  P2P_NO_RESP      0x00    // point-to-point msg from host, no response
#define  P2P_MSG_W_RESP   0x01    // point-to-point msg from host, response required
#define  BCAST_MSG_W_RESP 0xFE    // broadcast msg from host requiring response
#define  BCAST_NO_RESP    0xFF    // broadcast msg from host, no response allowed

#endif

/* Function prototypes from uart.c. */
void uart_init( void );
void input_buffer_reset( void );
void send_debug( char * d_str, dbug_print_options_t opt );
void HAL_UART_TxCpltCallback( UART_HandleTypeDef *huart );
void HAL_UART_RxCpltCallback( UART_HandleTypeDef *huart );
void transmit_character( U8 x_char );
U16  inc_circular_buf_ptr( U16 buffer_pointer, circ_buf_t which_buf );
U8 check_message_received( void );

/* Function prototypes from serial_commands.c. */
void print_debug_menu( void );
U8   process_message( void );
char * strip_blanks( char * the_buff );
char * get_main_menu_item( char * menu_str );
void cmd_prompt( void );
void cmd_beep( void );
void cmd_null( void );
void cmd_reboot_stm32( void );
void cmd_firmware_ver( void );
void cmd_dbug_out( void );
void cmd_pi_cool_values( void );
void cmd_pi_heat_values( void );
void cmd_temp_units_fc( void );
void cmd_setpoint_high( void );
void cmd_setpoint_low( void );
void cmd_stm32_info( void );
void cmd_get_ee( void );
void cmd_beta( void );
void cmd_thermistors( void );
void cmd_adc_counts( void );
void cmd_fan_funcs( void );
void cmd_voltages( void );
void cmd_control( void );
void cmd_set_ee( void );
void cmd_restore_parms( void );
char * get_mode_text( void );

#endif  /* serial_comm_h_ */

/* serial_comm.h ******************************************************** EOF */
