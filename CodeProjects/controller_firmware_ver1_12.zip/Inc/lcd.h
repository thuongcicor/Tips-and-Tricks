/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    lcd.h
**
** Description: Defines and related LCD module information.
**
** Version/Author/Date/Description:
** 1   DMA   12/07/2017  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef lcd_h_
#define lcd_h_

typedef enum  lcd_sequence_status_and_operation_status
{
  LCD_NOT_DONE,   // sequence not done yet
  LCD_DONE,       // sequence has completed
  LCD_RESET,      // reset the static vars to default values
  LCD_CONTINUE,   // continue with current function operation
  LCD_START,      // start the LCD write sequence
  LCD_CMND,       // send command code to LCD module
  LCD_DATA,       // send data byte to LCD module
  LCD_RIGHT,      // shift display data right
  LCD_LEFT        // shift display data left
}  lcd_t;

typedef struct  lcd_control_struct_parameters
{
  BOOL    scroll;        // enable (1) or disable (0) idle mode scrolling
  BOOL    ok_to_start;   // flag for display operation in manual mode
  BOOL    display_busy;  // display is doing something - don't overwrite
}  lcd_ctrl_t;

/* Character position and DDRAM addresses (hex).
** Char position:       1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16
** Addresses, line 1:   00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
** Addresses, line 2:   40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
*/

/* Delay values used for LCD module timing. */
#define  DELAY_4uSEC      1U      // small_delay value for 4uSeconds
#define  DELAY_8uSEC      2U      // small_delay value for 8uSeconds
#define  DELAY_12uSEC     3U      // small_delay value for 12uSeconds
#define  DELAY_20uSEC     5U      // small_delay value for 20uSeconds
#define  DELAY_40uSEC     10U     // small_delay value for 40uSeconds

/*  LCD module defines for the 16X2 display. */
#define  LCD_LINE1        1       // identifies top line of LCD
#define  LCD_LINE2        2       // identifies bottom line of LCD
#define  LCD_LINE1_HOME   0x00    // DDRAM address 1st position, line 1
#define  LCD_LINE2_HOME   0x40    // DDRAM address 1st position, line 2
#define  LCD_POSITIONS    16      // total of 16 character positions for each line
#define  LCD_CLEAR        1       // command: clear all display, move to home position
#define  LCD_HOME         2       // command: move to home position without clear
#define  LCD_MOVETO       3       // command: move to user-selected character position

#define  SPLASH_FULL      1       // flag for a full splash screen performed
#define  SPLASH_FAST      2       // flag for a quicker splash screen performed

typedef enum  lcd_special_image_loading_and_operation_status
{
  /* Leave the first 8 in order, since they are used for address calculations. */
  LOAD_CGRAM_0 = 0,  // 1st CGRAM image location
  LOAD_CGRAM_1,      // 2nd CGRAM image location
  LOAD_CGRAM_2,      // 3rd CGRAM image location
  LOAD_CGRAM_3,      // 4th CGRAM image location
  LOAD_CGRAM_4,      // 5th CGRAM image location
  LOAD_CGRAM_5,      // 6th CGRAM image location
  LOAD_CGRAM_6,      // 7th CGRAM image location
  LOAD_CGRAM_7,      // 8th CGRAM image location
  LOAD_ALL           // load all 8 images into CGRAM locations 0 thru 63
}  lcd_special_t;

/* Addresses for GCRAM special characters.  8 bytes per character/image. */
#define  CGRAM_0          0x00    // starting CGRAM address, 1st image location
#define  CGRAM_1          0x08    // starting CGRAM address, 2nd image location
#define  CGRAM_2          0x10    // starting CGRAM address, 3rd image location
#define  CGRAM_3          0x18    // starting CGRAM address, 4th image location
#define  CGRAM_4          0x20    // starting CGRAM address, 5st image location
#define  CGRAM_5          0x28    // starting CGRAM address, 6nd image location
#define  CGRAM_6          0x30    // starting CGRAM address, 7rd image location
#define  CGRAM_7          0x38    // starting CGRAM address, 8th image location
#define  CG_START         0x00    // beginning address - start of CGRAM
#define  CG_END           0x3F    // last address - end of CGRAM

#define  SCROLL_CHAR      0xA1    // character to scroll across screen for idle
#define  SPACE_CHAR       0x20    // ASCII ' ' (space)
#define  degree_symbol    0xDF    // built-in degree symbol in LCD module ROM

/*******************************************************************************
** function prototypes - lcd.c and lcd_special.c
*******************************************************************************/
lcd_t lcd_init( lcd_t op );
void  LCD_Write( lcd_t rs, U8 db );
void  LCD_Data_Bits_Set( U8 dByte );
void  small_delay( U8 val );
lcd_t send_lcd_message( char * str, U8 line );
void  splash_screen( U8 option );
void  screen_shift_left( void );
void  clear_line( U8 line );
void  load_custom_lcd_images( lcd_special_t im_id /*, U8 * im_adrs*/ );
void  setup_LCD( U8 cmnd, U8 pos );
void  animation_x1( void );
void  animation_x2( void );
void  animation_x3( void );
void  shift_display_array( void );
void  load_display_array_for_scroll( void );
void  show_idle_scrolling( void );
void  load_double_stroke_number( U8 num );
void  scrolling_set( BOOL scroll_yes_no );
BOOL  scrolling_get( void );
void  display_busy_set( BOOL busyflag );
BOOL  display_busy_get( void );
void  update_display_events( void );
void  lcd_backlight_control( BOOL onoff );
void  set_manual_ok_to_start_flag( BOOL ok2startyesno );
BOOL  get_manual_ok_to_start_flag( void );
void  pwm_persistent_vals( U8 type, void * value );

#endif /* lcd_h_ */

/* lcd.h **************************************************************** EOF */
