/*******************************************************************************
**
** Project:     Marlow Compact TE Controller (ISC-controller).
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    debug.h
**
** Description:
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2017 - 2018. Marlow Industries Inc.  All rights reserved.
*******************************************************************************/
#ifndef debug_h_  // DON'T INCLUDE THIS MODULE IN THE PROJECT......
#define debug_h_

#define  TRANSMIT         1  // mdp is in transmit mode
#define  RECEIVE          2  // mdp is in receive mode
#define  TRANSMIT_DONE    3  // mdp has sent the last character of current msg
#define  MDP_IDLE         4  // mdp is off-line

/* MDP command list defines */
#define  GET              1  // indicates command is 'get' (read only)
#define  SET              2  // cmnd is 'set' (write only - may not have data)
#define  GET_SET          3  // indicates command is read and/or write
#define  PASSWORD         0xABBA  // double duty - it's the password and it's
                                  // used to indentify the factory mode command
#define  INT1             1  // integer value, 1 word, 16 bits
#define  INT2             2  // long integer value, 2 words, 32 bits
#define  ASCII            3  // ascii string data
#define  ARRAY            4  // array of ints, fixed at 16 words/ints
#define  END_OF_LIST      0xDEAD  // marks the end of the command list
#define  PARAM            0xFFFE  // indicates the 1st parameter is the address
#define  NONE             0xFFFF  // indicates no eeprom or sram storage

/*
** Serial Data MDP Protocol Definitions:
** +-------+--------+-------+------+--------+-----------+-------+------+
** | Start | Source | Dest. | Msg  | Num of |           | Check | End  |
** | Char  |  Addr. | Addr. | Cmnd | Bytes  | Data      | Sum   | Char |
** +-------+--------+-------+------+--------+-----------+-------+------+
**  STX(1)  SA(2)    DA(2)   MC(2)  NB(2)    DATA(0-255) CS(2)   ETX(1)
**  |       |        |       |      |        |           |       |
**  |       |        |       |      |        |           |       buffer[NB + 11]
**  |       |        |       |      |        |           buffer[NB + 9]
**  |       |        |       |      |        buffer[9], length is NB
**  |       |        |       |      buffer[7]
**  |       |        |       buffer[5]
**  |       |        buffer[3]
**  |       buffer[1]
**  buffer[0]
**
** The position in the serial data buffer is shown for each item in the MDP
** protocol as it is received.  This of course assumes the MDP message was
** correctly transmitted by the host and correctly received.  Because the
** data can vary from 0 to 255 bytes, the max buffer size for the mdp incoming
** data should be 267 bytes.  In this application, the maximum received amount
** of data is a 50 byte ASCII message (DeviceNet [30-1-10]).  The maximum
** for a transmit message is 250 bytes (transient analyzer data).  This makes
** the max buffer size equal to 250 + 12 (protocol overhead) = 262.
*/
#define  MAX_BUF_SIZE     262

#define  ERROR_MASK       0x0080  // SCI receiver error flag
#define  BRKDET_MASK      0x0020  // SCI break-detect flag
#define  FE_MASK          0x0010  // SCI framing error flag
#define  OE_MASK          0x0008  // SCI overrun error flag
#define  PE_MASK          0x0004  // SCI parity error flag
#define  BRKDET_SET       0x0008  // rx error indicator bit position
#define  FE_SET           0x0004  // rx error indicator bit position
#define  OE_SET           0x0002  // rx error indicator bit position
#define  PE_SET           0x0001  // rx error indicator bit position

#define  STX              2       // start of text character, mdp protocol
#define  ETX              3       // end of text character, mdp protocol

/*  ETX_flag values */
#define  MSG_NOT_READY    0       // incoming mdp message not ready to process
#define  MSG_READY        1       // mdp message is received and ready
#define  PARSE_CMND       2       // get command byte from mdp message
#define  MEMORY_REQ       3       // write data to EEPROM
#define  MSG_SEND         5       // send mdp response back to host

/*  Protocol Message Values  */
#define  MDP_OK           0       // mdp received message is error-free
#define  STX_ERROR        1       // start of message character missing
#define  PROTOCOL_ERROR   2       // invalid or out of range data found
#define  CMND_LEN_ERROR   3       // not enough characters in protocol header
#define  CHECKSUM_ERROR   4       // calculated checksum does not match received
#define  MSG_LEN_ERROR    5       // message length is out of range
#define  RCVR_ERROR       6       // receiver error, (frame, overrun, parity)
#define  COMMAND_INVALID  10      // command word is undefined
#define  OPERAND_INVALID  11      // command operand is illegal, out of range
#define  MIN_MSG_LEN      12      // minimum mdp protocol message length
#define  SEND_OK_MSG      13      // send "OK" response after 'set' command
#define  MSG_LOADED       14      // indicates response message is ready to go
#define  PASS_PROTECT     15      // indicates command is password protected
#define  READ_EE          20      //
#define  WRITE_EE         21      //
#define  P2P_NO_RESP      0x00    // point-to-point msg from host, no response
#define  P2P_MSG_W_RESP   0x01    // point-to-point msg from host, response required
#define  BCAST_MSG_W_RESP 0xFE    // broadcast msg from host requiring response
#define  BCAST_NO_RESP    0xFF    // broadcast msg from host, no response allowed

/* Used for the list of pre-defined MDP responses. */
#define  RECEIVER_ERR_RESP             1
#define  PROTOCOL_ERR_RESP             2
#define  COMMAND_ERR_RESP              3
#define  CHECKSUM_ERR_RESP             4
#define  MSG_SIZE_ERR_RESP             5
#define  INVALID_COMMAND_ERR_RESP      6
#define  INVALID_OPERAND_ERR_RESP      7
#define  CMND_OK_RESP                  8
#define  INVALID_EE_READ_ERR_RESP      9
#define  PASSWORD_SET_ERR_RESP         10

/* Used with the pre-defined MDP response code - message lengths. */
#define  RECEIVER_ERROR_LEN            7
#define  PROTOCOL_ERROR_LEN            7
#define  COMMAND_ERROR_LEN             7
#define  CHECKSUM_ERROR_LEN            7
#define  MSG_SIZE_ERROR_LEN            7
#define  INVALID_COMMAND_LEN           8
#define  INVALID_OPERAND_LEN           8
#define  CMND_OK_LEN                   3
#define  INVALID_EE_READ_LEN           8
#define  PASSWORD_SET_ERR_LEN          8

/* Used with mdp / dnet access to MDP */
#define REQUESTED                      1
#define GRANTED                        2
#define COMPLETED                      3

/*
** The MDP structures are declared in the mdp.c module.
** When it makes sense, keep variables in alphabetical order for ease of
** maintainability and debugging.
*/
   typedef  struct  mdp_variables1
   {
      uint  app_cmnd;           // application section command byte
      uint  broadcast;          // TRUE if broadcast message
      uint  checksum;           // checksum byte of the message
      uint  cmnd_indx;          // index pointer number for the mdp command
      uint  d_addr;             // destination address (this unit's address)
      uint  ETX_flag;           // end of transmission byte & MDP state
      uint  for_me;             // TRUE if the message is for this unit
      uint  mode;               // indicates transmit, receive or idle mode
      uint  msg_cmnd;           // message command byte of MDP protocol
      uint  msg_start;          // STX detected, message is being received
      uint  num_bytes;          // number of bytes in message counter
      uint  rtn_msg;            // type of return message to send
      uint  rx_error;           // errors found in received message
      uint  rx_delay;           // delay count before responding to rx_error
      uint  s_addr;             // source address (from host)

   }  MDP1A;

   /*
   ** Don't modify this structure without a corresponding mod to the MDP
   ** command list, in mdp_init.c.
   */
   typedef  struct  mdp_command_list
   {
      uint  hex_cmnd;           // command, in hex, sent from host
      uint  ee_adrs;            // start location of data in eeprom
      uint  ram_adrs;           // start location of data in sram
      uint  access;             // indicates if command is get only or set/get
      uint  params;             // max number of parameters for this command
      uint  type;               // parameter data type, integer or string
      uint  len;                // max length of string, (max 50 bytes), OR -
                                // array offset for 2 parameter commands
   }  MDP4;


/*******************************************************************************
** function prototypes
*******************************************************************************/
/* functions from mdp_init.c */
uint  mdp_init_rev( uint );
void  mdp_init( void );

/* functions from mdp1.c */
uint  mdp1_init( uint );
void  mdp_fast_loop( void );
void  mdp( void );
void  look_for_errors( void );
void  parse_message( void );
uint  get_cmnd( char *msg, uint length );
void  eeprom_write_request( void );
void  get_int_data_values( uint index );
void  store_sram_data( uint index );
void  retrieve_sram_data( uint index );

/* functions from mdp2.c */
uint  mdp2_init( uint );
int   convert_ascii2hex( char *num );
int   ascii2hex( int ascii_val );
int   calc_checksum( char *rmsg, int rlen );
void  return_message2host( void );
void  load_buffer( uint word_type, uint index, uint sram_adrs );
void  load_response( uint resp_code );
void  read_serial_data( void );

#endif  /* debug_h_ */

/* debug.h ************************************************************** EOF */
