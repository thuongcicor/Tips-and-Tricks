/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    eeprom.h
**
** Description: Defines and function prototypes associated with the external
**              I2C EEPROM device.  This may be a 24C64, 24C256, or any other
**              part in this family (minimum capacity of 4K bytes).
**
** Version/Author/Date/Description:
** 1   DMA   12/16/2017  Began coding.
** 2   DMA   01/13/2019  Added locations for real SPH and SPL.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef eeprom_h_
#define eeprom_h_

/* Defines for I2C and control pins on the EEPROM. (See gpio.h).  */
#define  EEPROM_I2C_SCL   PB6   // i2c clock signal on portB, pin6 (alternate func)
#define  EEPROM_I2C_SDA   PB7   // i2c data signal on portB, pin7 (alternate func)
#define  EEPROM_WP        PB8   // write protect input (high to disable writes)
#define  EEPROM_I2C_A0    PB9   // i2c address line A0
#define  EEPROM_I2C_A1    PE0   // i2c address line A1
#define  EEPROM_I2C_A2    PE1   // i2c address line A2

/* Note - the HAL I2C read function will automatically add the bit for read. */
#define  EEPROM_ADRS      0xA0  // i2c address for 24C64, 24C256, etc.
#define  EE_ADRS_WR       0xA0  // i2c address for write (A0=A1=A2=0)
#define  EE_ADRS_RD       0xA1  // i2c address for read  (A0=A1=A2=0)

/*******************************************************************************
** List of non-volatile addresses for all parameters stored in EEPROM.
** Refer to spreadsheet documentation for complete list and descriptions.
** Also refer to module versions.h for the latest firmware/ee version number.
** NOTE: Once an address is defined, it will remain unchanged!  This is for
**       forward/backward frimware compatibility.
*******************************************************************************/
#define  EE_VER           0x0000  // EEPROM version, major, minor (2 bytes)
#define  EE_avialable     0x0002  // (2 bytes)
#define  EE_TEMP_UNITS    0x0004  // temperature units, C or F (1 byte)
#define  EE_START_MODE    0x0005  // start mode, auto/manual (1 byte)
#define  EE_BETA          0x0006  // thermistor beta value (2 bytes)
#define  EE_SPH           0x0008  // high setpoint, (4 bytes, F32)
#define  EE_SPL           0x000C  // low setpoint,  (4 bytes, F32)
#define  EE_PGAIN_COOL    0x0014  // P gain value, cooling (4 bytes, F32)
#define  EE_IGAIN_COOL    0x0018  // I gain value, cooling (4 bytes, F32)
#define  EE_DGAIN_COOL    0x001C  // D gain value, cooling (4 bytes, F32)
#define  EE_PGAIN_HEAT    0x0020  // P gain value, heating (4 bytes, F32)
#define  EE_IGAIN_HEAT    0x0024  // I gain value, heating (4 bytes, F32)
#define  EE_DGAIN_HEAT    0x0028  // D gain value, heating (4 bytes, F32)
#define  EE_NUM_RESETS    0x0030  // total resets count (4 bytes, U32)
#define  EE_THRM_GAIN     0x0034  // thermistor gain value (4 bytes, F32)
#define  EE_FAN1_SETUP    0x0038  // fan 1 setup/config details (1 byte, U8)
#define  EE_FAN2_SETUP    0x0039  // fan 2 setup/config details (1 byte, U8)
#define  EE_FAN3_SETUP    0x003A  // fan 3 setup/config details (1 byte, U8)
#define  EE_FAN4_SETUP    0x003B  // fan 4 setup/config details (1 byte, U8)
#define  EE_TOTAL_TIME    0x003C  // total time controller is on (4 bytes, U32)
#define  EE_TOTAL_TEC     0x0040  // total time TEC is on (4 bytes, U32)
#define  EE_SPH_F         0x0044  // high setpoint, deg F (4 bytes, F32)
#define  EE_SPL_F         0x0048  // low setpoint, deg F (4 bytes, F32)
#define  EE_next_avail    0x004C

/* Since the blocks of data are read 32 bytes at a time (due to buffer sizes),
** make the total ee memory area a multiple of 32.  Adjust as data grows... */
#define  EE_MEM_BLOCKS     8
#define  EE_ADDRESS_LIMIT  (EE_MEM_BLOCKS * 32)

/*
** I2C TIMING is calculated with the I2C Clock source is the SYSCLK = 48 MHz.
** We have sample values from the STMCube and Discovery boards for the I2C
** timing.  We only need 100 KHz speed, with rise and fall times < 100ns. */
//#define  EEPROM_TIMING    0x00E0D3FF  // from disco board example (100KHz)
#define  EEPROM_TIMING    0x20303E5D  // value from STM320F0_cube (100KHz)
//#define  EEPROM_TIMING    0x00A51314  // disco board example (1 MHz, Rise time 100 ns, Fall time 100 ns)

typedef enum EEPROM_data_to_write_length_8_16_32
{
  EE_DATA_8,        // 8-bit data, signed or unsigned
  EE_DATA_16,       // 16-bit data, signed or unsigned
  EE_DATA_32        // 32-bit data, signed or unsigned
}  ee_data_len_t;

/*******************************************************************************
** function prototypes - eeprom.c
*******************************************************************************/
void  I2C_init( void );
void  MX_I2C1_Init( void );
void  i2c_ee_read( U16 ee_mem, U16 block_size );
void  i2c_ee_write( U32 ee_data, U16 ee_adrs, ee_data_len_t dl );
char  * get_ee_read_data_str( U8 start_pos );
//U16     get_ee_read_data_u16( void );
void  load_initial_ee_data( void );
void  load_default_values( void );
U32  get_ee_parameter( U16 ee_parm_adrs, ee_data_len_t dsize );

#endif  /* eeprom_h_ */

/* eeprom.h ************************************************************* EOF */
