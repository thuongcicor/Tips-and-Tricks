/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    pwm.h
**
** Description:
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   01/03/2019  Split pwc.c code into fans.c and pid_ctrl.c.  Keep this
**                       include file for both .c modules.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef pwm_h_
#define pwm_h_

/* Default prescaler value for TIM2 (TEC PWM) with counter clock equal to
** 16,000,000 Hz (with a 48MHz system clock):
** uhPrescalerValue = (uint32_t)(SystemCoreClock / 16000000) - 1;
** (Same is true for TIM1 and TIM3 used for the fans).
** Note that most fans specify a PWM drive frequency between 18 and 30KHz.
** We will use 24KHz for our fan PWM frequency.  The values listed below were
** emperically derived by scope measurements. */
#define  preScale24KHz    2       // value for 24KHz freq
#define  preScale18KHz    3       // value for 18KHz freq
#define  preScale5_6KHz   12      // value for 5.6KHz freq
#define  preScale4_5KHz   15      // value for 4.5KHz freq
#define  preScale2_8KHz   24      // value for 2.8KHz freq

/* Defines for the duty cycles for the FAN PWM drive.  (The TEC PWM drive value
** is calculated in the PID function). */
#define  PERIOD_VALUE     (uint32_t)(666 - 1)              // period value
#define  PULSE_VALUE_10   (uint32_t)(PERIOD_VALUE * 0.10)  // 10%
#define  PULSE_VALUE_20   (uint32_t)(PERIOD_VALUE * 0.20)  // 20%
#define  PULSE_VALUE_25   (uint32_t)(PERIOD_VALUE / 4)     // 25%
#define  PULSE_VALUE_35   (uint32_t)(PERIOD_VALUE * 0.35)  // 35%
#define  PULSE_VALUE_50   (uint32_t)(PERIOD_VALUE / 2)     // 50%
#define  PULSE_VALUE_75   (uint32_t)(PERIOD_VALUE * 0.75)  // 75%
#define  PULSE_VALUE_90   (uint32_t)(PERIOD_VALUE * 0.90)  // 90%
#define  PULSE_VALUE_95   (uint32_t)(PERIOD_VALUE * 0.95)  // 95%

/* Fan speed values used in control functions - based on duty cycle 0-100. */
#define  FAN_SPEED_OFF    0
#define  FAN_SPEED_LOW    50
#define  FAN_SPEED_MED    75
#define  FAN_SPEED_HIGH   100
/* These fan speeds (PWM values) have been verified for the Sonendo fan
** (4800 max RPM).  To get continuous adjustment between 50% and 75% duty,
** (with the fan maxing out at 75% TEC duty), use formula:
** FD = CD(50%/75%) + 50%.
** Fan is not perfectly linear between duty and RPM, but close enough for us. */
#define  FAN_SPEED_0      0
#define  FAN_SPEED_2000   25
#define  FAN_SPEED_2560   35
#define  FAN_SPEED_3000   47
#define  FAN_SPEED_3230   50
#define  FAN_SPEED_3600   60
#define  FAN_SPEED_3900   65
#define  FAN_SPEED_4000   72
#define  FAN_SPEED_4200   75
#define  FAN_SPEED_4800   100

/* Fan info:
** XYW09225024BH-S-12     : Sonendo outside fan, 4800 max RPM.
** XYW09225024BL-S-12IPX5 : ISC outside fan, 3800 max RPM.
** YW09225024BH-NBP-12    : ISC inside fan, 2800 max RPM.
** Wire connections (for reference):
** Yellow=positive input (24VDC), black=GND, green=tach sense, blue=PWM. */
#define  MAX_RPM_XYW_BH   4800
#define  MAX_RPM_XYW_BL   3800
#define  MAX_RPM_YW_BH    2800

/* For ease of user connection and fan identification, the fans are numbered
** in order as they appear on the PWBA.  Some fan numbers will *not* match
** the PWM channel numbers.  This table correlates fan numbers with the
** associated board reference designator and timer channel:
** FAN #    CONNECT REF. DES.    PWM TMIER CHANNEL
** fan 1    J15                  channel 1  (typically the outside/hot side fan)
** fan 2    J18                  channel 4  (typically the inside/cold side fan)
** fan 3    J16                  channel 2  (RED LED on Sonendo)
** fan 4    J17                  channel 3  (BLUE LED on Sonendo) */
#define  FAN1_CH                 TIM_CHANNEL_1
#define  FAN2_CH                 TIM_CHANNEL_4
#define  FAN3_CH                 TIM_CHANNEL_2
#define  FAN4_CH                 TIM_CHANNEL_3

#define  FAN_START               1
#define  FAN_STOP                2
#define  FAN_WIRE3_NO_ERR        3        // 3 wire fan, pwm only, no error detection
#define  FAN_WIRE4_NO_ERR        4        // 4 wire fan, tach + pwm, no error detect
#define  FAN_WIRE4_ERRORS        5        // 4 wire fan, tack + pwm, with errors (same as default)

/* For PID calculations: */
#define  PID_ERROR_VALUE_MIN     0.1f     // min error value for PID
#define  ITERM_MAX               100.0f   // max I term accumulated value
#define  ITERM_MIN               -100.0f  // min I term accumulated value
#define  PID_OUT_MAX             100.0f   // normalized, scaled value???
#define  PID_OUT_MIN             0.0f     // normalized, scaled value??
#define  DEADTIME_MAX            12       // time spent in deadband (max)
#define  FLOAT_EPSILON           0.0001f  // allowed difference for float equality
#define  MIN_SWITCH_CNT          12       // min counts allowed before heat/cool mode switch
#define  INIT_PID_VALS           0        // flag for pid_value_init()
#define  RESET_ERROR_SUM         1        // flag for pid_value_init()

typedef enum  heat_cool_define_values
{
  NO_HEAT_NO_COOL,    // not heating or cooling
  COOL,
  HEAT,
  NOT_USED            // function ID to indicate value not needed
} heat_cool_t;

typedef enum  PID_ID_values_for_cool_and_heat
{
  PGAIN_COOL,  // identifiers for the pid struct below...
  IGAIN_COOL,
  DGAIN_COOL,
  PGAIN_HEAT,
  IGAIN_HEAT,
  DGAIN_HEAT,
  KI_VAL,
  KPKI_VAL
} pid_value_id_t;

typedef struct  PID_values_for_cool_and_heat
{
  F32          p_gain_cool;   // P gain value, cooling
  F32          i_gain_cool;   // I gain value, cooling
  F32          d_gain_cool;   // D gain value, cooling
  F32          p_gain_heat;   // P gain value, heating
  F32          i_gain_heat;   // I gain value, heating
  F32          d_gain_heat;   // D gain value, heating
  F32          KI_term;       // accumulated I term from the PID calculations
  F32          KP_KI;         // accumulated P + I terms from the PID calcs
} pid_values_t;

typedef enum  PID_ID_values_for_timing_and_mode_and_pwm
{
  GET_PID_TIMER,  // identifiers for the pid struct below and pid_vals() func.
  SET_PID_TIMER,
  GET_HC_MODE,
  SET_HC_MODE,
  GET_PWM_VAL,
  SET_PWM_VAL
} pid_misc_id_t;

typedef struct  PID_values_for_timing_and_mode_and_pwm
{
  U32          timer_cnt;     // tracks the time in heat/cool/deadband modes
  heat_cool_t  in_mode;       // mode that the PID algorithm is in
  U8           pwm_val;       // duty cycle value, 0-100%
} pid_misc_t;

typedef enum  setpoint_value_identifier_enums
{
  SPH_C,                 // setpoint high C
  SPH_F,                 // setpoint high F
  SPL_C,                 // setpoint low C
  SPL_F                  // setpoint low F
} sp_id_t;

typedef struct  high_and_low_setpoint_values
{
  F32     high_c;        // high setpoint, degrees C
  F32     high_f;        // high setpoint, degrees F
  F32     low_c;         // low setpoint, degrees C
  F32     low_f;         // low setpoint, degrees F
} setpoint_t;

typedef struct  fan_tachometer_values_for_rpm_computing
{
  U32     in_capture1;   // first input capture value
  U32     in_capture2;   // second input capture value
  U32     diff_capture;  // difference value (in_cap2 - in_cap1)
  U32     rpm_tach;      // computed fan tach RPM value
  U16     capture_idx;   // input capture index (1 or 2)
} fan_ic_values_t;

typedef enum  get_or_set_or_update_actions_for_various_functions
{
  SETUP_VAL,             // init or setup the function
  UPDATE_VAL,            // perform the update action
  RETRIEVE_VAL           // just get value, without modifing it
} action_t;

/* Function prototypes from fans.c. */
void  MX_TIM1_Init( void );  // Fans pwm
void  MX_TIM3_Init( void );  // Fans tach input
void  fan_ctrl( U32 channel, U8 speed );
void  set_fan_duty_cycle( U32 channel, U8 pwm_drive );
void  fan_init( void );
U16   get_fan_tach( U8 fan );
void  fan_start_stop( U8 fan_on_off, U32 channel );
void  fan_sonendo_ctrl( U8 TEC_duty );
void  fan_isc_ctrl( F32 sph, F32 spl, F32 sensor );
void  check_fan_error( void );

/* Function prototypes from pid_ctrl.c. */
void  MX_TIM2_Init( void );  // TEC pwm
void  HAL_TIM_IC_CaptureCallback( TIM_HandleTypeDef *htim );
void  init_pwm_values( void );
void  set_tec_duty_cycle( U8 pwm_drive );
void  tec_drivers_init( void );
void  tec_ctrl( heat_cool_t x );
F32   pid_terms( F32, pid_value_id_t id, get_set_access_t );
void  set_real_data( F32 real_val, U16 ee_address );
void  pid_value_init( U8 );
void  pid_calc( F32 sph, F32 spl, F32 sensor );
U8    adjust_tec_pwm( F32 error );
F32   rate_of_cooling( F32 sensor_now, action_t act );
F32   get_real_data( U16 ee_parm_adrs, F32 default_val );
void  set_sp_value( F32 val, sp_id_t id );
F32   get_sp_value( sp_id_t id );
void  sp_value_init( void );
U8    tec_pwm_runaway_check( F32 error_temp );
void  pid_vals( U32 * t_cnt, U8 * pwm, heat_cool_t * hc, pid_misc_id_t id );
U8    deadband_mode( F32 sph, F32 spl, F32 sensor );
U8    adjust_tec_pwm_deadband_mode( F32 error );

/* Needed to eliminate warning for timer init functions, even though function
** is in xx_hal_msp.c. TODO: re-visit this issue! */
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

#endif  /* pwm_h_ */

/* pwm.h **************************************************************** EOF */
