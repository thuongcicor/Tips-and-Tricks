/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    adc.h
**
** Description: Defines and function prototypes associated with the internal
**              analog-to-digital converter (ADC).
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef adc_h_
#define adc_h_

#define  ANALOG_REF_VOLTS            3.0f

/* Temperature defines and conversion factors.
** NOTE: See config.h for thermistor beta default value. */
#define  KELVIN_CONVERT_FACTOR       273.15f
#define  T1                          (25 + KELVIN_CONVERT_FACTOR)
/* The value of the resistor divider for the thermistor op-amp input circuit,
** and the calculated op-amp gain value (from the 221-0144 hardware): */
#define  RES_DIVIDE                  5000.0f  // 4.99K resistor + 10 ohm
#define  OP_AMP_GAIN                 1.6035f  // op-amp gain value (1.6035 ideal)
#define  ADC_TOTAL_CHANNELS          10       // 4 thermistor + 4 voltage +
                                              // internal ref voltage and temp.

/* The special analog function pins for the ADC inputs are configured in the
** stm32f0xx_hal_msp.c module.  For ease of user connection and identification,
** thermistors are numbered from 1 to 4, corresponding to ADC channels 0 to 3.
** Some confusion exists on schematic rev. 2.0, due to Tony's labels, but the
** table below should help correlate thermistors and associated board reference
** designators.
**  PORT   CHANNEL    SCHEMATIC NAME and DESCRIPTION  REF. DES. or TEST POINT
**  PA0    ADC_IN0    ADC_THM0, control thermistor    J11 (use as therm. #1)
**  PA1    ADC_IN1    ADC_THM1, spare thermistor 3    J12 (use as therm. #2)
**  PA2    ADC_IN2    ADC_THM2, spare thermistor 1    J13 (use as therm. #3)
**  PA3    ADC_IN3    ADC_THM3, spare thermistor 2    J14 (use as therm. #4)
**  PA4    ADC_IN4    ADC_IN0, 24VDC monitor          no connector, (TP91)
**  PA5    ADC_IN5    ADC_IN1, 12VDC monitor          no connector, (TP94)
**  PA6    ADC_IN6    ADC_IN2, 3.3VDC monitor         no connector, (TP97)
**  PA7    ADC_IN7    ADC_IN3, 3.0VDC monitor         no connector, (TP100)
**
** Also, there are two internal ADC channels for the VREFINT and TEMPSENSOR.
** No external pins, but they will be used on the same ADC instance.
** The list of adc array positions and what adc channel they hold:
** ADC array[0] - ADC_IN0, control thermistor.
** ADC array[1] - ADC_IN1, thermistor, spare.
** ADC array[2] - ADC_IN2, thermistor, spare.
** ADC array[3] - ADC_IN3, thermistor, spare.
** ADC array[4] - ADC_IN4, voltage monitor, 24VDC.
** ADC array[5] - ADC_IN5, voltage monitor, 12VDC.
** ADC array[6] - ADC_IN6, voltage monitor, 3.3VDC.
** ADC array[7] - ADC_IN7, voltage monitor, 3.0VDC.
** ADC array[8] - ADC_CHANNEL_16, internal STM32F0 temperature sensor.
** ADC array[9] - ADC_CHANNEL_17, internal STM32F0 voltage reference.  */

/*
** STM32F071x storage locations for the internal voltage reference and
** internal calilbration temperature. */
#define VREFINT_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFFF7BA))  // voltage ref
#define TEMP30_CAL_ADDR  ((uint16_t*) ((uint32_t) 0x1FFFF7B8))  // 30C ref temp
#define TEMP110_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFFF7C2))  // 110C ref temp
#define VDD_CALIB        ((uint16_t)  (330))
#define VDD_APPLI        ((uint16_t)  (300))

/*
** Max ADC count value is FFFh = 4095.  The MAX_TOTAL_ADC value is the maximum
** sum of array of 32 count values.  (32 * 4095 = 131,040).  */
#define  MAX_FULL_SCALE   4095U     // 0xFFF for a 12-bit ADC
#define  MAX_TOTAL_ADC    (ADC_SAMPLES * MAX_ADC_VALUE)

/* NOTE: ONLY SET *ONE* LINE BELOW TO 1 TO SELECT ADC INPUT ARRAY SIZE. */
#define ADC_ARRAY_SIZE_IS_4   (0)
#define ADC_ARRAY_SIZE_IS_8   (0)
#define ADC_ARRAY_SIZE_IS_16  (0)
#define ADC_ARRAY_SIZE_IS_32  (1)  // 32 samples selected
/* NOTE: ONLY SET *ONE* LINE ABOVE TO 1 TO SELECT ADC INPUT ARRAY SIZE. */

#if (ADC_ARRAY_SIZE_IS_4)
#define  SHIFT_DIVIDE        2  // right shift 2 for divide by 4
#endif

#if (ADC_ARRAY_SIZE_IS_8)
#define  SHIFT_DIVIDE        3  // right shift 3 for divide by 8
#endif

#if (ADC_ARRAY_SIZE_IS_16)
#define  SHIFT_DIVIDE        4  // right shift 4 for divide by 16
#endif

#if (ADC_ARRAY_SIZE_IS_32)
#define  SHIFT_DIVIDE        5  // right shift 5 for divide by 32
#endif

#define  ADC_ARRAY_SIZE      (1 << SHIFT_DIVIDE)
#define  ADC_ARRAY_TOP       (ADC_ARRAY_SIZE - 1)

#define  UPPER_TEMP_LIMIT    999.0   // value indicates shorted thermistor
#define  LOWER_TEMP_LIMIT    -99.0   // value indicates unplugged thermistor
#define  ADC_SHORT_ERROR     10      // counts of 10 or less are considered shorts
#define  ADC_MIN_VALID       39      // minimum valid ADC value for temperatures??
#define  ADC_MAX_VALID       4000U   // maximum valid ADC value for temperatures??
#define  ADC_OPEN_ERROR      4050U   // ADC counts of 4050 or more are considered open??
#define  DEGREES_C           0       // flag for reading temperature in C
#define  DEGREES_F           1       // flag for reading temperature in F
#define  F_to_C              0       // flag to convert from F to C
#define  C_to_F              1       // flag to convert from C to F
#define  X_1                 1       // flag indicates temp values are X1 (times 1)
#define  X_10                10      // flag indicates temp values are x10 (times 10)

typedef enum  errors_for_adc_readings
{
  NOT_VALID,   // counts in short or open range, but not enough yet for error
  ADC_OK,      // counts in valid range (not defined yet??)
  SHORT,       // counts below ADC_SHORT_ERROR is a short-circuit condition
  TOO_HIGH,    // counts between ADC_SHORT_ERROR and ADC_MIN_VALID??
  TOO_LOW,     // counts between ADC_MAX_VALID?? and ADC_OPEN_ERROR
  OPEN         // counts above ADC_OPEN_ERROR is an open-circuit condition
}  adc_error_t;

/* Keep the task sequence items in sequential order for update_adc_events(). */
typedef enum  sequence_values_for_adc_events
{
  ADC_SEQUENCE_CONFIG_CHANNEL,  // select the channel to read data from
  ADC_SEQUENCE_START,           // starts the conversion on selected channel
  ADC_SEQUENCE_GET_VALUE,       // gets converted value
  ADC_SEQUENCE_STOP,            // stops conversion after getting value
  ADC_SEQUENCE_NEXT_CHANNEL,    // select the next ADC channel to convert
  ADC_SEQUENCE_END              // always the last item
}  adc_task_seq_t;

/* Use a signed value for the ADC_total member so that we can check for
** negative totals (an error condition).
** The ADC channel number will be stored separately, and used as an index into
** this control structure. */
typedef struct adc_values_averages_totals_errors
{
  S32  ADC_total;               // holds total of all sampled values
  U32  ADC_in[ADC_ARRAY_SIZE];  // input ADC sample array
  U16  ADC_avg;                 // time filtered and averaged ADC value
  F32  temp_C;                  // temperature in C from averaged value
  F32  temp_F;                  // temperature in F from averaged value
  U8   idx;                     // array index for ADC_in[]
  U8   circuit_open;            // number open-circuit error conditions detected
  U8   circuit_short;           // number short-circuit error conditions detected
  adc_error_t     errors;       // errors: too low, too high, open or short
  adc_task_seq_t  sequence;     // sequence of events placeholder
}  adc_control_t;

/*******************************************************************************
** function prototypes - adc.c
*******************************************************************************/
static void MX_ADC_Init( void );
void  adc_init( void );
void  adc_cal( void );
void  adc_start( void );
U16   adc_get_val( void );
void  adc_stop( U32 channel );
void  adc_config_channel( U32 channel, BOOL enable );
void  adc_update_averages( void );
float  modified_steinhart_hart( U16 adc_count_val );
void  update_adc_events( void );
F32   get_current_temperature( U8 channel, U8 units );
U16   get_current_adc_counts( U8 channel );
U16   compute_average( U16 new_data );
void  init_adc_temp_values( void );
S32  get_stm32_internal_temp( void );

#endif  /* adc_h_ */

/* adc.h **************************************************************** EOF */
