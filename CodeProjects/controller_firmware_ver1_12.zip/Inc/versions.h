/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    versions.h
**
** Description: Firmware version info, and revision history.
**              VERSION CONTROL NOTE: Once the released version source is
**              archived/copied/put into the VCS, then remember to bump up the
**              version number before any future mods are done!
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   02/08/2019  See comments below and the release_notes.txt file for
**           change history and more details.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef versions_h_
#define versions_h_

/* NOTE:  ALWAYS PERFORM A "REBUILD ALL" TO INCLUDE THE LATEST VERSION NUMS. */

#define  HEX_FILE_NAME      ISC_??   // hex output file name TBD...
/* Note that major and minor verison numbers are limited to 255 max. value.
** These firmware version numbers will also be used for the EEPROM version.
** Major number = 0 for pre-release or test versions.  */
#define  MAJOR_VER_NUM      1        // major firmware/EE version number
#define  NUM_SEPARATOR      .
#define  MINOR_VER_NUM      12       // minor firmware/EE version number

#define  str_(s)   str__(s)          // preprocessor stringificaiton part 1
#define  str__(s)  #s                // preprocessor stringification part 2

/*
** Release notes:
**
** Version 1.12:  09-05-2019:
** * Mod for PI cooling values; 16.2 and 0.6.
** * Mod comm protocol to eliminate auto-respond with the full menu if an
**   unrecognized command is received.
** * Add the hidden serial commands "?" and "help" to print out the menu.
** * Fan mods; limit max speed (Sonendo) to about 4000 RPM.  Just 3 speeds.
** * In fan tach calculations, limit RPM to 4800, throwing out noise values.
** * Limit TEC to 95% power, to reduce noise on fan tach line.
**
** Version 1.11:  06-13-2019:
** Turn fan off on error or stop command for Sonendo.
** Add fan setup config to EE values.
** Sonendo prop band default value changed from 3.0 to 4.0.
**
** Version 1.10:  03-20-2019:
** This version is release to VN for flashing the 221-0144-009 controllers.
** These will be used both for Sonendo and ISC. Changes were made to the modes
** (in ISC operation), so that the display shows the correct SPH, SPL and
** current temperature in both C and F, and the conversions are accurate.  Mods
** made to the ISC "Deadband" mode.
**
** Version 1.9:
** This version was used for internal Marlow testing and was never released.
**
** Version 1.8 - 02-11-2019:
** Added a PID runaway check, to avoid losing control due to fast temperature
** transients (see notes in pid_ctrl.c).  Fixed the restore defaults command
** for pre-loading the proper config parms. Also fixed most post-increment
** operators to pre-increment due to bug (could this be an IAR compile issue)?
** This was seen in the index variable in check_fan_error().
** Official release version for Sonendo project.
**
** Version 1.7 - 02-01-2019:
** Used for internal Marlow testing.  Mainly to verify the effectiveness of the
** updated PID control algorithm, with the proportional/hysteresis band.  Also
** made some bug fixes related to F-C/C-F conversions in different modes.
**
** Version 1.6 - 01-22-2019:
** This version is used to test the new hardware (rev. 3 boards), but using
** essentially the same firmware from ver. 1.5.  This is just an internal
** Marlow test version. UPDATE - turns out we needed version 1.4 as a baseline.
**
** Version 1.5 - 12/10/2018
** Separated PWM/TEC functions for ISC and Sonendo.  This is just an early test
** version for M. Ward to do some development for his control/monitor program.
**
** Version 1.4 - 09/25/2018
** Added code for factory test.  Separated the key functions and LED functions.
** Mods to key events to detect the PWR & SET combination to initiate the test
** functions.  Added serial command to output "assemblies" of data.
** TODO:  still need to impliment "reset defaults".
**
** Version 1.3 - 08/15/2018
** Added code for the user interface to handle the manual start-up mode.  Also
** corrected the PWR/ON/OFF button operation.  Fixed bug when temperature
** adjust goes from a 3-digit value to a 2-digit value.  Fixed bug in PID for
** I gain calculations.
**
** Version 1.2 - 08/01/2018
** Various tweaks to the PID algorithm for Sonendo.  Add over/under voltage
** alarm.
**
** Version 1.1 - 07/31/2018
** For the first prototype units sent to Sonendo.
** beta 3450, pid-cool 268.6, 0.011, pid-heat 107.44, 0.004
** sph = spl = 27C.
** Jumper on position 1, J8.
**
** Version 1.00 - 07/30/2018
** For the first shipped units to ISC.  Set the following defaults via CLI:
** beta 3600, pid-cool 100.0, 0.4, pid-heat 50.0, 0.25
** SPH 86F, SPL 50F, t_units F
** no jumpers on J8
**
** Version 0.40 - 07/19/2018
** Pre-release alpha test version, used for EMI pre-compliance.  It will just
** run with a fixed resistor in place of the thermistor so that the TECs will
** be on continuously.
**
** Version 0.44 - 7/26/2018
** First version for Steve's chamber temperature validation test.
**
*/

#endif  /* versions_h_ */

/* versions.h *********************************************************** EOF */
