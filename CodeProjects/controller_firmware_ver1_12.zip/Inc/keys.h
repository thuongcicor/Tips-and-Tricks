/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    keys.h
**
** Description: General project defines and generic structure templates.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef keys_h_
#define keys_h_

/* Pushbutton (key) values:
** Fixed values used for array offsets. */
#define  PB_PWR                    0   // (MEMB_PWR_SW_Pin) - power (ON/OFF) button
#define  PB_SET                    1   // (MEMB_SET_SW_Pin) - set button
#define  PB_DOWN                   2   // (MEMB_D_ARR_SW_Pin) - down button
#define  PB_UP                     3   // (MEMB_U_ARR_SW_Pin) - up button
#define  NUM_PB                    4   // number of pushbutton switches
#define  PB_ALL                    5   // flag indicates to include all pushbuttons
#define  PB_SET_DONE               6   // flag indicates pb action has completed
#define  MANUAL_NO_KEYS_ALLOWED    7
#define  MANUAL_ALL_KEYS_ALLOWED   8
#define  MANUAL_SET_KEY_ALLOWED    9
#define  MANUAL_PWR_KEY_ALLOWED    10
#define  KEY_TIMEOUT               21000U  // 21 seconds to wait for keypress

/* Pushbutton switch debounce:
** Debounce on both push and release portions of the actuation.
** Each individual switch is called ~ every 4mSecs, and the count gives a
** debounce time of approx. DEBOUNCE_COUNT * 4mSec. */
#define  DEBOUNCE_COUNT    12
#define  TEST_MODE_COUNT   10
#define  MAX_PB_HOLD_TIME  500
#define  SW_ID_ERROR       99    // error, not a legal switch number (0-3)

typedef enum pushbutton_status
{
  PRESSED,
  RELEASED,
  HELD
} pb_status_t;

typedef enum pushbutton_modes
{
  READY,       // pushbutton is ready for action
  NOT_READY,   // pushbutton not active at this time (temporarily disabled)
  IN_PROCESS   // pushbutton action initiated but not completed
} pb_mode_t;

typedef struct  pushbutton_modes_and_states_and_timings
{
  pb_status_t    state[NUM_PB];   // Pressed or Not Pressed
  pb_mode_t      mode[NUM_PB];    // ready, not ready, or in-process
  U8             ID;              // pushbutton ID that initiated action
  U8             manual_keys;     // identifies which keyss are allowed in manual mode
  U16            hold[NUM_PB];    // see note below...
  U16            key_timeout;     // holds the key timeout countdown value
} pb_struct_t;

/* NOTE: The pushbutton hold time is used to keep track of the total time a key
** is pressed.  It can be used for a repeating key function.  Also, for funcs
** that look for multiple key presses, since this will track even after the
** primary function is in process. */

/*******************************************************************************
** function prototypes
*******************************************************************************/
U8    debounce_switch( U8 sw_id );
void  update_pb_events( void );
void  keypress_actions( U8 key );
void  key_timeout_check( void );
U8    get_pushbutton_id( void );
pb_mode_t  get_pushbutton_mode( U8 key );
void  pb_init( U8 x );
void  pb_clr_timeout( void );
void  set_manual_entry_keys( U8 mankey );
U8    get_manual_entry_keys( void );

#endif  /* keys_h_ */

/* keys.h *************************************************************** EOF */
