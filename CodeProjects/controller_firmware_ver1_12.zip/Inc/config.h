/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    config.h
**
** Description: Project defines and default values for all user-configurable
**              parameters and limits, ranges, and allowed variables.
**
** Version/Author/Date/Description:
** 1   DMA   06/13/2018  Began coding.
** 2   DMA   01/13/2019  Switched some temperature limits from ints to real.
**                       Separated the ISC defaults from the Sonendo defaults.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef config_h_
#define config_h_

/*******************************************************************************
** Jumper setting configurations:
** The dual row header (J8) next to the STM32 processor is used to configure
** the board for different applications.
** 00000 - No jumpers installed - default for ISC operation. Two fans, one
**         control thermistor, LCD 16X2 display, membrane keypad.  Use high/low
**         setpoints w/deadband.
** 00001 - Default Sonendo app - uses FANS 3 & 4 for LEDs and FAN 1 for hot side
**         TEC fan. No display or keypad.  One setpoint, no deadband, normal PID
**         (PI) control.
** 00010 - mode aaa. (TBD)
** 00011 - mode bbb. (TBD)
**
** DON'T WANT TO MAKE THE PRODUCT DEFINES CUSTOMER SPECIFIC, BUT FOR NOW....
**
*******************************************************************************/
#define  ISC_CONTROL          0x00
#define  SONENDO_CONTROL      0x01

/*******************************************************************************
** For the upper setpoint (SPH), user can enter values from a high value of
** USER_TEMP_MAX_ down to USER_TEMP_SPH_MIN_.
** For the lower setpoint (SPL), user can enter values from a high value of
** USER_TEMP_SPL_MAX_ down to USER_TEMP_MIN_.
** There is an intentional gap between the lowest upper setpoint value and the
** highest lower setpoint value for ISC, (typically 2 degrees).
*******************************************************************************/
/* Sonendo plate temperature should alarm > 40C and < 1C. */
#define  SONENDO_UPPER_ALARM_TEMP_C        41.0f
#define  SONENDO_LOWER_ALARM_TEMP_C        1.0f
/* ISC is spec'd for a max ambient operating temp of 50C and min of 15C.
** Set upper alarm at 55C, and lower alarm at 5C. */
#define  ISC_UPPER_ALARM_TEMP_C            55.0f
#define  ISC_LOWER_ALARM_TEMP_C            5.0f

#define  SONENDO_SPH_UPPER_TEMP_LIMIT_C    39.9f
#define  SONENDO_SPH_LOWER_TEMP_LIMIT_C    0.1f

#define  SONENDO_SPH_UPPER_TEMP_LIMIT_F    104.0f
#define  SONENDO_SPH_LOWER_TEMP_LIMIT_F    32.2f

#define  SONENDO_SPL_UPPER_TEMP_LIMIT_C    10.0f  // prop band value
#define  SONENDO_SPL_LOWER_TEMP_LIMIT_C    0.0f   // prop band value

#define  SONENDO_SPL_UPPER_TEMP_LIMIT_F    20.0f  // prop band value
#define  SONENDO_SPL_LOWER_TEMP_LIMIT_F    0.0f   // prop band value

#define  ISC_SPH_UPPER_TEMP_LIMIT_C        40.0f
#define  ISC_SPH_LOWER_TEMP_LIMIT_C        26.0f

#define  ISC_SPH_UPPER_TEMP_LIMIT_F        104.0f
#define  ISC_SPH_LOWER_TEMP_LIMIT_F        79.0f

#define  ISC_SPL_UPPER_TEMP_LIMIT_C        24.0f
#define  ISC_SPL_LOWER_TEMP_LIMIT_C        4.0f

#define  ISC_SPL_UPPER_TEMP_LIMIT_F        75.0f
#define  ISC_SPL_LOWER_TEMP_LIMIT_F        40.0f

/*******************************************************************************
** Error bit definitions.  Also see the Comm Protocol document for more details.
*******************************************************************************/
#define  NO_ERROR_BITS_SET         0x0000  //
#define  TEMP_SENSOR_FAIL          0x0001  // control thermistor 1 fail
#define  TEMP_TOO_LOW              0x0002  // temp below the operational low limit
#define  TEMP_TOO_HIGH             0x0004  // temp above the operational high limit
#define  FAN_1_FAIL                0x0008  // fan#1 had a tach value out-of-bounds
#define  FAN_2_FAIL                0x0010  // fan#2 had a tach value out-of-bounds
#define  FAN_3_FAIL                0x0020  // fan#3 had a tach value out-of-bounds
#define  FAN_4_FAIL                0x0040  // fan#4 had a tach value out-of-bounds
#define  VOLTAGE_24_FAIL           0x0080  // input voltage 24VDC out-of-bounds
#define  VOLTAGE_12_FAIL           0x0100  // internal 12VDC out-of-bounds
#define  VOLTAGE_3_3_FAIL          0x0200  // internal 3.3VDC out-of-bounds
#define  VOLTAGE_3_0_FAIL          0x0400  // internal 3.0VDC out-of-bounds

/* Note: 10.3 is the conversion factor for the 24V input voltage.  See the
** function cmd_voltages in module serial_commands.c., to see where this
** "magic number" is derived. Also note that the voltage upper limit value is
** limited by the hardware on the board - transient protection diodes that will
** start to conduct around 26.5VDC. */
#define  IN_VOLTS_UPPER_LIMIT      (26.5f)        // limited by hardware (see above)
#define  IN_VOLTS_LOWER_LIMIT      (24.0 - 4.8f)  // -20% on the low end
#define  IN_VOLTS_UPPER_COUNTS     ((IN_VOLTS_UPPER_LIMIT * 4095.)/(3.3 * 10.3f))
#define  IN_VOLTS_LOWER_COUNTS     ((IN_VOLTS_LOWER_LIMIT * 4095.)/(3.3 * 10.3f))

#define  BETA_DEFAULT              3190U   // default, thermistor beta (below 25C)
#define  BETA_DEFAULT_2            3330U   // default(2), thermistor beta (>= 25C)
#define  BETA_SONENDO              3450U   // default, sonendo thermistor

/* ISC P, I gain values. */
#define  PGAIN_COOL_ISC_DEFAULT    33.8f
#define  IGAIN_COOL_ISC_DEFAULT    0.38f
#define  PGAIN_HEAT_ISC_DEFAULT    12.2f
#define  IGAIN_HEAT_ISC_DEFAULT    0.155f

/* Sonendo P, I gain values. */
#define  PGAIN_COOL_SEN_DEFAULT    16.2f
#define  IGAIN_COOL_SEN_DEFAULT    0.60f
#define  PGAIN_HEAT_SEN_DEFAULT    4.33f
#define  IGAIN_HEAT_SEN_DEFAULT    0.23f

/* Default setpoints, Sonendo. */
#define  SONENDO_SETPOINT          27.0f   // Sonendo default setpoint, C
#define  SONENDO_SETPOINT_F        80.6f   // Sonendo default setpoint, F
#define  SONENDO_PROP_BAND         4.0f    // proportional band, (spl), C
#define  SONENDO_PROP_BAND_F       7.2f    // proportional band, (spl), F

/* Default setpoints, ISC. */
#define  ISC_SPH                   30.0f   // ISC high setpoint, C
#define  ISC_SPH_F                 86.0f   // ISC high setpoint, F
#define  ISC_SPL                   10.0f   // ISC low setpoint, C
#define  ISC_SPL_F                 50.0f   // ISC low setpoint, F

#define  SONENDO_TEMP_UNITS        DEGREES_C
#define  ISC_TEMP_UNITS            DEGREES_F

#endif  /* config_h_ */

/* config.h ************************************************************* EOF */
