/*******************************************************************************
**
** Project:     II-VI Marlow Compact TE Controller Firmware.
**              Platform: ST Micro STM32F071v8Tx, on the 221-0144 assembly.
**
** Filename:    project.h
**
** Description: General project defines and generic structure templates.
**
** Version/Author/Date/Description:
** 1   DMA   11/13/2017  Began coding.
** 2   DMA   02/04/2019  General updates and various additions.
**
** Marlow Industries Inc., and II-VI Marlow are trademarks of II-VI Incorporated.
** (C) 2018, 2019 II-VI Incorporated.
*******************************************************************************/
#ifndef project_h_
#define project_h_

/*******************************************************************************
** General Definitions - data type definition shortcuts.
*******************************************************************************/
// NOTE: Use the standard "char" data type for all string data.
typedef  uint8_t   U8;    // 8-bit byte and unsigned char
typedef  int8_t    S8;    // 7-bit byte and sign
typedef  uint16_t  U16;   // 16-bit unsigned int
typedef  int16_t   S16;   // 16-bit signed int
typedef  uint32_t  U32;   // 32-bit unsigned long int
typedef  int32_t   S32;   // 32-bit signed long int
typedef  uint64_t  U64;   // 64-bit unsigned long long int
typedef  float     F32;   // 32-bit real (IEEE-754 floating point)

#define  _NOP      __no_operation  // NOP instruction - include "instrinsics.h"

/* Unique 96-bit device ID locations on the STM32F0 part;
** includes X & Y co-ords on the wafer, lot and wafer nums.
** See STM32F07x doc for full detials on how this is encoded. */
#define UID1           ((uint32_t *)0x1FFFF7AC)
#define UID2           ((uint32_t *)0x1FFFF7B0)
#define UID3           ((uint32_t *)0x1FFFF7B4)

/* Flash memory size; STM32F071V8 is 64K, (mem_id = 0x040).
**                    STM32F071VB is 128K, (mem_id = 0x080).  */
#define MEM_ID         ((uint32_t *)0x1FFFF7CC)
/* Option bytes used to lock the flash contents for security. */
#define OPTION_BYTES   ((uint32_t *)0x1FFFF800)

/* Device ID location on the STM32F0; 0x448 for STM32F07x parts. */
#define DEV_ID         ((uint32_t *)0x40015800)

typedef enum stm32f0_on_chip_register_ids_and_other_internal_data
{
  UID01,        // unique ID for x/y location on wafer during manufacture
  UID02,        // unique ID for manufacturing lot number
  UID03,        // unique ID for manufacturing wafer number
  FLASH_M,      // flash memory size
  DEVICE_ID,    // identifier for the STM32F07x device
  INTVREFCAL,   // internal voltage reference, fixed calibration value
  INTVREFDATA,  // internal voltage reference, converted ADC value
  INT30T,       // internal temperature calibration reference (30C)
  INT110T,      // internal temperature calibration reference (110C)
  OPTIONS       // internal option bytes for locking flash contents
} stm32_reg_t;

typedef enum boolean_types
{
  FALSE = 0,    // use this if <stdbool.h> not included...
  TRUE  = 1,
  OFF   = 0,
  ON    = 1,
  NO    = 0,
  YES   = 1,
  PASS  = 0,
  FAIL  = 1
} BOOL, LOGIC;

typedef enum LED_operational_mode_types
{
  LED_ALL_OFF,      // all LEDs off
  LED_OFF,          // individual LED off
  LED_ALL_ON,       // all LEDs on
  LED_ON,           // individual LED on
  LED_SINGLE,       // LED on for x duration, single event
  LED_CONTINUOUS,   // LED on continuously
  LED_BLINK,        // turns LED on/off with on time, off time and repeat sequence
  LED_NOTHING       // do nothing - no count updates or state changes
} led_t;

typedef struct LED_control_struct_variables
{
  led_t    mode;         // LED operation modes or type
  U8       init_1st;     // false 1st time thru mode code, true all other times
  BOOL     state;        // on or off
  U16      counts;       // keeps track of counts for on-off timing
  U16      on_counts;    // timing counts for beeper on state
  U16      off_counts;   // timing counts for beeper off state
  U8       cycle;        // counts the on-off cycles (sequence)
  U8       repeat;       // number of times to repeat on-off sequence
} led_struct_t;

typedef enum init_task_defines_for_the_initialization_loop
{
  INIT_LCD_INIT_TASK,             // LCD module init
  INIT_LCD_CUSTOM_TASK,           // LCD custom icons, images setup
  INIT_LCD_SPLASH_TASK,           // LCD splash screen task
  INIT_ADC_CAL_TASK,              // ADC calibration task
//  INIT_BEEPER_TASK,               // audio/beeper init task
  INIT_LED_ONB_RED_TASK,          // on-board red LED init
  INIT_LED_ONB_RED_CONT_TASK,     // continuation of task until timed out
  INIT_LED_ONB_WHITE_TASK,        // on-board white LED init
  INIT_LED_ONB_WHITE_CONT_TASK,   // continuation of task until timed out
  INIT_LED_MEMB_RED_TASK,         // membrane red LED init
  INIT_LED_MEMB_RED_CONT_TASK,    // continuation of task until timed out
  INIT_LED_MEMB_GREEN_TASK,       // membrane green LED task
  INIT_LED_MEMB_GREEN_CONT_TASK,  // continuation of task until timed out
  INIT_LED_MEMB_BLUE_TASK,        // membrane blue LED task
  INIT_LED_MEMB_BLUE_CONT_TASK,   // continuation of task until timed out
  INIT_TASKS_COMPLETE
} init_tasks_t;

typedef enum  list_of_all_menu_states_and_display_modes_
{
  NORM_OP_SCREEN,      // normal operation screen
  SET_TO_START,        // Press [SET] to start (in manual mode)
  MENU_1,              // level 1, menu 1: setpoint high user entry mode
  MENU_2,              // level 1, menu 2: setpoint low user entry mode
  MENU_3,              // level 1, menu 3: temperature units, C or F, user entry mode
  MENU_4,              // level 1, menu 4: operating mode, auto or manual start, user entry mode
  MENU_21,             // level 2, menu 1: setpoint high adjust values
  MENU_22,             // level 2, menu 2: setpoint low adjust values
  MENU_23,             // level 2, menu 3: temperature units selection, C or F
  MENU_24,             // level 2, menu 4: auto/manual selection
  MENU_NONE,           // used in function to indicate value is not needed
  LAST_MENU_ITEM       // end of menu states list (always the last item)
} menu_states_t;

typedef enum  list_of_operational_states_and_control_modes_
{
  PWR_OFF_MODE,        // turns LCD, LEDs, Fans and TEC off
  INIT_MODE,           // initialization mode - right after power-on/reset
  COOL_MODE,           // unit is in active cooling - TEC on for PWM > 0
  HEAT_MODE,           // unit is in active heating - TEC on for PWM > 0
  DEADBAND_MODE,       // unit is in the deadband region - TEC is off
  STOP_MODE,           // STOP command was sent - no TEC PWM control
  RUN_MODE,            // RUN command was sent - resume normal operation
  TEST_MODE_ACTIVE,    // manufacture test or EOL test mode (active)
  TEST_MODE_PASS,      // EOL test mode has completed - PASS
  TEST_MODE_FAIL,      // EOL test mode has completed - FAIL
  ERROR_MODE,          // an error condition exists that stops normal operation
  NONE                 // used in function to indicate value is not needed
} op_ctrl_states_t;

typedef enum  list_of_operational_parameters_and_controls_
{
  TEMP_UNITS,          // temperature units; 0 = degrees C, 1 = degrees F
  START_MODE,          // auto start mode or manual start mode
  THERM_BETA,          // thermistor beta value
  misc_parm_code,      //
  LAST_PARM_ITEM       // (always the last item)
} op_ctrl_parms_t;

typedef enum  list_of_levels_in_menu_modes_and_operational_modes_etc
{
  SKIP_LEVEL,          // flag used to skip setting or getting values
  LEVEL_0,             // default mode - for idle and initialize
  LEVEL_1,             // first menu level entry
  LEVEL_2,             // 2nd menu levels - get here from 1st level
  LEVEL_3,             // 3rd menu levels - get here from 2nd level
  LAST_LEVEL_ITEM      // end of levels list (always the last item)
} mode_level_t;

typedef enum  list_of_menu_adjustment_controls_and_commands
{
  LOAD_SPH_VALUE,
  LOAD_SPL_VALUE,
  SAVE_DEGREE_C_VALUE_SPH,
  SAVE_DEGREE_C_VALUE_SPL,
  SAVE_DEGREE_F_VALUE_SPH,
  SAVE_DEGREE_F_VALUE_SPL,
  LAST_MENU_ADJ_ITEM   // end of menu adjustment commands (always the last item)
} menu_adj_cmnds_t;

typedef struct  control_operational_modes_parameters_menus_etc
{
  U8                board_cfg;   // board configuration from J8 jumper setting
  menu_states_t     menu_mode;   // current menu state/display mode
  op_ctrl_states_t  ctrl_mode;   // current operational state/mode
  op_ctrl_states_t  tout_mode;   // mode to got to when a timeout occurs
  mode_level_t      menu_level;  // display menu level
  mode_level_t      tout_level;  // level to go to when a timeout occurs
} control_struct_t;

typedef struct  control_variables_to_traverse_menu_state_table
{
  menu_states_t  st_now;         // current menu state
  U8   pb_in;                    // pushbutton input
  void ( *menu_fptr ) ( void );  // menu commands function pointer
} menu_struct_t;

typedef struct  menu_variables_to_manipulate_during_adjustments
{
  U16  spC;         // int setpoint, degrees C, (for menu adjust)
  U16  spF;         // int setpoint, degrees F, (for menu adjust)
  U8   tempUnit;    // temperature units, C=0, or F=1
} menu_adjust_vars_t;

typedef enum  list_of_all_user_defined_timed_task_events
{
  NO_OWNER = 0,           // default (0 - always the first item)
  PB_TIME,                // pushbutton debounce timer, typically about 50mSec
  PROCESS_TIME_PWR_KEY,   // timer ID for the next PWR key action allowed
  PROCESS_TIME_SET_KEY,   // timer ID for the next SET key action allowed
  PROCESS_TIME_DOWN_KEY,  // timer ID for the next DOWN key action allowed
  PROCESS_TIME_UP_KEY,    // timer ID for the next UP key action allowed
  FAN1_TACH_IC_INTR,      // timer for fan 1 tach input capture interrupt occurs
  FAN2_TACH_IC_INTR,      // timer for fan 2 tach input capture interrupt occurs
  BEEPER,                 // audio indicator (beeper) timing
  LCD_BUSY,               // display busy timer, keep updates from overwriting
  END_OF_OWNERS           // end of user event "owner" list (always the last item)
} task_owner_t;

typedef enum  list_of_timer_types_for_owner_defined_timed_events
{
  ONE_SHOT,            // used for a single, one-time event
  PERIODIC             // used for a continuous, re-occurring event
} timer_type_t;

typedef struct  task_timer_record_keeping_parameters
{
  BOOL           start;     // TRUE when timer has started
  BOOL           done;      // TRUE when timed event has completed
  U16            value;     // mSec load value (timed events up to 65.5 seconds)
  U16            cnt_down;  // current count, counting down from .value
  timer_type_t   type;      // ONE_SHOT or PERIODIC
} timer_params_t;

typedef struct  tec_control_variables
{
  U16  on_time;             // time TEC is powered (in seconds)
  U16  off_time;            // time TEC has been off/not powered - max 18 hours; just leave at max if more.
  U8   mode;                // cool or heat
} tec_control_t;

typedef enum  output_debug_print_options_conversion_options
{
  OPTIONS_NONE,        // no additonal options
  DECIMAL_PT,          // include decimal point (scaled int conversion)
  NO_DECIMAL_PT,       // don't include decimal point (scaled int convert)
  LEADING_0,           // include leading 0's
  LEADING_SPACES,      // include leading ' ' (spaces)
  NO_SPACE_OR_0,       // don't include any leading spaces or 0's
  ADD_CRLF,            // add carriage return, line feed
  ADD_COMMA,           // add comma to end of output string
  NO_CRLF              // don't add cr, lf
} dbug_print_options_t;

typedef enum  circular_buffer_function_options_and_flags
{
  IN_BUF,              // flag for the input buffer
  OUT_BUF,             // flag for the output buffer
  DEBUG_TAIL_PTR       // debug print tail pointer???
} circ_buf_t;

typedef enum  system_reset_options_and_flags
{
  START,               // flag to start the system reset operation
  CHECK_STATUS,        // flag to check status for system reset
  END_OF_OPTIONS
} reset_options_t;

typedef enum  error_bit_clear_set_commands
{
  SET_ERROR_BIT,       // set a single error bit
  CLR_ERROR_BIT,       // clear a single error bit
  CLR_ALL_ERROR_BITS
} error_bit_t;

typedef enum  debug_output_pin_flags
{
  OUTPUT_HIGH,         // set debug output pin logic level high
  OUTPUT_LOW,          // set debug output pin logic level low
  TOGGLE_OUTPUT        // toggle the debug output pin
} debug_pin_t;

typedef enum  get_and_set_access_defines
{
  GET_DATA,            // flag indicates "get a value" from the function
  SET_DATA,            // flag indicates "set a value" in the function
  GET_SET_DATA         // allow both get and set access
} get_set_access_t;

/* Manual mode turns everything off.  Press the ON/OFF button to toggle between
** auto and manual mode startup options. */
#define  AUTO_MODE               0  // unit will auto start
#define  MANUAL_MODE             1  // user must push on/off to start unit
#define  MANUAL_MODE_PROCEED     2  // user started unit in manual mode
#define  AUTO_MODE_PWR_DOWN      3  // user pressed on/off in auto mode

/*******************************************************************************
** bit manipulations
*******************************************************************************/
#define BOOL(x)             (!(!(x)))  // produces either a 0 or 1 for any x
#define BitSet(arg, posn)   ((arg) |= (1 << (posn)))
#define BitClr(arg, posn)   ((arg) &= ~(1 << (posn)))
#define BitTest(arg, posn)  BOOL((arg) & (1 << (posn)))
#define BitFlip(arg, posn)  ((arg) ^ (1 << (posn)))
#define BIT(posn)           (0x01 << (posn))

/*******************************************************************************
** 16/8 bit integer/byte manipulations
*******************************************************************************/
#define HIBYTE(Data2Convert)      ((U8)((Data2Convert >> 8) & 0xFF))
#define LOBYTE(Data2Convert)      ((U8)(Data2Convert & 0xFF))
#define SWAP_BYTES(word)          ((U16)((word << 8) | (word >> 8)))

#define ABS_DIFF(argx, argy) (argx > argy ? argx - argy : argy - argx)

#define SUCCESS     0     // for return code - FAIL can be any non-zero value

#define FOREVER     0xFF  //  for LED parameter, means "goes on indefinitely"
#define SP_HIGH     1     // identifier for SPH, used in convert function
#define SP_LOW      2     // identifier for SPL, used in convert function

#define BIT0_POS    0     // bit 0 position (least significant bit position)
#define BIT1_POS    1     // bit 1 position
#define BIT2_POS    2     // bit 2 position
#define BIT3_POS    3     // bit 3 position
#define BIT4_POS    4     // bit 4 position
#define BIT5_POS    5     // bit 5 position
#define BIT6_POS    6     // bit 6 position
#define BIT7_POS    7     // bit 7 position (most significant bit position)

#define BIT0_MASK   (1 << BIT0_POS)      // b00000001, 0x01
#define BIT1_MASK   (1 << BIT1_POS)      // b00000010, 0x02
#define BIT2_MASK   (1 << BIT2_POS)      // b00000100, 0x04
#define BIT3_MASK   (1 << BIT3_POS)      // b00001000, 0x08
#define BIT4_MASK   (1 << BIT4_POS)      // b00010000, 0x10
#define BIT5_MASK   (1 << BIT5_POS)      // b00100000, 0x20
#define BIT6_MASK   (1 << BIT6_POS)      // b01000000, 0x40
#define BIT7_MASK   (1 << BIT7_POS)      // b10000000, 0x80

/*******************************************************************************
** Delay values used for audio/buzzer timing. We need to produce frequencies
** from 1000Hz to 3200Hz (1mSec to 312.5uSec).  The *4 value was derived from
** scope measurements - see function small_delay().
*******************************************************************************/
#define  DELAY_1000uSEC   250U    // 1000uSeconds (250 * 4)  1000Hz
#define  DELAY_760uSEC    190U    // 760uSeconds (190 * 4)   1315Hz
#define  DELAY_500uSEC    125U    // 500uSeconds (125 * 4)   2000Hz
#define  DELAY_400uSEC    100U    // 400uSeconds (100 * 4)   2500Hz
#define  DELAY_312uSEC     78U    // 312uSeconds (78 * 4)    3200Hz

/*******************************************************************************
** Count values, based on a 1 millisecond update period.
*******************************************************************************/
#define  SECOND_1_CNT     ((U16)( 1 / 0.001 ))           // 1 second
#define  MINUTE_1_CNT     ((U16)( 60  / 0.001 ))         // 1 minute
#define  MINUTE_5_CNT     ((U32)(( 5 * 60 ) / 0.001 ))   // 5 minutes
#define  MINUTE_10_CNT    ((U32)(( 10 * 60 ) / 0.001 ))  // 10 minutes

/*******************************************************************************
** function prototypes
*******************************************************************************/
/* Function prototypes from convert.c.   ?? serial_debug.c ??*/
void output_initial_debug_info( dbug_print_options_t dpo );
void update_comm_events( void );
char * real_temp_to_string( F32 number );
char * s16_to_string( S16 num, dbug_print_options_t lz );
char * printable_timestamp( U32 num, dbug_print_options_t lz );
void reset_stm32( reset_options_t opt );
U8 hex_ascii( unsigned char hex_nibble );
U8 ascii_hex( unsigned char ascii );
char * hex_2_bcd( U16 hex_num );
void  debug_output( U32 time_tick, U16 adc_cnt, F32 tC, U8 drive );
U32 power_func( U8 base, U8 exp );
F32 string2float( char * str );
U16 string2int16( char * str );
U16  scale_value( U8 duty );
F32 temperature_convert( F32 t_val, U8 f_c );
F32  IEEE_754_bytes_to_float( U8 * f_array );
U8 * IEEE_754_float_to_bytes( F32 real_num );
F32 round_float( F32 val, U8 places );
F32  limit_check( F32 val, F32 upper, F32 lower );
F32  limit_check_temperature( F32 in_val, U8 sp );

/* Function prototypes from gpio.c. */
void  led_init( void );
void  led_setup( led_id_t id, led_t mode, U16 on_time, U16 off_time, U8 repeat );
void  led_on_off( led_id_t id, BOOL state );
void  update_led_ctrl_events( void );
led_t led_status( led_id_t id );

/* Function prototypes from main.c. */
U8  error_check( void );
task_owner_t  get_next_task( void );
void  task_timer_stop( task_owner_t owner );
void  task_timer_init( void );
void  task_timer_start( task_owner_t owner, U16 t_cnt, timer_type_t t_type );
BOOL  task_timer_done_check( task_owner_t owner );
void  update_task_timer( void );
menu_states_t  menu_mode_state( menu_states_t opm, get_set_access_t gs );
void  set_idle_mode( void );
void  update_misc_events( void );
void  update_error_check_events( void );
void  control_modes_init( void );
op_ctrl_states_t  ctrl_mode_state( op_ctrl_states_t state, get_set_access_t gs );
U8    board_cfg_get( void );
U8    read_board_config_pins( void );
U32  get_error_bits( void );
void  error_bit_ctrl( error_bit_t cs, U32 error_ );
void  debug_pin_output( debug_pin_t pin_high_low_toggle );

/* Function prototypes from initial_tasks.c */
void  initial_hardware_and_parms( void );
void  initial_tasks( void );
U32 get_stm32_info( stm32_reg_t reg_id );
void SystemClock_Config( void );
static void MX_GPIO_Init( void );

/* Function prototypes from tests.c */
void  test_mode_event_control( void );
void  display_msg_and_temp( char * s, F32 t );

/* Function prototypes from operation.c */
void  update_operation_events( void );
void  totals_init( void );
void  totals_tracker( void );

/* Function prototypes from menus.c. */
void  display_top_menu_line( U8 num );
void  display_bottom_menu_line( char * str );
void  level_1_menu_1( void );
void  level_1_menu_2( void );
void  level_1_menu_3( void );
void  level_1_menu_4( void );
void  level_2_menu_1( void );
void  level_2_menu_2( void );
void  level_2_menu_3( void );
void  level_2_menu_4( void );
void  menu_process( U8 pb );
void  menu_cmd_adjust_temperature( void );
void  menu_cmd_adjust_om_units( void );
void  menu_cmd_save_temperature( void );
void  menu_cmd_save_t_units( void );
void  menu_cmd_save_om_units( void );
void  menu_cmd_adjust_t_units( void );
void  display_value_saved_msg( void );
void  menu_cmd_null( void );
void  menu_values_manager( menu_adj_cmnds_t action );
void  menu_cmd_pwr_button( void );
void  menu_cmd_start_auto( void );
void  menu_cmd_go_back( void );

#endif  /* project_h_ */

/* project.h ************************************************************ EOF */
