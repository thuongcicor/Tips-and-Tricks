@echo off
setlocal enabledelayedexpansion

:: Batch-Skript für Diagnostic Monitor
set PY_SCRIPT=ReadDiagnostic.py
set COMPONENT_FILE=diagnostic_components.txt

:: Erstelle Komponentenliste
echo Serial Number (0-15),0,15 > %COMPONENT_FILE%
echo Battery Serial Number (16-34),16,19 >> %COMPONENT_FILE%
echo Firmware Version (36-41),36,6 >> %COMPONENT_FILE%
echo NTC Flex (42-43),42,2 >> %COMPONENT_FILE%
echo Hall Sensor (44-45),44,2 >> %COMPONENT_FILE%
echo Button (46-47),46,2 >> %COMPONENT_FILE%
echo Qi Interrupt (48-49),48,2 >> %COMPONENT_FILE%
echo Power Detect (50-51),50,2 >> %COMPONENT_FILE%
echo Battery Status (52-53),52,2 >> %COMPONENT_FILE%
echo NTC Battery (54-55),54,2 >> %COMPONENT_FILE%
echo Battery Level (56-57),56,2 >> %COMPONENT_FILE%
echo Right Current (58-59),58,2 >> %COMPONENT_FILE%
echo Left Current (60-61),60,2 >> %COMPONENT_FILE%
echo EEPROM Battery (62-77),62,16 >> %COMPONENT_FILE%
echo EEPROM HA Right (78-87),78,10 >> %COMPONENT_FILE%
echo EEPROM HA Left (88-97),88,10 >> %COMPONENT_FILE%
echo EEPROM Error (98-107),98,10 >> %COMPONENT_FILE%
echo Battery IC Registers (108-115),108,8 >> %COMPONENT_FILE%
echo STWLC38 Registers (116-121),116,6 >> %COMPONENT_FILE%
echo CRC (122-123),122,2 >> %COMPONENT_FILE%

:start
cls
echo **************************************
echo    DIAGNOSTIC MONITOR MENU
echo **************************************
:::::::::::::::::::::::::::::::::::::
:: Automatic COM Port Detection
:::::::::::::::::::::::::::::::::::::

:: Query registry for available COM ports
set "key=HKLM\HARDWARE\DEVICEMAP\SERIALCOMM"
set "count=0"

:: Store COM ports in an array
for /f "tokens=3" %%a in ('reg query %key% 2^>nul ^| find "COM"') do (
    set /a "count+=1"
    set "comport[!count!]=%%a"
)

:: No COM ports found
if %count% == 0 (
    echo No COM ports found!
    pause
    exit /b 1
)

:: Only one COM port found
if %count% == 1 (
    echo Only one COM port found: !comport[1]!
    set "COMPORT=!comport[1]!"
    goto start
)

:: Multiple COM ports - show selection
echo Available COM ports:
for /l %%i in (1,1,%count%) do (
    echo [%%i] !comport[%%i]!
)

:choice
echo.
set /p "input=Select a COM port (1-%count%): "
if "!input!"=="" goto choice
if !input! lss 1 goto choice
if !input! gtr %count% goto choice

set "com_port=!comport[%input%]!"

:: Komponentenauswahl-Menu
:component_menu
cls
echo **************************************
echo    COMPONENT SELECTION
echo **************************************
echo.
echo Available Diagnostic Components:
echo.

set counter=0
for /f "tokens=1-3 delims=," %%a in (%COMPONENT_FILE%) do (
    set /a counter+=1
    set "component[!counter!]=%%a"
    set "start[!counter!]=%%b"
    set "size[!counter!]=%%c"
    echo [!counter!] %%a
)

echo.
set /p selections="Enter component numbers (comma separated, e.g. 1,3,5) or 'a' for all: "

:: Format-Auswahl
echo.
set /p format="Enter output format (d for dec, h for hex, i for int, b for bin, s for str): "
if /i "!format!"=="h" (
    set format_option=hex
) else if /i "!format!"=="i" (
    set format_option=int
) else if /i "!format!"=="b" (
    set format_option=bin
) else if /i "!format!"=="s" (
    set format_option=str
) else (
    set format_option=dec
)
set quiet_option=--quiet


:: Verarbeite Auswahl
set components=
set starts=
set sizes=

if "%selections%"=="a" (
    for /l %%i in (1,1,%counter%) do (
        set components=!components! "!component[%%i]!"
        set starts=!starts! !start[%%i]!
        set sizes=!sizes! !size[%%i]!
    )
) else (
    for %%s in (%selections%) do (
        set valid=0
        for /l %%i in (1,1,%counter%) do (
            if "%%s"=="%%i" (
                set valid=1
                set components=!components! "!component[%%i]!"
                set starts=!starts! !start[%%i]!
                set sizes=!sizes! !size[%%i]!
            )
        )
        if !valid!==0 (
            echo Invalid selection: %%s
            pause
            goto component_menu
        )
    )
)

:: Starte Überwachung für jede ausgewählte Komponente
echo.
echo Starting monitoring for selected components...
echo.

set first=1
for %%c in (%components%) do (
    if !first!==1 (
        set comp_list=%%~c
        set /a first=0
    ) else (
        set comp_list=!comp_list!, %%~c
    )
)

echo Monitoring: !comp_list!
echo Output format: !format_option!
if "!quiet_option!"=="--quiet" echo Quiet mode enabled
echo.
echo Press 'x' to stop monitoring and return to menu
echo.

:: Starte Python-Skripte im Hintergrund
set index=0
for %%s in (%starts%) do (
    set /a index+=1
    
    :: Holen der Größe für die aktuelle Komponente
    call :get_size !index!
    
    echo Starting monitoring for: !component[%index%]!
    start "Diagnostic Monitor" /B python %PY_SCRIPT% --com %com_port% --start %%s --size !current_size! --format !format_option! --timestamp show !quiet_option!
)

:: Warte auf 'x' zum Beenden mit verbesserter Formatierung
echo.
:wait_for_x
set /p input=Type 'x' and press Enter to stop: 
if /i "!input!"=="x" (
    taskkill /f /im python.exe > nul 2>&1
    goto component_menu
)
goto wait_for_x

:: Funktion zum Abrufen der Größe basierend auf dem Index
:get_size
set current_size=
set count=0
for %%z in (%sizes%) do (
    set /a count+=1
    if !count! equ %1 set current_size=%%z
)
exit /b

endlocal