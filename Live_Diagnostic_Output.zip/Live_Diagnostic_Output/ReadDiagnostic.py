import argparse
import serial
from serial.tools import list_ports
import time
import sys
import datetime
import threading
import platform
import msvcrt
import os

# Flag to control program execution
exit_flag = False

def read_keyboard():
    """Check for 'q' input to exit program without Enter"""
    global exit_flag
    while not exit_flag:
        if sys.platform == "win32":
            # Windows implementation
            if msvcrt.kbhit():
                key = msvcrt.getch().decode('utf-8', 'ignore')
                if key == 'q' or key == 'Q':
                    exit_flag = True
                    break
        else:
            # Linux/macOS implementation
            import termios, fcntl
            fd = sys.stdin.fileno()
            oldterm = termios.tcgetattr(fd)
            newattr = termios.tcgetattr(fd)
            newattr[3] = newattr[3] & ~termios.ICANON & ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSANOW, newattr)
            oldflags = fcntl.fcntl(fd, fcntl.F_GETFL)
            fcntl.fcntl(fd, fcntl.F_SETFL, oldflags | os.O_NONBLOCK)
            
            try:
                c = sys.stdin.read(1)
                if c == 'q' or c == 'Q':
                    exit_flag = True
                    break
            except IOError:
                pass
            finally:
                termios.tcsetattr(fd, termios.TCSAFLUSH, oldterm)
                fcntl.fcntl(fd, fcntl.F_SETFL, oldflags)
        
        time.sleep(0.01)

def bytes_to_int(byte_array, endian='big'):
    """Convert byte array to integer"""
    return int.from_bytes(byte_array, byteorder=endian)

def main():
    global exit_flag
    parser = argparse.ArgumentParser(
        description='UART Diagnostic Data Reader', 
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Required parameters
    parser.add_argument('--com', required=True, help='COM port name (e.g. COM3)')
    parser.add_argument('--start', type=int, required=True, help='Start position in message (0-based index)')
    parser.add_argument('--size', type=int, required=True, help='Number of bytes to extract')
    
    # Optional parameters
    parser.add_argument('--format', choices=['hex', 'dec', 'int', 'bin', 'str'], default='dec', 
                       help='Output format: "hex" (hex bytes), "dec" (decimal bytes), "int" (integer value), "bin" (binary bytes), "str" (string)')
    parser.add_argument('--timestamp', choices=['show', 'hide'], default='show', 
                       help='Show timestamp: "show" or "hide"')
    parser.add_argument('--endian', choices=['big', 'little'], default='big', 
                       help='Byte order for integer conversion: "big" or "little"')
    parser.add_argument('--baud', type=int, default=115200, help='Baud rate')
    parser.add_argument('--timeout', type=float, default=0.1, 
                       help='Inter-message timeout in seconds')
    parser.add_argument('--list-ports', action='store_true', 
                       help='List available COM ports and exit')
    parser.add_argument('--quiet', action='store_true', 
                       help='Quiet mode - only show results and timestamps')
    
    args = parser.parse_args()
    
    # List available ports if requested
    if args.list_ports:
        print("Available COM ports:")
        ports = list_ports.comports()
        for port in ports:
            print(f"  - {port.device}")
        sys.exit(0)
    
    ser = None
    try:
        # Initialize serial connection
        ser = serial.Serial(
            port=args.com,
            baudrate=args.baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.1
        )
        
        if not args.quiet:
            print(f"Listening on {args.com} at {args.baud} baud...")
            print(f"Extracting {args.size} bytes starting from position {args.start}")
            print(f"Output format: {args.format.upper()}")
            print(f"Timestamp: {'SHOWN' if args.timestamp == 'show' else 'HIDDEN'}")
            if args.format == 'int':
                print(f"Byte order: {args.endian.upper()}")
            print(f"Message timeout: {args.timeout}s")
            print("Press 'q' to exit (without Enter)\n")
        
        # Start keyboard listening thread
        keyboard_thread = threading.Thread(target=read_keyboard, daemon=True)
        keyboard_thread.start()
        
        buffer = bytearray()
        last_receive_time = time.time()
        
        while not exit_flag:
            # Read available data
            data = ser.read(ser.in_waiting or 1)
            if data:
                buffer.extend(data)
                last_receive_time = time.time()
            
            # Check if we've received a complete message
            current_time = time.time()
            if buffer and (current_time - last_receive_time > args.timeout):
                # Process complete message
                if len(buffer) >= args.start + args.size:
                    segment = buffer[args.start:args.start + args.size]
                    
                    # Format output based on user selection
                    if args.format == 'hex':
                        output_values = [f"{b:02X}" for b in segment]
                    elif args.format == 'dec':
                        output_values = [str(b) for b in segment]
                    elif args.format == 'int':
                        int_value = bytes_to_int(segment, args.endian)
                        output_values = [str(int_value)]
                    elif args.format == 'bin':
                        output_values = [f"{b:08b}" for b in segment]
                    elif args.format == 'str':
                        try:
                            output_values = [segment.decode('utf-8', errors='replace')]
                        except Exception as e:
                            output_values = [f"<decode error: {e}>"]
                    
                    output_str = ' '.join(output_values)
                    
                    # Add timestamp if requested
                    if args.timestamp == 'show':
                        timestamp = datetime.datetime.now().strftime('%H:%M:%S')
                        print(f"[{timestamp}] {output_str}")
                    else:
                        print(output_str)
                
                # Clear buffer for next message
                buffer = bytearray()
            
            # Small delay to reduce CPU load
            time.sleep(0.01)
    
    except KeyboardInterrupt:
        if not args.quiet:
            print("\nProgram terminated by user")
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        exit_flag = True
        if ser and ser.is_open:
            ser.close()
        if not args.quiet:
            print("\nProgram exited")

if __name__ == "__main__":
    # Add Linux/macOS dependencies if needed
    if sys.platform != "win32":
        import os
    main()